#SBATCH --job-name="SubmissionTest/bundle
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 4
export OMP_NUM_THREADS=2
