#PBS -N SubmissionTe/73fac832/hybrid_op/0000
#PBS -V
#PBS -l nodes=1
export OMP_NUM_THREADS=2
