#PBS -N SubmissionTe/8f195d74/hybrid_op/0000
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux
export OMP_NUM_THREADS=2
