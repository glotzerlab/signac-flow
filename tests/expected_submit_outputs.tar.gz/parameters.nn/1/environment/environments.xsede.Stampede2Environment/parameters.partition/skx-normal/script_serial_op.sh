#SBATCH --job-name="SubmissionTe/ee92e792/serial_op/0000/"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --partition=skx-normal