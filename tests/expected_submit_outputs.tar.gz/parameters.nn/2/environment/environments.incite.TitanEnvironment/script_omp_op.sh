#PBS -N SubmissionTe/3a4af2fe/omp_op/0000
#PBS -V
#PBS -l nodes=2
export OMP_NUM_THREADS=2
