#PBS -N SubmissionTe/3fa0a26f/hybrid_op/0000
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux
export OMP_NUM_THREADS=2
