#SBATCH --job-name="SubmissionTe/aaac0fa7/omp_op/0000
#SBATCH --partition=RM
#SBATCH -N 2
#SBATCH --ntasks-per-node 2
export OMP_NUM_THREADS=2
