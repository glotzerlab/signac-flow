#SBATCH --job-name="SubmissionTe/e5515eac/omp_op/0000/"
#SBATCH --partition=compute
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=2
export OMP_NUM_THREADS=2