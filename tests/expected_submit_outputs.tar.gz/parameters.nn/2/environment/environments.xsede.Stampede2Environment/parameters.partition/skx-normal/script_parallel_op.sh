#SBATCH --job-name="SubmissionTe/37545281/parallel_op/0000
#SBATCH --partition=skx-normal
#SBATCH --nodes=2
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal
