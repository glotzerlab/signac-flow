#PBS -N SubmissionTe/9626d150/omp_op/0000
#PBS -V
#PBS -l nodes=1
export OMP_NUM_THREADS=2
