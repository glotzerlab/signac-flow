#SBATCH --job-name="SubmissionTe/63dbe882/hybrid_op/0000/"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4
export OMP_NUM_THREADS=2