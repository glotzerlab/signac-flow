#PBS -N SubmissionTe/c6eca32b/hybrid_op/0000
#PBS -V
#PBS -l nodes=1
export OMP_NUM_THREADS=2
