#SBATCH --job-name="SubmissionTe/d53ea384/omp_op/0000
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2
export OMP_NUM_THREADS=2
