#SBATCH --job-name="SubmissionTe/eff95441/mpi_op/0000
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
