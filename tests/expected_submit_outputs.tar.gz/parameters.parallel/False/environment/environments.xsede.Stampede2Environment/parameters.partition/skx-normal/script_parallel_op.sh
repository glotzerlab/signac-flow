#SBATCH --job-name="SubmissionTe/f433720d/parallel_op/0000
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal
