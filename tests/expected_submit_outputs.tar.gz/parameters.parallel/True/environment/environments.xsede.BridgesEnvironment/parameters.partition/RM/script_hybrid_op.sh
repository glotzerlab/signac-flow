#SBATCH --job-name="SubmissionTe/354054a3/hybrid_op/0000
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 4
export OMP_NUM_THREADS=2
