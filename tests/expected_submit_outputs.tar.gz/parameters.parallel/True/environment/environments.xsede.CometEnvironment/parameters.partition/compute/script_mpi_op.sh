#SBATCH --job-name="SubmissionTe/6d58262f/mpi_op/0000
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
