#SBATCH --job-name="SubmissionTe/6d58262f/omp_op/0000
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
export OMP_NUM_THREADS=2
