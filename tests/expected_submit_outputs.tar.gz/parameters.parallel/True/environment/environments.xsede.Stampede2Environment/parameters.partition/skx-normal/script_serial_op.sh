#SBATCH --job-name="SubmissionTe/1d9e6021/serial_op/0000
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --partition=skx-normal
