#PBS -N SubmissionTe/64760707/omp_op/0000/
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1
export OMP_NUM_THREADS=2