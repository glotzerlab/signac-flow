#PBS -N SubmissionTe/52fdf0d6/hybrid_op/0000/
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=4
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux
export OMP_NUM_THREADS=2