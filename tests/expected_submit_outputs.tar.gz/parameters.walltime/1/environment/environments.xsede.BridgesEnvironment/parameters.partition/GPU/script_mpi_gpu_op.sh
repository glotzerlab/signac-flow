#SBATCH --job-name="SubmissionTe/d52fc627/mpi_gpu_op/0000
#SBATCH --partition=GPU
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 2
#SBATCH --gres=gpu:p100:2
