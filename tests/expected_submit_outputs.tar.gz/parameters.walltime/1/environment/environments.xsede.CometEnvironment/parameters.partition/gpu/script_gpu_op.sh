#SBATCH --job-name="SubmissionTe/b2c00b6e/gpu_op/0000
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2
