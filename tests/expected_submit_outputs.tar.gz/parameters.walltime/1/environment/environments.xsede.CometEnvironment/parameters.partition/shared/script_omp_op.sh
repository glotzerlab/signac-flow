#SBATCH --job-name="SubmissionTe/f90e4a81/omp_op/0000/"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
export OMP_NUM_THREADS=2