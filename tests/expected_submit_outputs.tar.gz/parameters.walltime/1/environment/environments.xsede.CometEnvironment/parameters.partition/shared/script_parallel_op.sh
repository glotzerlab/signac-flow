#SBATCH --job-name="SubmissionTe/f90e4a81/parallel_op/0000
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
