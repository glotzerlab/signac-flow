#PBS -N SubmissionTe/5c02d3da/hybrid_op/0000
#PBS -V
#PBS -l nodes=1
export OMP_NUM_THREADS=2
