#SBATCH --job-name="SubmissionTe/d30f0956/mpi_gpu_op/0000
#SBATCH --partition=GPU
#SBATCH -N 1
#SBATCH --ntasks-per-node 2
#SBATCH --gres=gpu:p100:2
