#SBATCH --job-name="SubmissionTe/8aef86cd/omp_op/0000
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2
export OMP_NUM_THREADS=2
