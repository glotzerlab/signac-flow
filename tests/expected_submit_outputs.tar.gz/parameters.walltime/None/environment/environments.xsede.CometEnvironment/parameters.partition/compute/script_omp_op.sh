#SBATCH --job-name="SubmissionTe/0b5d7732/omp_op/0000
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
export OMP_NUM_THREADS=2
