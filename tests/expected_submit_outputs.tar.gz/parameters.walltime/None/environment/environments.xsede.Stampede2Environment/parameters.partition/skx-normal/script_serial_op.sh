#SBATCH --job-name="SubmissionTe/4a483a99/serial_op/0000
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --partition=skx-normal
