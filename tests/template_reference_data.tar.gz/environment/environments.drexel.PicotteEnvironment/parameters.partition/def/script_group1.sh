#!/bin/bash
#SBATCH --job-name="SubmissionTe/c2940d034a9b34f09a1909074cc4c214/memory_oppar/a85ff0ae5eb63d8794818249ded07c8c"
#SBATCH --mem=512M
#SBATCH --partition=def
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c2940d034a9b34f09a1909074cc4c214
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c2940d034a9b34f09a1909074cc4c214
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c2940d034a9b34f09a1909074cc4c214
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c2940d034a9b34f09a1909074cc4c214

