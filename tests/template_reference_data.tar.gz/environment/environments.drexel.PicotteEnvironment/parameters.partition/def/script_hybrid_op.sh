#!/bin/bash
#SBATCH --job-name="TestProject/c2940d034a9b34f09a1909074cc4c214/hybrid_op/8fc5f078063d2db3d659d307f8c14cf1"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op c2940d034a9b34f09a1909074cc4c214

