#!/bin/bash
#SBATCH --job-name="SubmissionTe/c2940d034a9b34f09a1909074cc4c214/memory_op/57b42aff9df6460fa07beaea8090b552"
#SBATCH --mem=512M
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c2940d034a9b34f09a1909074cc4c214

