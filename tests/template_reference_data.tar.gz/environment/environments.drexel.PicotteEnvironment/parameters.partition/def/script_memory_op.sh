#!/bin/bash
#SBATCH --job-name="TestProject/c2940d034a9b34f09a1909074cc4c214/memory_op/51b5807edac299580c3e3d6cbb751ee5"
#SBATCH --mem=512M
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c2940d034a9b34f09a1909074cc4c214

