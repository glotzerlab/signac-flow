#!/bin/bash
#SBATCH --job-name="TestProject/c2940d034a9b34f09a1909074cc4c214/mpi_op/9ec5795b8516f122b54a8735d099b750"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op c2940d034a9b34f09a1909074cc4c214

