#!/bin/bash
#SBATCH --job-name="SubmissionTe/c2940d034a9b34f09a1909074cc4c214/mpi_op/e9d326e7615a671e7d3f3ebf809828b2"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op c2940d034a9b34f09a1909074cc4c214

