#!/bin/bash
#SBATCH --job-name="SubmissionTe/c2940d034a9b34f09a1909074cc4c214/multiline_cm/377dcf089eb188f10185b92bc1cf552e"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# echo "First line"
# echo "Second line"

