#!/bin/bash
#SBATCH --job-name="SubmissionTe/c2940d034a9b34f09a1909074cc4c214/omp_op/906dd8c7601b2349b5a849e1ba027d56"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op c2940d034a9b34f09a1909074cc4c214

