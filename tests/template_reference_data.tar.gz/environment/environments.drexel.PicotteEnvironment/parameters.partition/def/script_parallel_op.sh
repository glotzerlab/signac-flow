#!/bin/bash
#SBATCH --job-name="SubmissionTe/c2940d034a9b34f09a1909074cc4c214/parallel_op/4ffce2ea0da0913abc0d3f8a5707470d"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c2940d034a9b34f09a1909074cc4c214

