#!/bin/bash
#SBATCH --job-name="SubmissionTe/c2940d034a9b34f09a1909074cc4c214/serial_op/67eef1b7bb4b1cd35b0f9bc352a5065e"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c2940d034a9b34f09a1909074cc4c214

