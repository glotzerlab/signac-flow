#!/bin/bash
#SBATCH --job-name="TestProject/c2940d034a9b34f09a1909074cc4c214/serial_op/402bdf0ace8fe62f42e69494abeb7950"
#SBATCH --partition=def
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op c2940d034a9b34f09a1909074cc4c214

