#!/bin/bash
#SBATCH --job-name="TestProject/c2940d034a9b34f09a1909074cc4c214/walltime_op/4baa462a9a2c85e0010477a7bb039b17"
#SBATCH --partition=def
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(c2940d034a9b34f09a1909074cc4c214)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j c2940d034a9b34f09a1909074cc4c214
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op c2940d034a9b34f09a1909074cc4c214

