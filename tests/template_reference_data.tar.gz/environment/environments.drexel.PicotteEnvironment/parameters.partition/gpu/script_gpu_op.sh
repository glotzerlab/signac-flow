#!/bin/bash
#SBATCH --job-name="SubmissionTe/85dd3d23561f8fd287e9707eed9ab24f/gpu_op/07a98722e379e98ad53546ecc46197f9"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --gres=gpu:2

set -e
set -u

cd /home/user/project/

# gpu_op(85dd3d23561f8fd287e9707eed9ab24f)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 85dd3d23561f8fd287e9707eed9ab24f
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 85dd3d23561f8fd287e9707eed9ab24f

