#!/bin/bash
#SBATCH --job-name="SubmissionTe/85dd3d23561f8fd287e9707eed9ab24f/gpu_op/f20f614da70150b25e1ca16d75401a3d"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --gres=gpu:2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(85dd3d23561f8fd287e9707eed9ab24f)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 85dd3d23561f8fd287e9707eed9ab24f
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 85dd3d23561f8fd287e9707eed9ab24f

