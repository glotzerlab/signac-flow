#!/bin/bash
#SBATCH --job-name="SubmissionTe/85dd3d23561f8fd287e9707eed9ab24f/mpi_gpu_op/86f0a81d146ecc5c477e200e195cdd06"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --gres=gpu:2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(85dd3d23561f8fd287e9707eed9ab24f)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 85dd3d23561f8fd287e9707eed9ab24f
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 85dd3d23561f8fd287e9707eed9ab24f

