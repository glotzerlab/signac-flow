#!/bin/bash
#SBATCH --job-name="SubmissionTe/85dd3d23561f8fd287e9707eed9ab24f/mpi_gpu_op/e12bfe43242e36501f8bbf99b4986d5e"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --gres=gpu:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(85dd3d23561f8fd287e9707eed9ab24f)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 85dd3d23561f8fd287e9707eed9ab24f
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 85dd3d23561f8fd287e9707eed9ab24f

