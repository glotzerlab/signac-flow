#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/memory_oppar/6f27870b46a8c94bd19e92b9862298dc"
#SBATCH --mem=512M
#SBATCH --partition=batch
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op a542b3b4fca15890cbe140f2ae2a64ae
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op a542b3b4fca15890cbe140f2ae2a64ae
# /usr/local/bin/python generate_template_reference_data.py exec memory_op a542b3b4fca15890cbe140f2ae2a64ae
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op a542b3b4fca15890cbe140f2ae2a64ae

