#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/hybrid_op/0842c08891e176f158c4d22a171814bb"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# hybrid_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# export OMP_NUM_THREADS=4; srun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op a542b3b4fca15890cbe140f2ae2a64ae

