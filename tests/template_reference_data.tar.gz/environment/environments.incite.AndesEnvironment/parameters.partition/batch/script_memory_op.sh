#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/memory_op/9b905c6681548df142a26910b81de1b3"
#SBATCH --mem=512M
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# memory_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op a542b3b4fca15890cbe140f2ae2a64ae

