#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/mpi_op/af23ecb85d558e6d3512424ce888df35"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# srun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op a542b3b4fca15890cbe140f2ae2a64ae

