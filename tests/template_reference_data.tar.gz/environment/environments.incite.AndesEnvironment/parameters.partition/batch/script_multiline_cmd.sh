#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/multiline_cm/7ecaa5213e277ad7fb3228866dbf025d"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# echo "First line"
# echo "Second line"

