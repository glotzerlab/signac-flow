#!/bin/bash
#SBATCH --job-name="TestProject/a542b3b4fca15890cbe140f2ae2a64ae/multiline_cm/76fe60f0e7d38064d5a0f5fb9aba246c"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# echo "First line"
# echo "Second line"

