#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/omp_op/9dc4522cf3f0daab715e4f46ecb1a7da"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op a542b3b4fca15890cbe140f2ae2a64ae

