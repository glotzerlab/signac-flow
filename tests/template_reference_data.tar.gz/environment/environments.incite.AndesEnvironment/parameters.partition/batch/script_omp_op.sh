#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/omp_op/ca014637b11819bacf66ec9b19f96f20"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd "/home/user/project/"

# omp_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op a542b3b4fca15890cbe140f2ae2a64ae

