#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/parallel_op/cb85340193df85e99754800c929a512c"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op a542b3b4fca15890cbe140f2ae2a64ae

