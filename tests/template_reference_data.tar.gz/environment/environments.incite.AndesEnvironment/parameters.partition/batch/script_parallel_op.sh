#!/bin/bash
#SBATCH --job-name="SubmissionTe/a542b3b4fca15890cbe140f2ae2a64ae/parallel_op/3952fe2eefa3f7837512072e53a0879e"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op a542b3b4fca15890cbe140f2ae2a64ae

