#!/bin/bash
#SBATCH --job-name="TestProject/a542b3b4fca15890cbe140f2ae2a64ae/serial_op/032ac2ced96769f483cfe9b7cb2c07ea"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op a542b3b4fca15890cbe140f2ae2a64ae

