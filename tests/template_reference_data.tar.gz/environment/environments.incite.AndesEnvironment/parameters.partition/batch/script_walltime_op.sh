#!/bin/bash
#SBATCH --job-name="TestProject/a542b3b4fca15890cbe140f2ae2a64ae/walltime_op/30ff0b7bfc5dae31da9175d9bd75ce90"
#SBATCH --partition=batch
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(a542b3b4fca15890cbe140f2ae2a64ae)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j a542b3b4fca15890cbe140f2ae2a64ae
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op a542b3b4fca15890cbe140f2ae2a64ae

