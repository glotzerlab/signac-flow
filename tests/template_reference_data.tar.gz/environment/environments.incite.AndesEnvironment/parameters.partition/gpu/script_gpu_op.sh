#!/bin/bash
#SBATCH --job-name="SubmissionTe/903d32c75e91ad4838ba339e84068811/gpu_op/f1da5a03d4779b828ebe6dea3d493cee"
#SBATCH --partition=gpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(903d32c75e91ad4838ba339e84068811)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 903d32c75e91ad4838ba339e84068811
# Eligible to run:
# srun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 903d32c75e91ad4838ba339e84068811

