#!/bin/bash
#SBATCH --job-name="SubmissionTe/903d32c75e91ad4838ba339e84068811/mpi_gpu_op/ba2c066b645a7253e48afa6509c93869"
#SBATCH --partition=gpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(903d32c75e91ad4838ba339e84068811)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 903d32c75e91ad4838ba339e84068811
# Eligible to run:
# srun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 903d32c75e91ad4838ba339e84068811

