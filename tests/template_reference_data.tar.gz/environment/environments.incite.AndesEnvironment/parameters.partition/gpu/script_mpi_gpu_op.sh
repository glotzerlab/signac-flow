#!/bin/bash
#SBATCH --job-name="TestProject/903d32c75e91ad4838ba339e84068811/mpi_gpu_op/ba2c066b645a7253e48afa6509c93869"
#SBATCH --partition=gpu
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(903d32c75e91ad4838ba339e84068811)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 903d32c75e91ad4838ba339e84068811
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 903d32c75e91ad4838ba339e84068811

