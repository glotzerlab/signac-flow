#!/bin/bash
#SBATCH --job-name="SubmissionTe/903d32c75e91ad4838ba339e84068811/mpi_gpu_op/00210d0313dceb18ee45676931d21804"
#SBATCH --partition=gpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(903d32c75e91ad4838ba339e84068811)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 903d32c75e91ad4838ba339e84068811
# Eligible to run:
# srun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 903d32c75e91ad4838ba339e84068811

