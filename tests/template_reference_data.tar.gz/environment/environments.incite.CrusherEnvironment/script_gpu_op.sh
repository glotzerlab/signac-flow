#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/gpu_op/39b40d6b1eb1dfe3067213afc879c180"
#SBATCH -N 1
#SBATCH -p batch
#SBATCH --threads-per-core=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# srun -N1 -n2 -c1 --gpus=2 /usr/local/bin/python generate_template_reference_data.py exec gpu_op ba42c5556e02f460bb65791858f2faa7

