#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/memory_oppar/02431de214907b0b32a34cd98e0f630d"
#SBATCH --mem=512M
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op ba42c5556e02f460bb65791858f2faa7
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op ba42c5556e02f460bb65791858f2faa7
# /usr/local/bin/python generate_template_reference_data.py exec memory_op ba42c5556e02f460bb65791858f2faa7
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op ba42c5556e02f460bb65791858f2faa7

