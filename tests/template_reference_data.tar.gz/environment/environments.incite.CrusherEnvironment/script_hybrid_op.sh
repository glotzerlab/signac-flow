#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/hybrid_op/9cd6a5149dc3d99bf60f39f1e57d6012"
#SBATCH -N 1
#SBATCH -p batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# export OMP_NUM_THREADS=4; srun -N1 -n5 -c4 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op ba42c5556e02f460bb65791858f2faa7

