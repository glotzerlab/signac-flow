#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/mpi_gpu_op/9863b0446cda0d2389803243b983f5f8"
#SBATCH -N 1
#SBATCH -p batch
#SBATCH --threads-per-core=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# srun -N1 -n5 -c1 --gpus=2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op ba42c5556e02f460bb65791858f2faa7

