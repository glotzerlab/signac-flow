#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/mpi_op/1b1963e7d02a13f261466acb808f7670"
#SBATCH -N 1
#SBATCH -p batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# srun -N1 -n5 -c1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec mpi_op ba42c5556e02f460bb65791858f2faa7

