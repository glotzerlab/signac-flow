#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/parallel_op/9c984a77fc7af88de6223959a2cc60de"
#SBATCH -N 1
#SBATCH -p batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# srun -N1 -n0 -c1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec parallel_op ba42c5556e02f460bb65791858f2faa7

