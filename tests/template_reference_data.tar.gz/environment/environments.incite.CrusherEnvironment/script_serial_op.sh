#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/serial_op/3ee0f01fed557630645c072a479480d1"
#SBATCH -N 1
#SBATCH -p batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# srun -N1 -n0 -c1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec serial_op ba42c5556e02f460bb65791858f2faa7

