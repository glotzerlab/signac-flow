#!/bin/bash
#SBATCH --job-name="TestProject/ba42c5556e02f460bb65791858f2faa7/serial_op/3ee0f01fed557630645c072a479480d1"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(ba42c5556e02f460bb65791858f2faa7)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j ba42c5556e02f460bb65791858f2faa7
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op ba42c5556e02f460bb65791858f2faa7

