#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/gpu_op/6ef575c12810aff93c6c74c0fd231047"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# srun --ntasks=2 --cpus-per-task=1 --gpus=2 /usr/local/bin/python generate_template_reference_data.py exec gpu_op 1dc3681e5d3346c9176701458c4dac5c

