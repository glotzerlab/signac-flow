#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/hybrid_op/a48a922e1600538a5a5dcb0ccecdb8a0"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=5 --cpus-per-task=4 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 1dc3681e5d3346c9176701458c4dac5c

