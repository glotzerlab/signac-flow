#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/memory_op/0fa3c65c6a20c70621259578b7e6ca0f"
#SBATCH --mem=512M
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1dc3681e5d3346c9176701458c4dac5c

