#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/mpi_op/b72ddcf58fc91756f1438004f5677f59"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# srun --ntasks=5 --cpus-per-task=1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 1dc3681e5d3346c9176701458c4dac5c

