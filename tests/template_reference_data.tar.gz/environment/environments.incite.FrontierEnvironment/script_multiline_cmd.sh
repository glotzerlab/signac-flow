#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/multiline_cm/94c5d6c6bf4841b01c80c01345161065"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# echo "First line"
# echo "Second line"

