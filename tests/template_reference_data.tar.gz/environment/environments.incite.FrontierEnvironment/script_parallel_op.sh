#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/parallel_op/66238403126bcec5e621238ce4b92fce"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 1dc3681e5d3346c9176701458c4dac5c

