#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/serial_op/89ab361a3fc79a50ffc07f9d22faa784"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1dc3681e5d3346c9176701458c4dac5c

