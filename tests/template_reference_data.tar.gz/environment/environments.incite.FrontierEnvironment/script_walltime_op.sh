#!/bin/bash
#SBATCH --job-name="TestProject/1dc3681e5d3346c9176701458c4dac5c/walltime_op/3a25900e2179c4327f5ccbd22083c38d"
#SBATCH -t 01:00:00
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(1dc3681e5d3346c9176701458c4dac5c)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 1dc3681e5d3346c9176701458c4dac5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 1dc3681e5d3346c9176701458c4dac5c

