#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/gpu_op/ed0ac40ecc0ff21fc51dae42484137ef
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 2 -a 1 -c 1 -g 1 --smpiargs='-gpu' -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 2e06630241047937c0b6e273acab00e4

