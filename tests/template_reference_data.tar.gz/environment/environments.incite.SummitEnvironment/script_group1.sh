'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/memory_oppar/f957969b064b0bb3ba5a59f2a419a0e4
#BSUB -M 512MB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# 
# 
# 
# 

