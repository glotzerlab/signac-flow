#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/memory_oppar/3352055080021ec0383eb772bea21d42
#BSUB -M 0.5GB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# group1(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec serial_op 2e06630241047937c0b6e273acab00e4
# jsrun -n 1 -a 1 -c 3 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec parallel_op 2e06630241047937c0b6e273acab00e4
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec memory_op 2e06630241047937c0b6e273acab00e4
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec walltime_op 2e06630241047937c0b6e273acab00e4

