#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/hybrid_op/14b2e2374f47d15e17e8e4c84c0c73c3
#BSUB -nnodes 1

set -e
set -u

cd "/home/user/project/"

# hybrid_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# export OMP_NUM_THREADS=4; jsrun -n 5 -a 1 -c 4 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 2e06630241047937c0b6e273acab00e4

