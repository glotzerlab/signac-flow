#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/hybrid_op/628f68b8471501407b02b18338a21ed1
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# export OMP_NUM_THREADS=4; jsrun -n 5 -a 1 -c 4 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 2e06630241047937c0b6e273acab00e4

