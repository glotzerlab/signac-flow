#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/memory_op/70ff41898ca36eb5aab328eee9c13b86
#BSUB -M 512MB
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec memory_op 2e06630241047937c0b6e273acab00e4

