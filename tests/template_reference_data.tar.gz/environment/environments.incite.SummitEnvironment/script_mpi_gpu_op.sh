#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/mpi_gpu_op/2857c151a9995a3d2e71f1d2828ae0aa
#BSUB -nnodes 1

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# mpi_gpu_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 5 -c 5 -g 2 --smpiargs='-gpu' -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 2e06630241047937c0b6e273acab00e4

