#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/mpi_op/20c5deca8c690a8f5c147b54500bacca
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 5 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 2e06630241047937c0b6e273acab00e4

