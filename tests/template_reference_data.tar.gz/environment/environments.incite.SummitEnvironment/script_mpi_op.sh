'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/mpi_op/31b0f782d505916a76d31be1fb2c7336
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# 

