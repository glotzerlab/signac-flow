#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/multiline_cm/86f8b1c9042524f47b209350156af84a
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# echo "First line"
# echo "Second line"

