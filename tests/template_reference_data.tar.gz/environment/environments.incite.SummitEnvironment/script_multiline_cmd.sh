#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/multiline_cm/49a477752134043b8d9937826c612959
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# multiline_cmd(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  echo "First line"
# echo "Second line"

