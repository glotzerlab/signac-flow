#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/omp_op/3ee159760894e1964504bd4b5eeaf8fc
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# omp_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# export OMP_NUM_THREADS=4; jsrun -n 1 -a 1 -c 4 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec omp_op 2e06630241047937c0b6e273acab00e4

