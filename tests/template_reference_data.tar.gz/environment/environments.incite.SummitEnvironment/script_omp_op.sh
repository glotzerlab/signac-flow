'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/omp_op/42cae68b2b4125e29e0123a18b938df2
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# 

