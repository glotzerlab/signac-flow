#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/parallel_op/c65b3e3ae24ba73073ec55bf2482043b
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 1 -c 3 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec parallel_op 2e06630241047937c0b6e273acab00e4

