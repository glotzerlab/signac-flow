#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/parallel_op/03efb77c3a860040afa21bb4e30c4228
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# parallel_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 1 -c 3 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec parallel_op 2e06630241047937c0b6e273acab00e4

