#!/bin/bash
#BSUB -J SubmissionTe/2e06630241047937c0b6e273acab00e4/serial_op/232d26480a4d26feb44967275b0baaae
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# serial_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec serial_op 2e06630241047937c0b6e273acab00e4

