#!/bin/bash
#BSUB -J TestProject/2e06630241047937c0b6e273acab00e4/walltime_op/6ee2dc45f5d5986c1a0d3c4d247573f0
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(2e06630241047937c0b6e273acab00e4)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 2e06630241047937c0b6e273acab00e4
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec walltime_op 2e06630241047937c0b6e273acab00e4

