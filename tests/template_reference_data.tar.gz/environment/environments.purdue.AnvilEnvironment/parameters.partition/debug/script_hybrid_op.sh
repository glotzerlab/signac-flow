#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/hybrid_op/5f1de6966c74c36db660527c44116fa1"
#SBATCH --partition=debug
#SBATCH --ntasks=20
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op bfb25e9e67b86abb540dfb07716993c6

