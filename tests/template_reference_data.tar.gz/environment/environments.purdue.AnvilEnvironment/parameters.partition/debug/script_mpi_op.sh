#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/mpi_op/f649e30df839ad82ae78a57109e17898"
#SBATCH --partition=debug
#SBATCH --ntasks=5
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op bfb25e9e67b86abb540dfb07716993c6

