#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/multiline_cm/58d28fb46435250be00f7dfa82900908"
#SBATCH --partition=debug
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# echo "First line"
# echo "Second line"

