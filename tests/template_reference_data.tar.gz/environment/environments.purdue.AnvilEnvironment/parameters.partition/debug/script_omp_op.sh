#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/omp_op/6c10ff11dbe4d221b996b8ad3bc44439"
#SBATCH --partition=debug
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op bfb25e9e67b86abb540dfb07716993c6

