#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/omp_op/6c10ff11dbe4d221b996b8ad3bc44439"
#SBATCH --partition=debug
#SBATCH --ntasks=4
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op bfb25e9e67b86abb540dfb07716993c6

