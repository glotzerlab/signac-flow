#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/parallel_op/24316f7ea753988276a41f20c7b114c3"
#SBATCH --partition=debug
#SBATCH --ntasks=3
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op bfb25e9e67b86abb540dfb07716993c6

