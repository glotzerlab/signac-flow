#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/serial_op/8b33ead77958b67914844d411e52c101"
#SBATCH --partition=debug
#SBATCH --ntasks=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op bfb25e9e67b86abb540dfb07716993c6

