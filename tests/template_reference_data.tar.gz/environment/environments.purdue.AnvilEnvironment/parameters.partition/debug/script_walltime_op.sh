#!/bin/bash
#SBATCH --job-name="TestProject/bfb25e9e67b86abb540dfb07716993c6/walltime_op/b9a64853d75b22bf8e0c2397cd571e8c"
#SBATCH --partition=debug
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(bfb25e9e67b86abb540dfb07716993c6)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j bfb25e9e67b86abb540dfb07716993c6
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op bfb25e9e67b86abb540dfb07716993c6

