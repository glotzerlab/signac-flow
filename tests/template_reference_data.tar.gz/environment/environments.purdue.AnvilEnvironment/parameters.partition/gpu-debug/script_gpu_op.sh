#!/bin/bash
#SBATCH --job-name="TestProject/af829225858ac05eb89a650c1fea1bb1/gpu_op/e6fea6cfea8aae7fe627925a59dcf657"
#SBATCH --partition=gpu-debug
#SBATCH --ntasks=2
#SBATCH --gpus=2
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(af829225858ac05eb89a650c1fea1bb1)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j af829225858ac05eb89a650c1fea1bb1
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op af829225858ac05eb89a650c1fea1bb1

