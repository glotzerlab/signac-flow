#!/bin/bash
#SBATCH --job-name="TestProject/af829225858ac05eb89a650c1fea1bb1/mpi_gpu_op/d3631a6700117eea4e5d6919ba352e7d"
#SBATCH --partition=gpu-debug
#SBATCH --ntasks=5
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(af829225858ac05eb89a650c1fea1bb1)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j af829225858ac05eb89a650c1fea1bb1
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op af829225858ac05eb89a650c1fea1bb1

