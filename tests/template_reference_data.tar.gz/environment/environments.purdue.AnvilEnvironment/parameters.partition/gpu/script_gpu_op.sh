#!/bin/bash
#SBATCH --job-name="TestProject/f3ee4294324f3c5f2416d7ae2b1f4527/gpu_op/34620012affee60156f9f71d52956384"
#SBATCH --partition=gpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(f3ee4294324f3c5f2416d7ae2b1f4527)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j f3ee4294324f3c5f2416d7ae2b1f4527
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op f3ee4294324f3c5f2416d7ae2b1f4527

