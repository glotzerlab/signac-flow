#!/bin/bash
#SBATCH --job-name="TestProject/f3ee4294324f3c5f2416d7ae2b1f4527/gpu_op/34620012affee60156f9f71d52956384"
#SBATCH --partition=gpu
#SBATCH --ntasks=2
#SBATCH --gpus=2
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(f3ee4294324f3c5f2416d7ae2b1f4527)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j f3ee4294324f3c5f2416d7ae2b1f4527
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op f3ee4294324f3c5f2416d7ae2b1f4527

