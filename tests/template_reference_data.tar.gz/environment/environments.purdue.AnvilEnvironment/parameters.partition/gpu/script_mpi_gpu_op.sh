#!/bin/bash
#SBATCH --job-name="TestProject/f3ee4294324f3c5f2416d7ae2b1f4527/mpi_gpu_op/7d248351ec91fb15c0a311a730be2f01"
#SBATCH --partition=gpu
#SBATCH --ntasks=5
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(f3ee4294324f3c5f2416d7ae2b1f4527)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j f3ee4294324f3c5f2416d7ae2b1f4527
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op f3ee4294324f3c5f2416d7ae2b1f4527

