#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/memory_oppar/94fbbcd58d15c8cea49eff5fde2577fa"
#SBATCH --mem=512M
#SBATCH --partition=highmem
#SBATCH -t 01:00:00
#SBATCH --ntasks=3
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 0fdd4e3af86683ecbb5de7a048bd2435
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 0fdd4e3af86683ecbb5de7a048bd2435
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 0fdd4e3af86683ecbb5de7a048bd2435
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 0fdd4e3af86683ecbb5de7a048bd2435

