#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/hybrid_op/c0a42e9eb43a8deae42f0f2cebebcf63"
#SBATCH --partition=highmem
#SBATCH --ntasks=20
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 0fdd4e3af86683ecbb5de7a048bd2435

