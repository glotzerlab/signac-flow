#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/memory_op/f4ac0e35c8dc1297a3d9bd3589b396a7"
#SBATCH --mem=512M
#SBATCH --partition=highmem
#SBATCH --ntasks=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 0fdd4e3af86683ecbb5de7a048bd2435

