#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/mpi_op/4f547d41755bb19bd3adf62e92e1ba9f"
#SBATCH --partition=highmem
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 0fdd4e3af86683ecbb5de7a048bd2435

