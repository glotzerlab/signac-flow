#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/multiline_cm/3c57d06496574f8442802e8e62b7a5c4"
#SBATCH --partition=highmem
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# echo "First line"
# echo "Second line"

