#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/omp_op/d7ca8383146f760f22b1d6f52d9488ce"
#SBATCH --partition=highmem
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 0fdd4e3af86683ecbb5de7a048bd2435

