#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/omp_op/d7ca8383146f760f22b1d6f52d9488ce"
#SBATCH --partition=highmem
#SBATCH --ntasks=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 0fdd4e3af86683ecbb5de7a048bd2435

