#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/parallel_op/57cd7e192f86db4dff467de99ccda6ba"
#SBATCH --partition=highmem
#SBATCH --ntasks=3
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 0fdd4e3af86683ecbb5de7a048bd2435

