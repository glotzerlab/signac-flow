#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/serial_op/2f801da7a37f80d3ab9e0fd8129bbe9b"
#SBATCH --partition=highmem
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 0fdd4e3af86683ecbb5de7a048bd2435

