#!/bin/bash
#SBATCH --job-name="TestProject/0fdd4e3af86683ecbb5de7a048bd2435/walltime_op/053ce0c2f71963ba1e5c4d30009c167d"
#SBATCH --partition=highmem
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(0fdd4e3af86683ecbb5de7a048bd2435)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 0fdd4e3af86683ecbb5de7a048bd2435
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 0fdd4e3af86683ecbb5de7a048bd2435

