#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/memory_op/36bdf389dc10fd0c3a2748ee8b695334"
#SBATCH --mem=512M
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 5094bf939eecc868f76a9d47ea8e3694

