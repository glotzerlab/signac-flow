#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/mpi_op/5a877aa92713d183c815facf2273c84f"
#SBATCH --partition=shared
#SBATCH --ntasks=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 5094bf939eecc868f76a9d47ea8e3694

