#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/multiline_cm/85cbc5889b3605f51c68cece4c8707f5"
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# echo "First line"
# echo "Second line"

