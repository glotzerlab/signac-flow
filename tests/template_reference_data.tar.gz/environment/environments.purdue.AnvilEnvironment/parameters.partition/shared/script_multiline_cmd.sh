#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/multiline_cm/85cbc5889b3605f51c68cece4c8707f5"
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# echo "First line"
# echo "Second line"

