#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/omp_op/800a4aed8f3e5027ba8fe31d04567cc7"
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 5094bf939eecc868f76a9d47ea8e3694

