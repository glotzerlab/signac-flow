#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/parallel_op/fbc492aee9315229781f73e4d51b33f0"
#SBATCH --partition=shared
#SBATCH --ntasks=3
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 5094bf939eecc868f76a9d47ea8e3694

