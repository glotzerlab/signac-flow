#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/serial_op/f996d136ebdf47a3ac1eb22ef418bbcc"
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 5094bf939eecc868f76a9d47ea8e3694

