#!/bin/bash
#SBATCH --job-name="TestProject/5094bf939eecc868f76a9d47ea8e3694/walltime_op/eb26a221c1a2e984febe61f323f9d6af"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(5094bf939eecc868f76a9d47ea8e3694)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 5094bf939eecc868f76a9d47ea8e3694
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 5094bf939eecc868f76a9d47ea8e3694

