#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/memory_oppar/46e5d2b153da4ba06a7b2a11214d3e07"
#SBATCH --mem=512M
#SBATCH --partition=wholenode
#SBATCH -t 01:00:00
#SBATCH --ntasks=3
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 61ae1b7764ff789a7702a206c3ab7553
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 61ae1b7764ff789a7702a206c3ab7553
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 61ae1b7764ff789a7702a206c3ab7553
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 61ae1b7764ff789a7702a206c3ab7553

