#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/hybrid_op/c545d5993752346e7e68de843aa41b17"
#SBATCH --partition=wholenode
#SBATCH --ntasks=20
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 61ae1b7764ff789a7702a206c3ab7553

