#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/memory_op/6cbaf447c7dbc3d10a494ae91d485e9b"
#SBATCH --mem=512M
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 61ae1b7764ff789a7702a206c3ab7553

