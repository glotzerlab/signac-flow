#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/mpi_op/fa0144e9586ff686f8bf784db6d0d1b3"
#SBATCH --partition=wholenode
#SBATCH --ntasks=5
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 61ae1b7764ff789a7702a206c3ab7553

