#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/multiline_cm/b0f9c525e05787e0c484837cb0d07e15"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# echo "First line"
# echo "Second line"

