#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/omp_op/28dfd4de6a54b1045075c98f3735e183"
#SBATCH --partition=wholenode
#SBATCH --ntasks=4
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 61ae1b7764ff789a7702a206c3ab7553

