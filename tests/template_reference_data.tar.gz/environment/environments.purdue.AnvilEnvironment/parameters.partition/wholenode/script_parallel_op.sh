#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/parallel_op/746eb21f62770a3137d28bdd5a9fe422"
#SBATCH --partition=wholenode
#SBATCH --ntasks=3
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 61ae1b7764ff789a7702a206c3ab7553

