#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/serial_op/9ec42ad526dc286b427f859514a9587d"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 61ae1b7764ff789a7702a206c3ab7553

