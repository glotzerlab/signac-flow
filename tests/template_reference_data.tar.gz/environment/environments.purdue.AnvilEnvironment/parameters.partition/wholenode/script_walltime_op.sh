#!/bin/bash
#SBATCH --job-name="TestProject/61ae1b7764ff789a7702a206c3ab7553/walltime_op/7a5aa78b06773dc5d32e3058b1662b87"
#SBATCH --partition=wholenode
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(61ae1b7764ff789a7702a206c3ab7553)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 61ae1b7764ff789a7702a206c3ab7553
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 61ae1b7764ff789a7702a206c3ab7553

