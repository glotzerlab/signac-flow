#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/memory_oppar/9101453f88f36d670f8e56c9492dec16"
#SBATCH --mem=512M
#SBATCH --partition=wide
#SBATCH -t 01:00:00
#SBATCH --ntasks=3
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 413febaa3960552c564ef9b99f60f4d0
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 413febaa3960552c564ef9b99f60f4d0
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 413febaa3960552c564ef9b99f60f4d0
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 413febaa3960552c564ef9b99f60f4d0

