#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/hybrid_op/558591f2db1ad87e84b8fc836b233408"
#SBATCH --partition=wide
#SBATCH --ntasks=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 413febaa3960552c564ef9b99f60f4d0

