#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/memory_op/49ccc7a2a5f4768a7c48e9a145b04fcd"
#SBATCH --partition=wide
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 413febaa3960552c564ef9b99f60f4d0

