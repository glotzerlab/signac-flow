#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/memory_op/49ccc7a2a5f4768a7c48e9a145b04fcd"
#SBATCH --mem=512M
#SBATCH --partition=wide
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 413febaa3960552c564ef9b99f60f4d0

