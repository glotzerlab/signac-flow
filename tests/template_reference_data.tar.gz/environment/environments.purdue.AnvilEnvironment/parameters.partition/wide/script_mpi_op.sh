#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/mpi_op/ad2b203e0045b4d1a4103ff0e24cb728"
#SBATCH --partition=wide
#SBATCH --ntasks=5
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 413febaa3960552c564ef9b99f60f4d0

