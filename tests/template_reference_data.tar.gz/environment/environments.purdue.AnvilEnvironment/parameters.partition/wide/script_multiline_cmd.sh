#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/multiline_cm/d1d5552d7159a51196ce21bccae63436"
#SBATCH --partition=wide
#SBATCH --ntasks=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# echo "First line"
# echo "Second line"

