#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/omp_op/c8c742d74211c4a30ebe765ee5ccddf4"
#SBATCH --partition=wide
#SBATCH --ntasks=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 413febaa3960552c564ef9b99f60f4d0

