#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/parallel_op/d478617e6d9c1dbe24a82e7f9198b0f1"
#SBATCH --partition=wide
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 413febaa3960552c564ef9b99f60f4d0

