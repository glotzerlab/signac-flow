#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/parallel_op/d478617e6d9c1dbe24a82e7f9198b0f1"
#SBATCH --partition=wide
#SBATCH --ntasks=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 413febaa3960552c564ef9b99f60f4d0

