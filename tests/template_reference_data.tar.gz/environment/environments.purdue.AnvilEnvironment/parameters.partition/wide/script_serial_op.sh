#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/serial_op/71f12f3d1a89f6594ed56ef12907ddd9"
#SBATCH --partition=wide
#SBATCH --ntasks=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 413febaa3960552c564ef9b99f60f4d0

