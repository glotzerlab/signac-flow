#!/bin/bash
#SBATCH --job-name="TestProject/413febaa3960552c564ef9b99f60f4d0/walltime_op/bb6f28554d23b346cc663de823919439"
#SBATCH --partition=wide
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH -A dmr140129

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(413febaa3960552c564ef9b99f60f4d0)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 413febaa3960552c564ef9b99f60f4d0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 413febaa3960552c564ef9b99f60f4d0

