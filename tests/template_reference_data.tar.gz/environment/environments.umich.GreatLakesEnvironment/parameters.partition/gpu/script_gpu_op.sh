#!/bin/bash
#SBATCH --job-name="SubmissionTe/2c8c654420ae2097b9d25a5641864ca7/gpu_op/0c739d257fa1cd6d6f73bd080ee5e1dd"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2
#SBATCH --account=sglotzer0

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(2c8c654420ae2097b9d25a5641864ca7)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 2c8c654420ae2097b9d25a5641864ca7
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 2c8c654420ae2097b9d25a5641864ca7

