#!/bin/bash
#SBATCH --job-name="SubmissionTe/2c8c654420ae2097b9d25a5641864ca7/mpi_gpu_op/45c14b29d999f7d195d40a1e6d901fa3"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(2c8c654420ae2097b9d25a5641864ca7)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 2c8c654420ae2097b9d25a5641864ca7
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 2c8c654420ae2097b9d25a5641864ca7

