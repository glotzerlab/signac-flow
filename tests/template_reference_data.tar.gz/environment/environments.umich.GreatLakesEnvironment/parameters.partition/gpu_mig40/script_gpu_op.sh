#!/bin/bash
#SBATCH --job-name="TestProject/e7f66bbb5888f6a943a1e7f04d9b8bca/gpu_op/ea0d1395a5707aa29d9359cb72b7a506"
#SBATCH --partition=gpu_mig40
#SBATCH --nodes=1-1
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(e7f66bbb5888f6a943a1e7f04d9b8bca)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j e7f66bbb5888f6a943a1e7f04d9b8bca
# Eligible to run:
# srun -u --export=ALL -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op e7f66bbb5888f6a943a1e7f04d9b8bca

