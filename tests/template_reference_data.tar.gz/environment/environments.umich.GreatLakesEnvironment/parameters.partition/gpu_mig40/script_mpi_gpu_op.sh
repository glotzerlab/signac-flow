#!/bin/bash
#SBATCH --job-name="TestProject/e7f66bbb5888f6a943a1e7f04d9b8bca/mpi_gpu_op/7c843671a4e4f9243122bd122297514a"
#SBATCH --partition=gpu_mig40
#SBATCH --nodes=1-1
#SBATCH --ntasks=5
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=0

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(e7f66bbb5888f6a943a1e7f04d9b8bca)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j e7f66bbb5888f6a943a1e7f04d9b8bca
# Eligible to run:
# srun -u --export=ALL -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op e7f66bbb5888f6a943a1e7f04d9b8bca

