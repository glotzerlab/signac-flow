#!/bin/bash
#SBATCH --job-name="SubmissionTe/c560c58797faf382d72c9f282e015a5a/memory_oppar/41afc43e0dfe0d0c69dd1597c46be744"
#SBATCH --mem=512M
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c560c58797faf382d72c9f282e015a5a
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c560c58797faf382d72c9f282e015a5a
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c560c58797faf382d72c9f282e015a5a
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c560c58797faf382d72c9f282e015a5a

