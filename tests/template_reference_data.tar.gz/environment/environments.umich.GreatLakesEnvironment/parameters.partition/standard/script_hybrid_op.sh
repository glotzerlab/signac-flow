#!/bin/bash
#SBATCH --job-name="SubmissionTe/c560c58797faf382d72c9f282e015a5a/hybrid_op/4b6826312d7336e08fecb4838371ba1f"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op c560c58797faf382d72c9f282e015a5a

