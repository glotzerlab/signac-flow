#!/bin/bash
#SBATCH --job-name="TestProject/c560c58797faf382d72c9f282e015a5a/hybrid_op/8c3dc5d919a81dfcbdd4adc89c0a3541"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op c560c58797faf382d72c9f282e015a5a

