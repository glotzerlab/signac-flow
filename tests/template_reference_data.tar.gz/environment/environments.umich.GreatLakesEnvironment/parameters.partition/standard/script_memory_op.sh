#!/bin/bash
#SBATCH --job-name="SubmissionTe/c560c58797faf382d72c9f282e015a5a/memory_op/0b33e8fded91ce072949562dffe74548"
#SBATCH --mem=0.5G
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c560c58797faf382d72c9f282e015a5a

