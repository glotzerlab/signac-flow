#!/bin/bash
#SBATCH --job-name="TestProject/c560c58797faf382d72c9f282e015a5a/memory_op/56803eaf00848d310c67c28b45506e53"
#SBATCH --partition=standard
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op c560c58797faf382d72c9f282e015a5a

