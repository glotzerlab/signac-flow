#!/bin/bash
#SBATCH --job-name="TestProject/c560c58797faf382d72c9f282e015a5a/mpi_op/7d0b8e9cec85e7b302f76fe75a57020f"
#SBATCH --partition=standard
#SBATCH --nodes=1-1
#SBATCH --ntasks=5
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# srun -u --export=ALL -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op c560c58797faf382d72c9f282e015a5a

