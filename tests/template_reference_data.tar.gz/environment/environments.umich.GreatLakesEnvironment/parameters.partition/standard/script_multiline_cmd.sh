#!/bin/bash
#SBATCH --job-name="SubmissionTe/c560c58797faf382d72c9f282e015a5a/multiline_cm/57f192fe32e049c18a4f54cb73b88025"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# echo "First line"
# echo "Second line"

