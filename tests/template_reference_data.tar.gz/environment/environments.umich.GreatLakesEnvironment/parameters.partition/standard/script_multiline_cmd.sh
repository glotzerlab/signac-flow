#!/bin/bash
#SBATCH --job-name="SubmissionTe/c560c58797faf382d72c9f282e015a5a/multiline_cm/5f6e789d8bcb6601456da5fffda5abd2"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# echo "First line"
# echo "Second line"

