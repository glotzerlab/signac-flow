#!/bin/bash
#SBATCH --job-name="TestProject/c560c58797faf382d72c9f282e015a5a/serial_op/a1ad8233a093090717259dc87c0879d8"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c560c58797faf382d72c9f282e015a5a

