#!/bin/bash
#SBATCH --job-name="SubmissionTe/c560c58797faf382d72c9f282e015a5a/serial_op/d860d6319eab222522ba8b548be41124"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd "/home/user/project/"

# serial_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c560c58797faf382d72c9f282e015a5a

