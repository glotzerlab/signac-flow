#!/bin/bash
#SBATCH --job-name="TestProject/c560c58797faf382d72c9f282e015a5a/walltime_op/93959c4592972ca442627ceef070ff9e"
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1-1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(c560c58797faf382d72c9f282e015a5a)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j c560c58797faf382d72c9f282e015a5a
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c560c58797faf382d72c9f282e015a5a

