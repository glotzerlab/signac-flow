#!/bin/bash
#SBATCH --job-name="TestProject/c10822efccdbf590a37b4d1c8741aab8/gpu_op/925908214fd25e922a3cf8ce717ea81e"
#SBATCH --ntasks=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op c10822efccdbf590a37b4d1c8741aab8

