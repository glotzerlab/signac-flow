#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/memory_oppar/cd6b473c13d2061c7d2ef55c100eb6b6"
#SBATCH --mem=512M
#SBATCH -t 01:00:00
#SBATCH --ntasks=3

set -e
set -u

cd "/home/user/project/"

# group1(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c10822efccdbf590a37b4d1c8741aab8
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c10822efccdbf590a37b4d1c8741aab8
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c10822efccdbf590a37b4d1c8741aab8
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c10822efccdbf590a37b4d1c8741aab8

