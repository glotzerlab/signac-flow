#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/hybrid_op/8a114d17d9c783bc07bad5ceb0185de7"
#SBATCH --ntasks=20

set -e
set -u

cd /home/user/project/

# hybrid_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op c10822efccdbf590a37b4d1c8741aab8

