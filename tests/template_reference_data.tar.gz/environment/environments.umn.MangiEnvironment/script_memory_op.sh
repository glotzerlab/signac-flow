#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/memory_op/db60ca20f32726e4c49d7668c5a3bb43"
#SBATCH --mem=512M
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# memory_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c10822efccdbf590a37b4d1c8741aab8

