#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/mpi_gpu_op/a571ab62598dd3183233a578a73d4a1a"
#SBATCH --ntasks=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op c10822efccdbf590a37b4d1c8741aab8

