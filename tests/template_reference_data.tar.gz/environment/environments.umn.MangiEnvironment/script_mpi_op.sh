#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/mpi_op/c9c854a86cf831d1516f21e9969557d4"
#SBATCH --ntasks=5

set -e
set -u

cd "/home/user/project/"

# mpi_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op c10822efccdbf590a37b4d1c8741aab8

