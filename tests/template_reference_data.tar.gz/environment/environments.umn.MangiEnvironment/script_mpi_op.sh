#!/bin/bash
#SBATCH --job-name="TestProject/c10822efccdbf590a37b4d1c8741aab8/mpi_op/4920c8a092b463097e38d8cf88150d63"
#SBATCH --ntasks=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op c10822efccdbf590a37b4d1c8741aab8

