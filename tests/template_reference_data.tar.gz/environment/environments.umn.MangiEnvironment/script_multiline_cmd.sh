#!/bin/bash
#SBATCH --job-name="TestProject/c10822efccdbf590a37b4d1c8741aab8/multiline_cm/7eb5ac7f5c19def2191dbdb83508b7c6"
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# echo "First line"
# echo "Second line"

