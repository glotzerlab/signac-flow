#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/omp_op/43b6a6655549825bc714031165f83fb8"
#SBATCH --ntasks=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op c10822efccdbf590a37b4d1c8741aab8

