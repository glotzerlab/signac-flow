#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/parallel_op/3122511e27737bae1b5c28a405cb0e5b"
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# parallel_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c10822efccdbf590a37b4d1c8741aab8

