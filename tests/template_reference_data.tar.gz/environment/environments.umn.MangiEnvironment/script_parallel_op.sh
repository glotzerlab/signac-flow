#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/parallel_op/315e13d5c221d2e17027023aa0296393"
#SBATCH --ntasks=3

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# parallel_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c10822efccdbf590a37b4d1c8741aab8

