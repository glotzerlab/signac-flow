#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/serial_op/b34570c0ebcc6aa2c1b615c265422085"
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/project/"

# serial_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c10822efccdbf590a37b4d1c8741aab8

