#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/serial_op/274071d73bda501a8719c984d67d8131"
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c10822efccdbf590a37b4d1c8741aab8

