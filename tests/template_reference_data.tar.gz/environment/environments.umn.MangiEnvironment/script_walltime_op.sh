#!/bin/bash
#SBATCH --job-name="SubmissionTe/c10822efccdbf590a37b4d1c8741aab8/walltime_op/3f8689850efee98ea535a7137400dbd2"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# walltime_op(c10822efccdbf590a37b4d1c8741aab8)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j c10822efccdbf590a37b4d1c8741aab8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c10822efccdbf590a37b4d1c8741aab8

