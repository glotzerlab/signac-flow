#!/bin/bash
#SBATCH --job-name="SubmissionTe/48e992d35c85c7fe16d4daf9cae8e4ff/gpu_op/1bc317ad67a32c254440e1670df231fa"
#SBATCH --partition=GPU-shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(48e992d35c85c7fe16d4daf9cae8e4ff)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 48e992d35c85c7fe16d4daf9cae8e4ff
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 48e992d35c85c7fe16d4daf9cae8e4ff

