#!/bin/bash
#SBATCH --job-name="SubmissionTe/48e992d35c85c7fe16d4daf9cae8e4ff/mpi_gpu_op/8dab2f5f4c6c34966cae1b161cc706c4"
#SBATCH --partition=GPU-shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(48e992d35c85c7fe16d4daf9cae8e4ff)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 48e992d35c85c7fe16d4daf9cae8e4ff
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 48e992d35c85c7fe16d4daf9cae8e4ff

