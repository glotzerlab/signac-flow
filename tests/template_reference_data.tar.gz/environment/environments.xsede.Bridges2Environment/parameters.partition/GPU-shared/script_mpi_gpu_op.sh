#!/bin/bash
#SBATCH --job-name="SubmissionTe/48e992d35c85c7fe16d4daf9cae8e4ff/mpi_gpu_op/b6f85b8b29f3178e58dcaefec164ddfc"
#SBATCH --partition=GPU-shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(48e992d35c85c7fe16d4daf9cae8e4ff)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 48e992d35c85c7fe16d4daf9cae8e4ff
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 48e992d35c85c7fe16d4daf9cae8e4ff

