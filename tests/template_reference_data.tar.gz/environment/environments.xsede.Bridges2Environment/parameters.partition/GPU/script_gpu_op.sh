#!/bin/bash
#SBATCH --job-name="TestProject/6bdc14d4ce63d9fd41a516a97e7f5a59/gpu_op/cfb0399b61db0e8b498352f09d62fb98"
#SBATCH --partition=GPU
#SBATCH --ntasks=2
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(6bdc14d4ce63d9fd41a516a97e7f5a59)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 6bdc14d4ce63d9fd41a516a97e7f5a59
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 6bdc14d4ce63d9fd41a516a97e7f5a59

