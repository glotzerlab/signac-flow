#!/bin/bash
#SBATCH --job-name="SubmissionTe/6bdc14d4ce63d9fd41a516a97e7f5a59/mpi_gpu_op/828233185df59940c7ed8e6b11f7fe6d"
#SBATCH --partition=GPU
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd "/home/user/project/"

# mpi_gpu_op(6bdc14d4ce63d9fd41a516a97e7f5a59)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 6bdc14d4ce63d9fd41a516a97e7f5a59
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 6bdc14d4ce63d9fd41a516a97e7f5a59

