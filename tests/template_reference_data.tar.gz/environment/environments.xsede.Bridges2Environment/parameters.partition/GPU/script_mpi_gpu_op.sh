#!/bin/bash
#SBATCH --job-name="TestProject/6bdc14d4ce63d9fd41a516a97e7f5a59/mpi_gpu_op/2f435b6f614ef6d06e8d128a0c34a9a6"
#SBATCH --partition=GPU
#SBATCH -N 1
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(6bdc14d4ce63d9fd41a516a97e7f5a59)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 6bdc14d4ce63d9fd41a516a97e7f5a59
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 6bdc14d4ce63d9fd41a516a97e7f5a59

