#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/memory_oppar/354afaecbbfea765bae9ff9785774c80"
#SBATCH --mem=512M
#SBATCH --partition=RM-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# group1(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 36260405f6a3c70170eacdf55bbfa900
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 36260405f6a3c70170eacdf55bbfa900
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 36260405f6a3c70170eacdf55bbfa900
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 36260405f6a3c70170eacdf55bbfa900

