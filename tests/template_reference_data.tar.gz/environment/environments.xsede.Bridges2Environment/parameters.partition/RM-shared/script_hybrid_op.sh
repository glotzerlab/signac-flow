#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/hybrid_op/e9b219def27639a140e951211bd19cce"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=20

set -e
set -u

cd /home/user/project/

# hybrid_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 36260405f6a3c70170eacdf55bbfa900

