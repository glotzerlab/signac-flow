#!/bin/bash
#SBATCH --job-name="TestProject/36260405f6a3c70170eacdf55bbfa900/hybrid_op/bc726a63bb0177c108794e3a1374f946"
#SBATCH --partition=RM-shared
#SBATCH --ntasks=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 36260405f6a3c70170eacdf55bbfa900

