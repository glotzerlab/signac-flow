#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/memory_op/a01fbcbe0f29a3fd625e65170ec0d5a4"
#SBATCH --mem=0.5G
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# memory_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 36260405f6a3c70170eacdf55bbfa900

