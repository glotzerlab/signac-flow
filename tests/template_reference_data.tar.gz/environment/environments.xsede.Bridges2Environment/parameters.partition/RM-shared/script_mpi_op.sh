#!/bin/bash
#SBATCH --job-name="TestProject/36260405f6a3c70170eacdf55bbfa900/mpi_op/b55479995ca696afb3ae6dd7ecd615f6"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 36260405f6a3c70170eacdf55bbfa900

