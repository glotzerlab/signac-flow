#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/mpi_op/8e152d0bc5fe9ecde82490245d85e08b"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 36260405f6a3c70170eacdf55bbfa900

