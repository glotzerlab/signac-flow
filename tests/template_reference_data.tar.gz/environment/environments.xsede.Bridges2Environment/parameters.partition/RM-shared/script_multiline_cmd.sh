#!/bin/bash
#SBATCH --job-name="TestProject/36260405f6a3c70170eacdf55bbfa900/multiline_cm/80d8eb0ea235a5b0ef06d51a9a671788"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# echo "First line"
# echo "Second line"

