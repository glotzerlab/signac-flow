#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/multiline_cm/fcf3b2efd1dc3cdb13575ea1ffc39229"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/project/"

# multiline_cmd(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# echo "First line"
# echo "Second line"

