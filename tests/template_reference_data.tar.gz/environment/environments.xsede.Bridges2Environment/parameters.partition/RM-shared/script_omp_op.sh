#!/bin/bash
#SBATCH --job-name="TestProject/36260405f6a3c70170eacdf55bbfa900/omp_op/750e666c763b3b4c1a3ac09827a1bf5e"
#SBATCH --partition=RM-shared
#SBATCH --ntasks=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 36260405f6a3c70170eacdf55bbfa900

