#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/omp_op/aac2e3f7f17f3f0f9b157fc2f2ca5399"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=4

set -e
set -u

cd "/home/user/project/"

# omp_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 36260405f6a3c70170eacdf55bbfa900

