#!/bin/bash
#SBATCH --job-name="TestProject/36260405f6a3c70170eacdf55bbfa900/parallel_op/48cfa96240f4bdcd556d5330025a49a1"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 36260405f6a3c70170eacdf55bbfa900

