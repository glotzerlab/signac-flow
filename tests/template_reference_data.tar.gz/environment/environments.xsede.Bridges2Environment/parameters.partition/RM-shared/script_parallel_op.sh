#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/parallel_op/1e0cec42b638355585cf9ef900306726"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd "/home/user/project/"

# parallel_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 36260405f6a3c70170eacdf55bbfa900

