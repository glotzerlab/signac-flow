#!/bin/bash
#SBATCH --job-name="TestProject/36260405f6a3c70170eacdf55bbfa900/serial_op/3253d3c8098b60e450a9f7f35ba9e241"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 36260405f6a3c70170eacdf55bbfa900

