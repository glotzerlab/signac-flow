#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/serial_op/c6fea46ea5e6821440a3463e6be3ac56"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# serial_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 36260405f6a3c70170eacdf55bbfa900

