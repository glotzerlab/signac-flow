#!/bin/bash
#SBATCH --job-name="SubmissionTe/36260405f6a3c70170eacdf55bbfa900/walltime_op/e8a4d2b4f532cb1f6d03cb97824aa25f"
#SBATCH --partition=RM-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(36260405f6a3c70170eacdf55bbfa900)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 36260405f6a3c70170eacdf55bbfa900
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 36260405f6a3c70170eacdf55bbfa900

