#!/bin/bash
#SBATCH --job-name="TestProject/8738e54ee383cc64ad1aae2bd3c36a86/memory_oppar/a181d5ddfce335e2857010efe1f63a37"
#SBATCH --mem=512M
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8738e54ee383cc64ad1aae2bd3c36a86
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8738e54ee383cc64ad1aae2bd3c36a86
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 8738e54ee383cc64ad1aae2bd3c36a86
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 8738e54ee383cc64ad1aae2bd3c36a86

