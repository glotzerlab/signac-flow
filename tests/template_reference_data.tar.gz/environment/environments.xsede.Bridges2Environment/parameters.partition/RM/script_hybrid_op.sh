#!/bin/bash
#SBATCH --job-name="SubmissionTe/8738e54ee383cc64ad1aae2bd3c36a86/hybrid_op/21d3437836434060df29a02a263288d9"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 8738e54ee383cc64ad1aae2bd3c36a86

