#!/bin/bash
#SBATCH --job-name="TestProject/8738e54ee383cc64ad1aae2bd3c36a86/hybrid_op/d23861f7285d4fbd0417c5579621f8e6"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 8738e54ee383cc64ad1aae2bd3c36a86

