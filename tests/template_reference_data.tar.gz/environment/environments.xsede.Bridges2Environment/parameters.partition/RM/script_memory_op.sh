#!/bin/bash
#SBATCH --job-name="SubmissionTe/8738e54ee383cc64ad1aae2bd3c36a86/memory_op/a5ccea74c3145a00984a4342b1c94817"
#SBATCH --mem=512M
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd "/home/user/project/"

# memory_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 8738e54ee383cc64ad1aae2bd3c36a86

