#!/bin/bash
#SBATCH --job-name="SubmissionTe/8738e54ee383cc64ad1aae2bd3c36a86/mpi_op/34e9565d78cf8fb8dd513f046f2f5004"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# mpi_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 8738e54ee383cc64ad1aae2bd3c36a86

