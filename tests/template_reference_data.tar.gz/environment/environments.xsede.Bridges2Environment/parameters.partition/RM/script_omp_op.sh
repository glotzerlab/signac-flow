#!/bin/bash
#SBATCH --job-name="TestProject/8738e54ee383cc64ad1aae2bd3c36a86/omp_op/3209a86b31139d49f697e959d88d3ede"
#SBATCH --partition=RM
#SBATCH --ntasks=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 8738e54ee383cc64ad1aae2bd3c36a86

