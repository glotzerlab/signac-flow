#!/bin/bash
#SBATCH --job-name="SubmissionTe/8738e54ee383cc64ad1aae2bd3c36a86/omp_op/a5d081ea36ad7d84238ef92e5b04c8c8"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 8738e54ee383cc64ad1aae2bd3c36a86

