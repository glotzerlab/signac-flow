#!/bin/bash
#SBATCH --job-name="TestProject/8738e54ee383cc64ad1aae2bd3c36a86/parallel_op/05a42f00c20c7e99d7483e81d64cfc88"
#SBATCH --partition=RM
#SBATCH --ntasks=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8738e54ee383cc64ad1aae2bd3c36a86

