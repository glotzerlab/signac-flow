#!/bin/bash
#SBATCH --job-name="SubmissionTe/8738e54ee383cc64ad1aae2bd3c36a86/parallel_op/a14c2c0ab3226daaf5ecd705d024cda6"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd "/home/user/project/"

# parallel_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8738e54ee383cc64ad1aae2bd3c36a86

