#!/bin/bash
#SBATCH --job-name="SubmissionTe/8738e54ee383cc64ad1aae2bd3c36a86/serial_op/c93fe37de76e2c433ff9e2ea6c5cfda1"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8738e54ee383cc64ad1aae2bd3c36a86

