#!/bin/bash
#SBATCH --job-name="SubmissionTe/8738e54ee383cc64ad1aae2bd3c36a86/serial_op/931ac6f29054683a56c60a7d1d937b68"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8738e54ee383cc64ad1aae2bd3c36a86

