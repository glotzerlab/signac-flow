#!/bin/bash
#SBATCH --job-name="TestProject/8738e54ee383cc64ad1aae2bd3c36a86/walltime_op/c6db9a993e39ab78128c9fdf9534492a"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(8738e54ee383cc64ad1aae2bd3c36a86)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 8738e54ee383cc64ad1aae2bd3c36a86
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 8738e54ee383cc64ad1aae2bd3c36a86

