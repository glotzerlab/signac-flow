#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/memory_oppar/d1b58cec2bd1d1d7d9a2d3f17e8ccd65"
#SBATCH --mem=0.5G
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 85cdf8330382ad266e89d50c28edff9d
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 85cdf8330382ad266e89d50c28edff9d
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 85cdf8330382ad266e89d50c28edff9d
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 85cdf8330382ad266e89d50c28edff9d

