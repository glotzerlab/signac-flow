#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/hybrid_op/154ea5147e799312b3959752c20afa15"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# export OMP_NUM_THREADS=4; ibrun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 85cdf8330382ad266e89d50c28edff9d

