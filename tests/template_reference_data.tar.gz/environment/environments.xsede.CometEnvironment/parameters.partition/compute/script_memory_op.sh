#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/memory_op/3be1077ce05865cecd4dc37e3885ed06"
#SBATCH --mem=512M
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 85cdf8330382ad266e89d50c28edff9d

