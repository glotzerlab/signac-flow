#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/mpi_op/277788aef6a861f042034e6c001b06a6"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# ibrun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 85cdf8330382ad266e89d50c28edff9d

