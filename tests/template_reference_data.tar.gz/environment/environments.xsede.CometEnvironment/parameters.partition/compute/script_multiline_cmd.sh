#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/multiline_cm/e4a33113e625de0e4225a1b859b1cb01"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# echo "First line"
# echo "Second line"

