#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/omp_op/d146a5583f78ce6565f5a05d5601136c"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 85cdf8330382ad266e89d50c28edff9d

