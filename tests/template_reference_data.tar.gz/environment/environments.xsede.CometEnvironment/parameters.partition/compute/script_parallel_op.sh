#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/parallel_op/f7ebbe0f9966442bd0ac97df50167c19"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 85cdf8330382ad266e89d50c28edff9d

