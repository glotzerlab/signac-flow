#!/bin/bash
#SBATCH --job-name="SubmissionTe/85cdf8330382ad266e89d50c28edff9d/serial_op/93c72afbd47158b09e3eb0c70c828b69"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(85cdf8330382ad266e89d50c28edff9d)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 85cdf8330382ad266e89d50c28edff9d
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 85cdf8330382ad266e89d50c28edff9d

