#!/bin/bash
#SBATCH --job-name="SubmissionTe/379926f49e28664c9de134f38d3be63f/gpu_op/ef4cd9ef0fba441c118832f032681f79"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# gpu_op(379926f49e28664c9de134f38d3be63f)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 379926f49e28664c9de134f38d3be63f
# Eligible to run:
# ibrun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 379926f49e28664c9de134f38d3be63f

