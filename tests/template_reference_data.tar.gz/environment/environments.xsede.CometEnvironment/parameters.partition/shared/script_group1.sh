#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/memory_oppar/93f65b6c4356fe9b41a8d0bbf89e0bb1"
#SBATCH --mem=512M
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 859cc287bbb951586abafb776501e854
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 859cc287bbb951586abafb776501e854
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 859cc287bbb951586abafb776501e854
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 859cc287bbb951586abafb776501e854

