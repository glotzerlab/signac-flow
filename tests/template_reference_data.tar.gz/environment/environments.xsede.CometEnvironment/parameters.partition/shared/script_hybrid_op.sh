#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/hybrid_op/cc2145fa5ff7a8bf20c945b1d0e13540"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# export OMP_NUM_THREADS=4; ibrun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 859cc287bbb951586abafb776501e854

