#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/mpi_op/259aca22fba9e5a0934347c17d4015b4"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# ibrun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 859cc287bbb951586abafb776501e854

