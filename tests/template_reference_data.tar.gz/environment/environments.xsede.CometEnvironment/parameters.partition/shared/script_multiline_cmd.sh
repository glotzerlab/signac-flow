#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/multiline_cm/530d1d840693a7b522dcfa29b125f7d4"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# echo "First line"
# echo "Second line"

