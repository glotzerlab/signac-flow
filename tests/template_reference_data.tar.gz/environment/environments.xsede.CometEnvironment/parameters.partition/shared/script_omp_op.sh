#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/omp_op/241b69c1ed7a1565468dc5b25ac146de"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 859cc287bbb951586abafb776501e854

