#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/parallel_op/0b7031025618db51b8e92174fef86330"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 859cc287bbb951586abafb776501e854

