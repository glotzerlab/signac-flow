#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/serial_op/d3ea90df57b7f39f866e77726274ce38"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 859cc287bbb951586abafb776501e854

