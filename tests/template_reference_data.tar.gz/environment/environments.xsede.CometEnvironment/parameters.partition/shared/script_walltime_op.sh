#!/bin/bash
#SBATCH --job-name="SubmissionTe/859cc287bbb951586abafb776501e854/walltime_op/1d91ead1d28787776cc3385bb6e3ed18"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# walltime_op(859cc287bbb951586abafb776501e854)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 859cc287bbb951586abafb776501e854
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 859cc287bbb951586abafb776501e854

