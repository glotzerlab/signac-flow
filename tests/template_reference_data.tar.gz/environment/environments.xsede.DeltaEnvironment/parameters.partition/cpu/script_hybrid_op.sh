#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/hybrid_op/e0d33b3299835e451f65f99a12303310"
#SBATCH --partition=cpu
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op ae6102764f69b3952b58f567f901ca9c

