#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/hybrid_op/e0d33b3299835e451f65f99a12303310"
#SBATCH --partition=cpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op ae6102764f69b3952b58f567f901ca9c

