#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/memory_op/b454e69a5e1823e752cef7fdeb885508"
#SBATCH --mem=512M
#SBATCH --partition=cpu
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op ae6102764f69b3952b58f567f901ca9c

