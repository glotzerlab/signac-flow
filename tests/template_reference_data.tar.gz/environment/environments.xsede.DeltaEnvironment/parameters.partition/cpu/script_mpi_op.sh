#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/mpi_op/74406f395431418361e51911f2f49c4c"
#SBATCH --partition=cpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op ae6102764f69b3952b58f567f901ca9c

