#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/multiline_cm/88426ef79ce0af1f27a825caa8330c17"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# echo "First line"
# echo "Second line"

