#!/bin/bash
#SBATCH --job-name="SubmissionTe/ae6102764f69b3952b58f567f901ca9c/omp_op/c964aa21250420dfdb2d359e3d4bcaa1"
#SBATCH --partition=cpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op ae6102764f69b3952b58f567f901ca9c

