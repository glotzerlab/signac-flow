#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/parallel_op/65e62349da1ee259e99257f77eaa1aa0"
#SBATCH --partition=cpu
#SBATCH --ntasks=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op ae6102764f69b3952b58f567f901ca9c

