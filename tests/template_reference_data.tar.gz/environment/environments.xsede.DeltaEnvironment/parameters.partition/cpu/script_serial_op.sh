#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/serial_op/bd8c8d814cec6cde7784e2e18758c1d1"
#SBATCH --partition=cpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op ae6102764f69b3952b58f567f901ca9c

