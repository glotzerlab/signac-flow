#!/bin/bash
#SBATCH --job-name="TestProject/ae6102764f69b3952b58f567f901ca9c/walltime_op/c1aaa8b175cc4bab5c95cf865bd8369f"
#SBATCH --partition=cpu
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(ae6102764f69b3952b58f567f901ca9c)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j ae6102764f69b3952b58f567f901ca9c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op ae6102764f69b3952b58f567f901ca9c

