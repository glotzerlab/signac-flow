#!/bin/bash
#SBATCH --job-name="TestProject/294201b5485c61a6ad70853d2ea0bd02/gpu_op/b3e5948d160316266123a67c87478c63"
#SBATCH --partition=gpuA100x4
#SBATCH --ntasks=2
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(294201b5485c61a6ad70853d2ea0bd02)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 294201b5485c61a6ad70853d2ea0bd02
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 294201b5485c61a6ad70853d2ea0bd02

