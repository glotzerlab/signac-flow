#!/bin/bash
#SBATCH --job-name="TestProject/294201b5485c61a6ad70853d2ea0bd02/mpi_gpu_op/470dcfe9c30b0c8a45a2c0de4e31dae3"
#SBATCH --partition=gpuA100x4
#SBATCH --ntasks=5
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(294201b5485c61a6ad70853d2ea0bd02)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 294201b5485c61a6ad70853d2ea0bd02
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 294201b5485c61a6ad70853d2ea0bd02

