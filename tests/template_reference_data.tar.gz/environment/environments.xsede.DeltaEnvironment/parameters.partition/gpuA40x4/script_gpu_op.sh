#!/bin/bash
#SBATCH --job-name="TestProject/e748493632e9e0b4a33992b4f26c532a/gpu_op/4575ce3d075d60e2ba7cbb6991f143ba"
#SBATCH --partition=gpuA40x4
#SBATCH --ntasks=2
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(e748493632e9e0b4a33992b4f26c532a)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j e748493632e9e0b4a33992b4f26c532a
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op e748493632e9e0b4a33992b4f26c532a

