#!/bin/bash
#SBATCH --job-name="TestProject/e748493632e9e0b4a33992b4f26c532a/mpi_gpu_op/58ca89cbc96906f8aa040c7bcd22c523"
#SBATCH --partition=gpuA40x4
#SBATCH --ntasks=5
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(e748493632e9e0b4a33992b4f26c532a)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j e748493632e9e0b4a33992b4f26c532a
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op e748493632e9e0b4a33992b4f26c532a

