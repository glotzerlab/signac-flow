#!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/memory_oppar/5fa1a8223edea847eb006b3333e0b80e"
#SBATCH --mem=512M
#SBATCH --partition=compute
#SBATCH -t 01:00:00
 
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op efde390daf4cf9a8d4b04534c2cf4430
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op efde390daf4cf9a8d4b04534c2cf4430
# /usr/local/bin/python generate_template_reference_data.py exec memory_op efde390daf4cf9a8d4b04534c2cf4430
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op efde390daf4cf9a8d4b04534c2cf4430

