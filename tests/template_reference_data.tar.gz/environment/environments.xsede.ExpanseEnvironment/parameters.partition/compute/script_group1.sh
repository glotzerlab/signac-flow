#!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/memory_oppar/b7fef663096913867b8f39f6d52077dc"
#SBATCH --mem=512M
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op efde390daf4cf9a8d4b04534c2cf4430
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op efde390daf4cf9a8d4b04534c2cf4430
# /usr/local/bin/python generate_template_reference_data.py exec memory_op efde390daf4cf9a8d4b04534c2cf4430
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op efde390daf4cf9a8d4b04534c2cf4430

