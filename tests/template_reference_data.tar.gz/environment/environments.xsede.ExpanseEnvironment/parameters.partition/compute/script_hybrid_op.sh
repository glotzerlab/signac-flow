#!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/hybrid_op/2137bed5d4c3ba3e8e6c851859e246bd"
#SBATCH --partition=compute
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op efde390daf4cf9a8d4b04534c2cf4430

