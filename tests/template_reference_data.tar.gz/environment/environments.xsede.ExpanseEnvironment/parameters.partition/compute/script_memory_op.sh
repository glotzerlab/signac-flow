#!/bin/bash
#SBATCH --job-name="TestProject/efde390daf4cf9a8d4b04534c2cf4430/memory_op/55c40edaa0b0bec22878353be2146c44"
#SBATCH --mem=512M
#SBATCH --partition=compute
#SBATCH -N 1
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op efde390daf4cf9a8d4b04534c2cf4430

