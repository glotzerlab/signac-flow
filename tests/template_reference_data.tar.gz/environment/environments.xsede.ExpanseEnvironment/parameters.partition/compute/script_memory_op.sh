    #!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/memory_op/e0fe8fd4409cfbbb093d019900f78487"
#SBATCH --mem=512M
#SBATCH --partition=compute

#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op efde390daf4cf9a8d4b04534c2cf4430

