#!/bin/bash
#SBATCH --job-name="TestProject/efde390daf4cf9a8d4b04534c2cf4430/mpi_op/ab53436efbe37a34a8aa9290bb5cf063"
#SBATCH --partition=compute
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op efde390daf4cf9a8d4b04534c2cf4430

