    #!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/multiline_cm/54c6a30918d0cb66550afa46e876b6a9"
#SBATCH --partition=compute

#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# echo "First line"
# echo "Second line"

