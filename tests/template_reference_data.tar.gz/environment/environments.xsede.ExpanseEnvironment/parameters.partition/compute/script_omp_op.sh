    #!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/omp_op/8650d7a41463ac9a7a6e126b929b2614"
#SBATCH --partition=compute

#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd "/home/user/project/"

# omp_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op efde390daf4cf9a8d4b04534c2cf4430

