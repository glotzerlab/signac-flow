    #!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/omp_op/36c001d9d222bf8973a8fdf87579bbe0"
#SBATCH --partition=compute

#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op efde390daf4cf9a8d4b04534c2cf4430

