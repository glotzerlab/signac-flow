#!/bin/bash
#SBATCH --job-name="TestProject/efde390daf4cf9a8d4b04534c2cf4430/parallel_op/8ba5ef2fec3ecdc7de4ba9082d52c994"
#SBATCH --partition=compute
#SBATCH -N 1
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op efde390daf4cf9a8d4b04534c2cf4430

