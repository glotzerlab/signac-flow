    #!/bin/bash
#SBATCH --job-name="SubmissionTe/efde390daf4cf9a8d4b04534c2cf4430/parallel_op/b599976b9bb4a2dad0b0adddc9014b45"
#SBATCH --partition=compute

#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd "/home/user/project/"

# parallel_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op efde390daf4cf9a8d4b04534c2cf4430

