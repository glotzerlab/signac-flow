#!/bin/bash
#SBATCH --job-name="TestProject/efde390daf4cf9a8d4b04534c2cf4430/serial_op/e1807be04c0149773062f48d63cde5ec"
#SBATCH --partition=compute
#SBATCH -N 1
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(efde390daf4cf9a8d4b04534c2cf4430)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j efde390daf4cf9a8d4b04534c2cf4430
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op efde390daf4cf9a8d4b04534c2cf4430

