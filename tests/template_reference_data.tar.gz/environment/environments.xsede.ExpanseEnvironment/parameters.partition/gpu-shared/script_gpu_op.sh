    #!/bin/bash
#SBATCH --job-name="SubmissionTe/9e819d3c00b8bb203f10e3a000a2922d/gpu_op/067adbfcd1d1718822558e4c61244a90"
#SBATCH --partition=gpu-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd "/home/user/project/"

# gpu_op(9e819d3c00b8bb203f10e3a000a2922d)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 9e819d3c00b8bb203f10e3a000a2922d
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 9e819d3c00b8bb203f10e3a000a2922d

