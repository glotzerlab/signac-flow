#!/bin/bash
#SBATCH --job-name="TestProject/9e819d3c00b8bb203f10e3a000a2922d/gpu_op/7aaf190d1158ed7a2c50dcba1b7a894e"
#SBATCH --partition=gpu-shared
#SBATCH --ntasks=2
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(9e819d3c00b8bb203f10e3a000a2922d)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 9e819d3c00b8bb203f10e3a000a2922d
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 9e819d3c00b8bb203f10e3a000a2922d

