#!/bin/bash
#SBATCH --job-name="TestProject/9e819d3c00b8bb203f10e3a000a2922d/mpi_gpu_op/b3477a0ddd56e78fed70d7bca33847c5"
#SBATCH --partition=gpu-shared
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(9e819d3c00b8bb203f10e3a000a2922d)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 9e819d3c00b8bb203f10e3a000a2922d
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 9e819d3c00b8bb203f10e3a000a2922d

