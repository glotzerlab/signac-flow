#!/bin/bash
#SBATCH --job-name="TestProject/9e819d3c00b8bb203f10e3a000a2922d/mpi_gpu_op/b3477a0ddd56e78fed70d7bca33847c5"
#SBATCH --partition=gpu-shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(9e819d3c00b8bb203f10e3a000a2922d)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 9e819d3c00b8bb203f10e3a000a2922d
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 9e819d3c00b8bb203f10e3a000a2922d

