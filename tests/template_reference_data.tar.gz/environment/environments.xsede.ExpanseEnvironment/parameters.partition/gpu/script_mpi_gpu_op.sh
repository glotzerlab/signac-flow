#!/bin/bash
#SBATCH --job-name="SubmissionTe/d916440c00cd724531f041ee111276b5/mpi_gpu_op/a669d0ae6b20ee00991bb5ff75ecbe70"
#SBATCH --partition=gpu
 
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(d916440c00cd724531f041ee111276b5)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j d916440c00cd724531f041ee111276b5
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op d916440c00cd724531f041ee111276b5

