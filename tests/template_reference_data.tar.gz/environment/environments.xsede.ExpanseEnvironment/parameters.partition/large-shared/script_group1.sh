    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/memory_oppar/e3f3cbb05934b18707114fce57893381"
#SBATCH --mem=512M
#SBATCH --partition=large-shared
#SBATCH -t 01:00:00

#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd "/home/user/project/"

# group1(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1afbbe096a620f35c624e6858be22bfb
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 1afbbe096a620f35c624e6858be22bfb
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1afbbe096a620f35c624e6858be22bfb
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 1afbbe096a620f35c624e6858be22bfb

