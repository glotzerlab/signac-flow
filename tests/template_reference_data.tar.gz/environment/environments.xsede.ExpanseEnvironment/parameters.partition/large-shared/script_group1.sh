#!/bin/bash
#SBATCH --job-name="TestProject/1afbbe096a620f35c624e6858be22bfb/memory_oppar/b3dd8326475879758500025c7ad6f79a"
#SBATCH --mem=512M
#SBATCH --partition=large-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1afbbe096a620f35c624e6858be22bfb
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 1afbbe096a620f35c624e6858be22bfb
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1afbbe096a620f35c624e6858be22bfb
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 1afbbe096a620f35c624e6858be22bfb

