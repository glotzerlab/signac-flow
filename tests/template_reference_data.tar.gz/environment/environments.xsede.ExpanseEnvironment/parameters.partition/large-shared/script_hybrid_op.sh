    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/hybrid_op/269c9a06b11503461b13f8e03ead4eb8"
#SBATCH --partition=large-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# hybrid_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 1afbbe096a620f35c624e6858be22bfb

