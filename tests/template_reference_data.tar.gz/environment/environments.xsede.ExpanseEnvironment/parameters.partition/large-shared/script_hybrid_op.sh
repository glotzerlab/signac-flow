    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/hybrid_op/bd76aa105b562d5ce9e15e8421c604c5"
#SBATCH --partition=large-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 1afbbe096a620f35c624e6858be22bfb

