#!/bin/bash
#SBATCH --job-name="TestProject/1afbbe096a620f35c624e6858be22bfb/memory_op/e2ca75756b8de0a07e609acc16c40ada"
#SBATCH --mem=512M
#SBATCH --partition=large-shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1afbbe096a620f35c624e6858be22bfb

