    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/memory_op/389e356852f5456fd8c2567f33fe5c4e"
#SBATCH --mem=512M
#SBATCH --partition=large-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd "/home/user/project/"

# memory_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1afbbe096a620f35c624e6858be22bfb

