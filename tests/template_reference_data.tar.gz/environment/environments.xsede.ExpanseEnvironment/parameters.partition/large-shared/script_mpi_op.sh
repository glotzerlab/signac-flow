#!/bin/bash
#SBATCH --job-name="TestProject/1afbbe096a620f35c624e6858be22bfb/mpi_op/12bab4de53416fb8e451c42450de6e0c"
#SBATCH --partition=large-shared
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 1afbbe096a620f35c624e6858be22bfb

