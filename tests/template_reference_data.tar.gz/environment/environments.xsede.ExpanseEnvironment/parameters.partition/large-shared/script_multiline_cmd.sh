    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/multiline_cm/32951519723ad7fd4ceaf76abfe5651e"
#SBATCH --partition=large-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd "/home/user/project/"

# multiline_cmd(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# echo "First line"
# echo "Second line"

