#!/bin/bash
#SBATCH --job-name="TestProject/1afbbe096a620f35c624e6858be22bfb/multiline_cm/77f02a91cbd9f8e80819672c4a699a29"
#SBATCH --partition=large-shared
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# echo "First line"
# echo "Second line"

