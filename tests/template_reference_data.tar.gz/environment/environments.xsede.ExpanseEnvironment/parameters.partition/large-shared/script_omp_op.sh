    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/omp_op/c70727b9934c5e38f79341f40f3ac972"
#SBATCH --partition=large-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd "/home/user/project/"

# omp_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 1afbbe096a620f35c624e6858be22bfb

