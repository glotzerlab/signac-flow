#!/bin/bash
#SBATCH --job-name="TestProject/1afbbe096a620f35c624e6858be22bfb/omp_op/9900a8e24f650a8e66f8a5ae4a457f18"
#SBATCH --partition=large-shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 1afbbe096a620f35c624e6858be22bfb

