    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/parallel_op/1b9a7e46d0f2258bb49ae5c5055f63b3"
#SBATCH --partition=large-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd "/home/user/project/"

# parallel_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 1afbbe096a620f35c624e6858be22bfb

