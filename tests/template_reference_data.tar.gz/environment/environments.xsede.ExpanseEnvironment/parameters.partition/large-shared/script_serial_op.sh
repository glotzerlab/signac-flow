    #!/bin/bash
#SBATCH --job-name="SubmissionTe/1afbbe096a620f35c624e6858be22bfb/serial_op/a43a844c76bb28ff0a5e0b9ca60717ab"
#SBATCH --partition=large-shared

#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1afbbe096a620f35c624e6858be22bfb

