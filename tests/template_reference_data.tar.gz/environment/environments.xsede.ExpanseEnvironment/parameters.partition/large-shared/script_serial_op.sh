#!/bin/bash
#SBATCH --job-name="TestProject/1afbbe096a620f35c624e6858be22bfb/serial_op/5d6dfeaa64695b944ab65edf66d101b6"
#SBATCH --partition=large-shared
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1afbbe096a620f35c624e6858be22bfb

