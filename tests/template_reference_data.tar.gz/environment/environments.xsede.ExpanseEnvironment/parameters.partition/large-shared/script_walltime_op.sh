#!/bin/bash
#SBATCH --job-name="TestProject/1afbbe096a620f35c624e6858be22bfb/walltime_op/ac9f26984689b1bbd4863498c0584ac5"
#SBATCH --partition=large-shared
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(1afbbe096a620f35c624e6858be22bfb)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 1afbbe096a620f35c624e6858be22bfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 1afbbe096a620f35c624e6858be22bfb

