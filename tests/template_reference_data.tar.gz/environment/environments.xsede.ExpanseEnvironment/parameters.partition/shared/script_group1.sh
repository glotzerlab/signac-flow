#!/bin/bash
#SBATCH --job-name="TestProject/c211c885918519fff29728b2ae74d90c/memory_oppar/937cc4af1e2c84da03efcbeb20153b6d"
#SBATCH --mem=512M
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --ntasks=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c211c885918519fff29728b2ae74d90c
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c211c885918519fff29728b2ae74d90c
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c211c885918519fff29728b2ae74d90c
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c211c885918519fff29728b2ae74d90c

