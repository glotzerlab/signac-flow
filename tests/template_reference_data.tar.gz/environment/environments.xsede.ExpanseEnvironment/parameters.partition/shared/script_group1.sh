    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/memory_oppar/1eb8ae93a8463168c08d45fab08e0611"
#SBATCH --mem=512M
#SBATCH --partition=shared
#SBATCH -t 01:00:00

#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# group1(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c211c885918519fff29728b2ae74d90c
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c211c885918519fff29728b2ae74d90c
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c211c885918519fff29728b2ae74d90c
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c211c885918519fff29728b2ae74d90c

