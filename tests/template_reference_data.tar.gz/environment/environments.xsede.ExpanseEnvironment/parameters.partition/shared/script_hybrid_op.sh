    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/hybrid_op/9801ae30fc820dec182dabf0357bcd36"
#SBATCH --partition=shared

#SBATCH -N 1
#SBATCH --ntasks=20

set -e
set -u

cd /home/user/project/

# hybrid_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op c211c885918519fff29728b2ae74d90c

