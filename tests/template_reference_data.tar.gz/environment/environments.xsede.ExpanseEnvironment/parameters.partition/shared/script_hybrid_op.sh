#!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/hybrid_op/7635ff88cbb875da28e87331a448fa14"
#SBATCH --partition=shared
#SBATCH -N 1
#SBATCH --ntasks=20

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op c211c885918519fff29728b2ae74d90c

