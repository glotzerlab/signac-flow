#!/bin/bash
#SBATCH --job-name="TestProject/c211c885918519fff29728b2ae74d90c/memory_op/b6fbc9e9489345ffd7cf22ac332d21e0"
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op c211c885918519fff29728b2ae74d90c

