    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/memory_op/5dd693461b61312796791ff9bc9ed401"
#SBATCH --mem=512M
#SBATCH --partition=shared

#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/project/"

# memory_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op c211c885918519fff29728b2ae74d90c

