    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/mpi_op/fb108f9ce3f0c5c4c91d6452f17778e7"
#SBATCH --partition=shared

#SBATCH -N 1
#SBATCH --ntasks=5

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# mpi_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op c211c885918519fff29728b2ae74d90c

