    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/mpi_op/81fbd4504a4d7c741a6ed5ebc11bb91d"
#SBATCH --partition=shared

#SBATCH -N 1
#SBATCH --ntasks=5

set -e
set -u

cd "/home/user/project/"

# mpi_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op c211c885918519fff29728b2ae74d90c

