#!/bin/bash
#SBATCH --job-name="TestProject/c211c885918519fff29728b2ae74d90c/multiline_cm/1fd9e576e7bf336081e2dd4d874eafee"
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# echo "First line"
# echo "Second line"

