#!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/multiline_cm/8bd4afd4fbfddd19aec5a751a50889b4"
#SBATCH --partition=shared
 
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# echo "First line"
# echo "Second line"

