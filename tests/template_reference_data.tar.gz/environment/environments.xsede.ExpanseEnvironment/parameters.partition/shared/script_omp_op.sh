    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/omp_op/1f413d4e0af9f3b9b22a422b299ee65e"
#SBATCH --partition=shared

#SBATCH -N 1
#SBATCH --ntasks=4

set -e
set -u

cd /home/user/project/

# omp_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op c211c885918519fff29728b2ae74d90c

