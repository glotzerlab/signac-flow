#!/bin/bash
#SBATCH --job-name="TestProject/c211c885918519fff29728b2ae74d90c/omp_op/92936b0d4585523f4ed37b26e1e9a8cd"
#SBATCH --partition=shared
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op c211c885918519fff29728b2ae74d90c

