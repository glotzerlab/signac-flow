    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/parallel_op/16eba5e4f5b90f630b332df8176f402a"
#SBATCH --partition=shared

#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd "/home/user/project/"

# parallel_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c211c885918519fff29728b2ae74d90c

