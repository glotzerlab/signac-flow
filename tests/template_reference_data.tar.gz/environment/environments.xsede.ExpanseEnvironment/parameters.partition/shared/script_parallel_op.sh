#!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/parallel_op/8e2ee54c242ee52f8d6b7a9ca01c73b0"
#SBATCH --partition=shared
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op c211c885918519fff29728b2ae74d90c

