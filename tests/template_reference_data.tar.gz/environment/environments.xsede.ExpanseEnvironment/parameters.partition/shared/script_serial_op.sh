    #!/bin/bash
#SBATCH --job-name="SubmissionTe/c211c885918519fff29728b2ae74d90c/serial_op/80a25e8a2e02405978679e428d55e846"
#SBATCH --partition=shared

#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/project/"

# serial_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op c211c885918519fff29728b2ae74d90c

