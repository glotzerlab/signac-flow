#!/bin/bash
#SBATCH --job-name="TestProject/c211c885918519fff29728b2ae74d90c/walltime_op/663ed5eb8054aaf3f1c62350255ec666"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(c211c885918519fff29728b2ae74d90c)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j c211c885918519fff29728b2ae74d90c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op c211c885918519fff29728b2ae74d90c

