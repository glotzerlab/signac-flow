#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/memory_oppar/db581e8f26ac54b24b41700cdd86da04"
#SBATCH --mem=512M
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# group1(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8003786b1a06cc91021f09a51d2ee8de
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8003786b1a06cc91021f09a51d2ee8de
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 8003786b1a06cc91021f09a51d2ee8de
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 8003786b1a06cc91021f09a51d2ee8de


