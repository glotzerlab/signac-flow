#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/memory_op/07467957bc6c28c76d6781b5c9a60829"
#SBATCH --mem=0.5G
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# memory_op(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 8003786b1a06cc91021f09a51d2ee8de


