#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/mpi_op/c7abb661e11048d2febf145dc73bbf92"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd "/home/user/project/"

# mpi_op(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# ibrun -n 5 -o 0 task_affinity  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 8003786b1a06cc91021f09a51d2ee8de


