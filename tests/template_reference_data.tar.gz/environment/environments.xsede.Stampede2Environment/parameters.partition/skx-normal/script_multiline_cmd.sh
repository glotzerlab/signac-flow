#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/multiline_cm/b5e6c230232b83e42b283b3ce887549a"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# echo "First line"
# echo "Second line"


