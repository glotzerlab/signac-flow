#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/omp_op/6a99df4acff48b43d6be3ba889706a2b"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# omp_op(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 8003786b1a06cc91021f09a51d2ee8de


