#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/parallel_op/14ab3cd45653cb2df9fbce4419fde69f"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/project/"

# parallel_op(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8003786b1a06cc91021f09a51d2ee8de


