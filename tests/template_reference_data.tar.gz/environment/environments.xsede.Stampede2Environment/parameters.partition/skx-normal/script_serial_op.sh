#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/serial_op/e1ef696324a9b968a3d7f1155824d9ab"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# serial_op(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8003786b1a06cc91021f09a51d2ee8de


