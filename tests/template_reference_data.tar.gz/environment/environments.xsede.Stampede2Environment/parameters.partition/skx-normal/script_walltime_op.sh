#!/bin/bash
#SBATCH --job-name="SubmissionTe/8003786b1a06cc91021f09a51d2ee8de/walltime_op/2ab89b3a86cd15ce0534b0ec5c9955a6"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# walltime_op(8003786b1a06cc91021f09a51d2ee8de)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 8003786b1a06cc91021f09a51d2ee8de
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 8003786b1a06cc91021f09a51d2ee8de


