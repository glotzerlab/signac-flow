#!/bin/bash
#SBATCH --job-name="TestProject/bundle/6cf3ea9f82cf2c9324cc710f219fc725cdcfec5b"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(4be2d42ad74a7039bdb6a402abc19afb)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 4be2d42ad74a7039bdb6a402abc19afb
# Eligible to run:
# srun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 4be2d42ad74a7039bdb6a402abc19afb

# omp_op(4be2d42ad74a7039bdb6a402abc19afb)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 4be2d42ad74a7039bdb6a402abc19afb
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 4be2d42ad74a7039bdb6a402abc19afb

