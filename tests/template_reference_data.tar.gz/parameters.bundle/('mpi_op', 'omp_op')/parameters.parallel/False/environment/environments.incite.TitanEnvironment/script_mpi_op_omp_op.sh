#PBS -N SubmissionTest/bundle/eda429c11796961775fb2a7c0e2b78eab6bdc0f2
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(b293e1851c5881828462bb7a06dce02c)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op b293e1851c5881828462bb7a06dce02c

# omp_op(b293e1851c5881828462bb7a06dce02c)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op b293e1851c5881828462bb7a06dce02c

