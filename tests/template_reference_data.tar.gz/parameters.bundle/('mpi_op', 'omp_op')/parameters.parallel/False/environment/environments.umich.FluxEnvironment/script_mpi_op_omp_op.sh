#PBS -N SubmissionTest/bundle/ed2f1a518d5143e886ca58b19d63d8a461e247ac
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_op(97fb213cec4e13f4044d47f5df1e217d)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 97fb213cec4e13f4044d47f5df1e217d

# omp_op(97fb213cec4e13f4044d47f5df1e217d)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 97fb213cec4e13f4044d47f5df1e217d

