#!/bin/bash
#SBATCH --job-name="TestProject/bundle/cba417c9ab6c0ff07d0017442fd846b294728892"
#SBATCH --partition=standard
#SBATCH --nodes=1-1
#SBATCH --ntasks=5
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(7441eb4c64c1e8ebac38c41ffe945c97)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 7441eb4c64c1e8ebac38c41ffe945c97
# Eligible to run:
# srun -u --export=ALL -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 7441eb4c64c1e8ebac38c41ffe945c97

# omp_op(7441eb4c64c1e8ebac38c41ffe945c97)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 7441eb4c64c1e8ebac38c41ffe945c97
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 7441eb4c64c1e8ebac38c41ffe945c97

