#!/bin/bash
#SBATCH --job-name="TestProject/bundle/23649c398203ef6761b2297b543b0ca3168a9771"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(a9049bd72bc8dd97cd1f92c20b1422c8)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a9049bd72bc8dd97cd1f92c20b1422c8 &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op a9049bd72bc8dd97cd1f92c20b1422c8

# omp_op(a9049bd72bc8dd97cd1f92c20b1422c8)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a9049bd72bc8dd97cd1f92c20b1422c8 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op a9049bd72bc8dd97cd1f92c20b1422c8
wait

