#PBS -N SubmissionTest/bundle/a73a11851d20206f912ac1021b8eb9382248cc21
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(def67f27e79966e068d16dcf943a7921)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op def67f27e79966e068d16dcf943a7921 &

# omp_op(def67f27e79966e068d16dcf943a7921)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op def67f27e79966e068d16dcf943a7921 &
wait

