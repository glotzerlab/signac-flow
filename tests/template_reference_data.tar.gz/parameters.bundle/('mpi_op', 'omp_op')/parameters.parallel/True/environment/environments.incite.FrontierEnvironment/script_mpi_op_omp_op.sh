#!/bin/bash
#SBATCH --job-name="TestProject/bundle/df3dd5dc576e0928170b6b0e771795fea99aeab1"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(89c8e553d8cddce838bce293c3cbd437)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 89c8e553d8cddce838bce293c3cbd437 &
# Eligible to run:
# srun --ntasks=5 --cpus-per-task=1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 89c8e553d8cddce838bce293c3cbd437

# omp_op(89c8e553d8cddce838bce293c3cbd437)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 89c8e553d8cddce838bce293c3cbd437 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 89c8e553d8cddce838bce293c3cbd437
wait

