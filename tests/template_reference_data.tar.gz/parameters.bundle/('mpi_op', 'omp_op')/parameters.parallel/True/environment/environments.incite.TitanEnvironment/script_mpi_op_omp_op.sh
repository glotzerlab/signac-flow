#PBS -N SubmissionTest/bundle/03ab5bc31d2f1a10b34a7ea23d8b88d69b7f34e5
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(29110bb20bd8a85768c9201d72139c85)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 29110bb20bd8a85768c9201d72139c85 &

# omp_op(29110bb20bd8a85768c9201d72139c85)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 29110bb20bd8a85768c9201d72139c85 &
wait

