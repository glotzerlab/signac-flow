#PBS -N SubmissionTest/bundle/a313bdd5c96e41d5dc1956bc60f47573d9b61fcd
#PBS -V
#PBS -l nodes=4
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_op(4337ec17629a91d60dd5750b224ebedc)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 4337ec17629a91d60dd5750b224ebedc &

# omp_op(4337ec17629a91d60dd5750b224ebedc)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 4337ec17629a91d60dd5750b224ebedc &
wait

