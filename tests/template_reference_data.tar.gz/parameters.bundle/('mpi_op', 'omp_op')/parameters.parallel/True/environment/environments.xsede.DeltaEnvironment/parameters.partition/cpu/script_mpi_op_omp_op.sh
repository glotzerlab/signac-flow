#!/bin/bash
#SBATCH --job-name="TestProject/bundle/bf09e7e04e2d688c146a263d92557e28879b43bd"
#SBATCH --partition=cpu
#SBATCH --ntasks=9

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(028808e9c43d54d9db228a3294b2a482)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 028808e9c43d54d9db228a3294b2a482 &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 028808e9c43d54d9db228a3294b2a482

# omp_op(028808e9c43d54d9db228a3294b2a482)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 028808e9c43d54d9db228a3294b2a482 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 028808e9c43d54d9db228a3294b2a482
wait

