#!/bin/bash
#SBATCH --job-name="TestProject/bundle/683d1f5fd52d0d1d52fd92654277f84413488e4e"
#SBATCH --partition=compute
#SBATCH -N 1
#SBATCH --ntasks=9

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(40830f58f9ee1dec7e88896065f6383d)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 40830f58f9ee1dec7e88896065f6383d &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 40830f58f9ee1dec7e88896065f6383d

# omp_op(40830f58f9ee1dec7e88896065f6383d)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 40830f58f9ee1dec7e88896065f6383d &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 40830f58f9ee1dec7e88896065f6383d
wait

