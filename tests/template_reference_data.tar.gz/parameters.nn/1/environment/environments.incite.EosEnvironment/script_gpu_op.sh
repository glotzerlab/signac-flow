#PBS -N SubmissionTe/118f4f3c/gpu_op/0000/e543cee0245b2fe7655cca3691a4eabc
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# gpu_op(118f4f3ccfae13a187ade1247f33dd3c)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 118f4f3ccfae13a187ade1247f33dd3c

