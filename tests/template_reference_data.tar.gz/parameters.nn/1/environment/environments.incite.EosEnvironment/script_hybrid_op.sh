#PBS -N SubmissionTe/118f4f3c/hybrid_op/0000/61d927d469207497f569f8f1b1fc00d4
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(118f4f3ccfae13a187ade1247f33dd3c)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 118f4f3ccfae13a187ade1247f33dd3c

