#PBS -N SubmissionTe/118f4f3c/mpi_gpu_op/0000/3ae67e828ef23e0a61d4f1a028bea980
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(118f4f3ccfae13a187ade1247f33dd3c)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 118f4f3ccfae13a187ade1247f33dd3c

