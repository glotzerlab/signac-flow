#PBS -N SubmissionTe/118f4f3c/mpi_op/0000/53c4d82e392b1554a94a3ea4adc38209
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(118f4f3ccfae13a187ade1247f33dd3c)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 118f4f3ccfae13a187ade1247f33dd3c

