#PBS -N SubmissionTe/118f4f3c/omp_op/0000/1739c539b9e2177fbcd6fc20cded6804
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(118f4f3ccfae13a187ade1247f33dd3c)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 118f4f3ccfae13a187ade1247f33dd3c

