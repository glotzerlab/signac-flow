#PBS -N SubmissionTe/118f4f3c/parallel_op/0000/fec284dde455e1a9751fafbe8c948337
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# parallel_op(118f4f3ccfae13a187ade1247f33dd3c)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 118f4f3ccfae13a187ade1247f33dd3c

