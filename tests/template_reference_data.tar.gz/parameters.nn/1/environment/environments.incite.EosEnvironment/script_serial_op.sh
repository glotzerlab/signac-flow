#PBS -N SubmissionTe/118f4f3c/serial_op/0000/79aaaf59f9d8786f79f051b3496c65d2
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(118f4f3ccfae13a187ade1247f33dd3c)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 118f4f3ccfae13a187ade1247f33dd3c

