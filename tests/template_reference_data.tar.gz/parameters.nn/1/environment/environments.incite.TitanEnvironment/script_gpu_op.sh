#PBS -N SubmissionTe/73fac832/gpu_op/0000/25fb572407655648d415011bfac64964
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# gpu_op(73fac8326acefd5bce115ce05ed77895)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 73fac8326acefd5bce115ce05ed77895

