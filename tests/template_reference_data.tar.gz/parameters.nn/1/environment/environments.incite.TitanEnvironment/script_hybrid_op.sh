#PBS -N SubmissionTe/73fac832/hybrid_op/0000/007c90f86a463f3832d05ead3eb14edc
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(73fac8326acefd5bce115ce05ed77895)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 73fac8326acefd5bce115ce05ed77895

