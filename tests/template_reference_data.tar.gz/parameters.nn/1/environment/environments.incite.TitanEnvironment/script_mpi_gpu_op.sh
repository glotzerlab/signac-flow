#PBS -N SubmissionTe/73fac832/mpi_gpu_op/0000/aaddf0a8ed2fcbe67fa9419bfd31a98a
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(73fac8326acefd5bce115ce05ed77895)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 73fac8326acefd5bce115ce05ed77895

