#PBS -N SubmissionTe/73fac832/omp_op/0000/cccf730be8b96d8b63de792972276e38
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(73fac8326acefd5bce115ce05ed77895)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 73fac8326acefd5bce115ce05ed77895

