#PBS -N SubmissionTe/73fac832/parallel_op/0000/eef7d82f91d3e290a3040d457425ab9e
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# parallel_op(73fac8326acefd5bce115ce05ed77895)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 73fac8326acefd5bce115ce05ed77895

