#PBS -N SubmissionTe/73fac832/serial_op/0000/a7f4acfe33bab816085effcefd24be2b
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(73fac8326acefd5bce115ce05ed77895)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 73fac8326acefd5bce115ce05ed77895

