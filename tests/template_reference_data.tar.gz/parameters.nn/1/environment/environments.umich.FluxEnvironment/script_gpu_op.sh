#PBS -N SubmissionTe/8f195d74/gpu_op/0000/a1545e04c93b78589d780d7b937d327b
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# gpu_op(8f195d7498eca1fdf5215f4d03f26590)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 8f195d7498eca1fdf5215f4d03f26590

