#PBS -N SubmissionTe/8f195d74/hybrid_op/0000/ae6c196f212bbe65628c310545f52d6a
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(8f195d7498eca1fdf5215f4d03f26590)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 8f195d7498eca1fdf5215f4d03f26590

