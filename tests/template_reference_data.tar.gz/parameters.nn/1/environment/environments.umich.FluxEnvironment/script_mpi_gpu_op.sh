#PBS -N SubmissionTe/8f195d74/mpi_gpu_op/0000/6c6683c94bf0d9f79cf057d12e92e764
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(8f195d7498eca1fdf5215f4d03f26590)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 8f195d7498eca1fdf5215f4d03f26590

