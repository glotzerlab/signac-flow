#PBS -N SubmissionTe/8f195d74/mpi_op/0000/5e625d55c32f800879bb10c8fb32e9eb
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_op(8f195d7498eca1fdf5215f4d03f26590)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 8f195d7498eca1fdf5215f4d03f26590

