#PBS -N SubmissionTe/8f195d74/parallel_op/0000/068e57c6189fd19897720f986a4ade1d
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# parallel_op(8f195d7498eca1fdf5215f4d03f26590)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 8f195d7498eca1fdf5215f4d03f26590

