#PBS -N SubmissionTe/8f195d74/serial_op/0000/b60e0a633bdb7ff4644d73b0f8a1d69d
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# serial_op(8f195d7498eca1fdf5215f4d03f26590)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 8f195d7498eca1fdf5215f4d03f26590

