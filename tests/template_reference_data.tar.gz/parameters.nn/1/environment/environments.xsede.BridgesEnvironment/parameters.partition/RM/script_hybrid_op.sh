#!/bin/bash
#SBATCH --job-name="SubmissionTe/f3fa47ca/hybrid_op/0000/fe25b0e2a38ce70c8598b68a2afa5651"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(f3fa47caf345d14c4c9ccb604b76f2e3)
export OMP_NUM_THREADS=2
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op f3fa47caf345d14c4c9ccb604b76f2e3

