#!/bin/bash
#SBATCH --job-name="SubmissionTe/f3fa47ca/mpi_op/0000/983d4822be3fd80c15bffd7302efba08"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(f3fa47caf345d14c4c9ccb604b76f2e3)
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op f3fa47caf345d14c4c9ccb604b76f2e3

