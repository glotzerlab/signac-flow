#!/bin/bash
#SBATCH --job-name="SubmissionTe/f3fa47ca/omp_op/0000/98877819fb37aebb38e3390e5473a405"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# omp_op(f3fa47caf345d14c4c9ccb604b76f2e3)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op f3fa47caf345d14c4c9ccb604b76f2e3

