#!/bin/bash
#SBATCH --job-name="SubmissionTe/f3fa47ca/parallel_op/0000/830a20b5856f0889b060011c563c9657"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(f3fa47caf345d14c4c9ccb604b76f2e3)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op f3fa47caf345d14c4c9ccb604b76f2e3

