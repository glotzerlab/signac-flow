#!/bin/bash
#SBATCH --job-name="SubmissionTe/f3fa47ca/serial_op/0000/c1154990c1ce3861e4fc33d9a363cec4"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 1

set -e
set -u

cd /home/johndoe/project/

# serial_op(f3fa47caf345d14c4c9ccb604b76f2e3)
/usr/local/bin/python generate_template_reference_data.py exec serial_op f3fa47caf345d14c4c9ccb604b76f2e3

