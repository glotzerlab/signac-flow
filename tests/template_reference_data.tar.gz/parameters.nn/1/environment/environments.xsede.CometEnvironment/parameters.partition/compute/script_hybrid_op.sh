#!/bin/bash
#SBATCH --job-name="SubmissionTe/1fe75367/hybrid_op/0000/05b17ecedc7c229d6ee955819693af00"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(1fe753679fef722e7adca78b4ae843f2)
export OMP_NUM_THREADS=2
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 1fe753679fef722e7adca78b4ae843f2

