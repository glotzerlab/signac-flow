#!/bin/bash
#SBATCH --job-name="SubmissionTe/1fe75367/mpi_op/0000/390f81478f5e12632ed4a1746484c43b"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(1fe753679fef722e7adca78b4ae843f2)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 1fe753679fef722e7adca78b4ae843f2

