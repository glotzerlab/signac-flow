#!/bin/bash
#SBATCH --job-name="SubmissionTe/1fe75367/omp_op/0000/1df7a5efbcf7c8452da1320b5aaf016b"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# omp_op(1fe753679fef722e7adca78b4ae843f2)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 1fe753679fef722e7adca78b4ae843f2

