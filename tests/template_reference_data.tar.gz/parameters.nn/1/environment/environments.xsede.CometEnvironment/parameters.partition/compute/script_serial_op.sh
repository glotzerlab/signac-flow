#!/bin/bash
#SBATCH --job-name="SubmissionTe/1fe75367/serial_op/0000/5afa8368b851334cac82422a826ef141"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(1fe753679fef722e7adca78b4ae843f2)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 1fe753679fef722e7adca78b4ae843f2

