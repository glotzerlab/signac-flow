#!/bin/bash
#SBATCH --job-name="SubmissionTe/ee92e792/mpi_op/0000/1cbcc37cc152b8185f3b367d55ec97df"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# mpi_op(ee92e7925c96192c2c6e2bdebf490652)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op ee92e7925c96192c2c6e2bdebf490652

