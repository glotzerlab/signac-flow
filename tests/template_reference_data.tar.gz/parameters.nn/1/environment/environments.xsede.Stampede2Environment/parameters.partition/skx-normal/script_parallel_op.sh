#!/bin/bash
#SBATCH --job-name="SubmissionTe/ee92e792/parallel_op/0000/a13a954f522b954c46c29fbd87bff8db"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# parallel_op(ee92e7925c96192c2c6e2bdebf490652)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op ee92e7925c96192c2c6e2bdebf490652

