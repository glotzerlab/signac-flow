#!/bin/bash
#SBATCH --job-name="SubmissionTe/ee92e792/serial_op/0000/cc750f437c5c8810317768a6c5f20939"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# serial_op(ee92e7925c96192c2c6e2bdebf490652)
/usr/local/bin/python generate_template_reference_data.py exec serial_op ee92e7925c96192c2c6e2bdebf490652

