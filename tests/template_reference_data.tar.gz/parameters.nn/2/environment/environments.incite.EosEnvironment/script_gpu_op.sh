#PBS -N SubmissionTe/38dbccd7/gpu_op/0000/53c65025464f1b0092dfc7ee0d85f8be
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# gpu_op(38dbccd79e1d32d69930dd227fd250ae)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 38dbccd79e1d32d69930dd227fd250ae

