#PBS -N SubmissionTe/38dbccd7/hybrid_op/0000/13ac06c73c2b86ee0888bd2fcfec5208
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(38dbccd79e1d32d69930dd227fd250ae)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 38dbccd79e1d32d69930dd227fd250ae

