#PBS -N SubmissionTe/38dbccd7/hybrid_op/0000/
#PBS -V
#PBS -l nodes=2
export OMP_NUM_THREADS=2