#PBS -N SubmissionTe/38dbccd7/mpi_gpu_op/0000/e9a2789c34c0d7aaec67fafb84045400
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(38dbccd79e1d32d69930dd227fd250ae)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 38dbccd79e1d32d69930dd227fd250ae

