#PBS -N SubmissionTe/38dbccd7/mpi_op/0000/44521f5aab39a8cc88f39280a9e22c33
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(38dbccd79e1d32d69930dd227fd250ae)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 38dbccd79e1d32d69930dd227fd250ae

