#PBS -N SubmissionTe/38dbccd7/omp_op/0000/5d7ee6573459226d425eb47d702d334f
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# omp_op(38dbccd79e1d32d69930dd227fd250ae)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 38dbccd79e1d32d69930dd227fd250ae

