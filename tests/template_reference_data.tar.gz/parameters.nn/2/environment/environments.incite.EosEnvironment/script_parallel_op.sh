#PBS -N SubmissionTe/38dbccd7/parallel_op/0000/3aef1712c8418eb281c1173f77c60a3a
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(38dbccd79e1d32d69930dd227fd250ae)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 38dbccd79e1d32d69930dd227fd250ae

