#PBS -N SubmissionTe/38dbccd7/serial_op/0000/c3b40cf8f41c850554ed8c93b3400db5
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# serial_op(38dbccd79e1d32d69930dd227fd250ae)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 38dbccd79e1d32d69930dd227fd250ae

