#PBS -N SubmissionTe/3a4af2fe/gpu_op/0000/4eb9b6e4d73a55068ca67338036b2674
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# gpu_op(3a4af2feee66159a285a2d2de5f37293)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 3a4af2feee66159a285a2d2de5f37293

