#PBS -N SubmissionTe/3a4af2fe/hybrid_op/0000/30d9690d7338867f79d730dc29efc958
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(3a4af2feee66159a285a2d2de5f37293)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 3a4af2feee66159a285a2d2de5f37293

