#PBS -N SubmissionTe/3a4af2fe/mpi_gpu_op/0000/3f2d6d0fdc22ff5285795e4acd42dfc4
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(3a4af2feee66159a285a2d2de5f37293)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 3a4af2feee66159a285a2d2de5f37293

