#PBS -N SubmissionTe/3a4af2fe/mpi_op/0000/8f9f21e2cefb54c5c082bf6513911b85
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(3a4af2feee66159a285a2d2de5f37293)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 3a4af2feee66159a285a2d2de5f37293

