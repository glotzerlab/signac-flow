#PBS -N SubmissionTe/3a4af2fe/parallel_op/0000/f2e0a5f2ed92162a5f539732d55f9644
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(3a4af2feee66159a285a2d2de5f37293)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 3a4af2feee66159a285a2d2de5f37293

