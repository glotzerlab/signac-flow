#PBS -N SubmissionTe/3a4af2fe/serial_op/0000/4bc9788af404008c076015b9119c64ce
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# serial_op(3a4af2feee66159a285a2d2de5f37293)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 3a4af2feee66159a285a2d2de5f37293

