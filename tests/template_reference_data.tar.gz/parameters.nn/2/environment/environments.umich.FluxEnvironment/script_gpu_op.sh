#PBS -N SubmissionTe/3fa0a26f/gpu_op/0000/aec7ff2e5f994289227946cc9bca0780
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# gpu_op(3fa0a26faa0ceb2d07430b99af5a0e2b)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 3fa0a26faa0ceb2d07430b99af5a0e2b

