#PBS -N SubmissionTe/3fa0a26f/hybrid_op/0000/91fbf1a6e9d580eb9c42466ad86bb4d8
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(3fa0a26faa0ceb2d07430b99af5a0e2b)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 3fa0a26faa0ceb2d07430b99af5a0e2b

