#PBS -N SubmissionTe/3fa0a26f/omp_op/0000/574d7cbeec5c8b9ce15d60557c847a34
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# omp_op(3fa0a26faa0ceb2d07430b99af5a0e2b)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 3fa0a26faa0ceb2d07430b99af5a0e2b

