#PBS -N SubmissionTe/3fa0a26f/parallel_op/0000/3b7f6401d27000cafe016a01a3fa2275
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# parallel_op(3fa0a26faa0ceb2d07430b99af5a0e2b)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 3fa0a26faa0ceb2d07430b99af5a0e2b

