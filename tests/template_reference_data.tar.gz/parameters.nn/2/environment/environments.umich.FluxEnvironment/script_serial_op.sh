#PBS -N SubmissionTe/3fa0a26f/serial_op/0000/bd3f89c19f7b5acdf9734de4dfedab49
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# serial_op(3fa0a26faa0ceb2d07430b99af5a0e2b)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 3fa0a26faa0ceb2d07430b99af5a0e2b

