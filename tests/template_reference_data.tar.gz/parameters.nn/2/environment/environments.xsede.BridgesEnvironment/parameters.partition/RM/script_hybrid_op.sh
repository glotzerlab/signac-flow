#!/bin/bash
#SBATCH --job-name="SubmissionTe/aaac0fa7/hybrid_op/0000/c18d5658fbef0f507a93fe0795f89e41"
#SBATCH --partition=RM
#SBATCH -N 2
#SBATCH --ntasks-per-node 4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(aaac0fa77b8e5ac7392809bd53c13a74)
export OMP_NUM_THREADS=2
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op aaac0fa77b8e5ac7392809bd53c13a74

