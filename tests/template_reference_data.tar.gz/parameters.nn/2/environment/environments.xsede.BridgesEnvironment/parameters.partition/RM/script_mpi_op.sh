#!/bin/bash
#SBATCH --job-name="SubmissionTe/aaac0fa7/mpi_op/0000/f20213e755cbf5899c23fa76bbdba75d"
#SBATCH --partition=RM
#SBATCH -N 2
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(aaac0fa77b8e5ac7392809bd53c13a74)
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op aaac0fa77b8e5ac7392809bd53c13a74

