#!/bin/bash
#SBATCH --job-name="SubmissionTe/aaac0fa7/omp_op/0000/7a7e2121c2d788889d176fb5e575da4f"
#SBATCH --partition=RM
#SBATCH -N 2
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# omp_op(aaac0fa77b8e5ac7392809bd53c13a74)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op aaac0fa77b8e5ac7392809bd53c13a74

