#!/bin/bash
#SBATCH --job-name="SubmissionTe/aaac0fa7/parallel_op/0000/0ac7699ade6d7c71c985ce16a9a68d38"
#SBATCH --partition=RM
#SBATCH -N 2
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(aaac0fa77b8e5ac7392809bd53c13a74)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op aaac0fa77b8e5ac7392809bd53c13a74

