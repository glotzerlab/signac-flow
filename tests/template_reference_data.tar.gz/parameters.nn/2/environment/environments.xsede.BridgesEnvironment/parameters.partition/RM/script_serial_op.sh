#!/bin/bash
#SBATCH --job-name="SubmissionTe/aaac0fa7/serial_op/0000/1be33dec5a197744e55a7776e64d6da9"
#SBATCH --partition=RM
#SBATCH -N 2
#SBATCH --ntasks-per-node 1

set -e
set -u

cd /home/johndoe/project/

# serial_op(aaac0fa77b8e5ac7392809bd53c13a74)
/usr/local/bin/python generate_template_reference_data.py exec serial_op aaac0fa77b8e5ac7392809bd53c13a74

