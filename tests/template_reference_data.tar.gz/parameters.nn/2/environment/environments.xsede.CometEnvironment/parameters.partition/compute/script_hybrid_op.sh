#!/bin/bash
#SBATCH --job-name="SubmissionTe/e5515eac/hybrid_op/0000/31eb9b9695f686242e337e9620bfb290"
#SBATCH --partition=compute
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(e5515eac081f886786169793e9b96512)
export OMP_NUM_THREADS=2
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op e5515eac081f886786169793e9b96512

