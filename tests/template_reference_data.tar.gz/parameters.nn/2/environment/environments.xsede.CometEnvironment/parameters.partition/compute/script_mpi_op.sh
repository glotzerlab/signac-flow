#!/bin/bash
#SBATCH --job-name="SubmissionTe/e5515eac/mpi_op/0000/5ec3061ae50925fcf896723b8d8e354a"
#SBATCH --partition=compute
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(e5515eac081f886786169793e9b96512)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op e5515eac081f886786169793e9b96512

