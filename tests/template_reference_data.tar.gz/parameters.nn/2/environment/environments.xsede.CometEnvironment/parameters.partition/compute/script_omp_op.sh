#!/bin/bash
#SBATCH --job-name="SubmissionTe/e5515eac/omp_op/0000/3d089ec04d68a1991840669d230925fc"
#SBATCH --partition=compute
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# omp_op(e5515eac081f886786169793e9b96512)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op e5515eac081f886786169793e9b96512

