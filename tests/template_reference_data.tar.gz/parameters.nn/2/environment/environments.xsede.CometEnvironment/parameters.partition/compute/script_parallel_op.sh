#!/bin/bash
#SBATCH --job-name="SubmissionTe/e5515eac/parallel_op/0000/6114f2489bb80895321a6dbdcd5a4eb9"
#SBATCH --partition=compute
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(e5515eac081f886786169793e9b96512)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op e5515eac081f886786169793e9b96512

