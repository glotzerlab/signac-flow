#!/bin/bash
#SBATCH --job-name="SubmissionTe/e5515eac/serial_op/0000/67b18fa8fe3f631e57b0ca27f9053f3a"
#SBATCH --partition=compute
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(e5515eac081f886786169793e9b96512)
/usr/local/bin/python generate_template_reference_data.py exec serial_op e5515eac081f886786169793e9b96512

