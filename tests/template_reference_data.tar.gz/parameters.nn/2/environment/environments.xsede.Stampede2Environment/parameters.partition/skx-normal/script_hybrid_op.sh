#!/bin/bash
#SBATCH --job-name="SubmissionTe/37545281/hybrid_op/0000/7bc1763851943977ef8f2cb89ac7861e"
#SBATCH --partition=skx-normal
#SBATCH --nodes=2
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(37545281479eb2ac074fef1d280ae0bd)
export OMP_NUM_THREADS=2
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 37545281479eb2ac074fef1d280ae0bd

