#!/bin/bash
#SBATCH --job-name="SubmissionTe/37545281/mpi_op/0000/8e8c02b17a7238c63bf47cd893437f07"
#SBATCH --partition=skx-normal
#SBATCH --nodes=2
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# mpi_op(37545281479eb2ac074fef1d280ae0bd)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 37545281479eb2ac074fef1d280ae0bd

