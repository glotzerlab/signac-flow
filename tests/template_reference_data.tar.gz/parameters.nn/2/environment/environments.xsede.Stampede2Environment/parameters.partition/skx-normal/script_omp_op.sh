#!/bin/bash
#SBATCH --job-name="SubmissionTe/37545281/omp_op/0000/6dddf06912ae047981dd04d05f1cf844"
#SBATCH --partition=skx-normal
#SBATCH --nodes=2
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# omp_op(37545281479eb2ac074fef1d280ae0bd)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 37545281479eb2ac074fef1d280ae0bd

