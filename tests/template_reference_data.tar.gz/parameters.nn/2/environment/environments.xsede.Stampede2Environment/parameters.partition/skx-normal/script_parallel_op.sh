#!/bin/bash
#SBATCH --job-name="SubmissionTe/37545281/parallel_op/0000/ec99bbd481c74ba8d2b3c92ba50979c3"
#SBATCH --partition=skx-normal
#SBATCH --nodes=2
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# parallel_op(37545281479eb2ac074fef1d280ae0bd)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 37545281479eb2ac074fef1d280ae0bd

