#!/bin/bash
#SBATCH --job-name="SubmissionTe/37545281/serial_op/0000/940e8b512cbd4f5376a584bd589e443e"
#SBATCH --partition=skx-normal
#SBATCH --nodes=2
#SBATCH --ntasks=1
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# serial_op(37545281479eb2ac074fef1d280ae0bd)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 37545281479eb2ac074fef1d280ae0bd

