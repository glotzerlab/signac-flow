#PBS -N SubmissionTe/9626d150/gpu_op/0000/89e0e543823316de73c0a1347d9bc0cb
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# gpu_op(9626d150d28acc04b0288d609fe63a1a)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 9626d150d28acc04b0288d609fe63a1a

