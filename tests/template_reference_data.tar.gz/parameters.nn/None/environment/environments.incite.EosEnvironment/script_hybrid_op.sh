#PBS -N SubmissionTe/9626d150/hybrid_op/0000/94211f76878137676bf25fec71d20e99
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(9626d150d28acc04b0288d609fe63a1a)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 9626d150d28acc04b0288d609fe63a1a

