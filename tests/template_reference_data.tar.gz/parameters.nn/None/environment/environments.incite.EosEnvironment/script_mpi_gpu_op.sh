#PBS -N SubmissionTe/9626d150/mpi_gpu_op/0000/3a3bb51fc5f4bade4ea4fd71b936818a
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(9626d150d28acc04b0288d609fe63a1a)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 9626d150d28acc04b0288d609fe63a1a

