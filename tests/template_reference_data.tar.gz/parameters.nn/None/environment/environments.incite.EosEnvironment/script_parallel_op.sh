#PBS -N SubmissionTe/9626d150/parallel_op/0000/d3ea654dcb94c887bc951d2ea78ef736
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# parallel_op(9626d150d28acc04b0288d609fe63a1a)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 9626d150d28acc04b0288d609fe63a1a

