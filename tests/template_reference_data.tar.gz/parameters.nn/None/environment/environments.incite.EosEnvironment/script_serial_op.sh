#PBS -N SubmissionTe/9626d150/serial_op/0000/1fbd843caff937c55c3746b694a472b5
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(9626d150d28acc04b0288d609fe63a1a)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 9626d150d28acc04b0288d609fe63a1a

