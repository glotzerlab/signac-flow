#PBS -N SubmissionTe/11dd16d0/gpu_op/0000/6d75eebbe2a558bb25733b58a175302c
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# gpu_op(11dd16d04f6d624884a59e3e77d22cc8)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 11dd16d04f6d624884a59e3e77d22cc8

