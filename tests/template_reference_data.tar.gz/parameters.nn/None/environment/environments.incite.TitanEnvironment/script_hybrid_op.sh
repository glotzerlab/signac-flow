#PBS -N SubmissionTe/11dd16d0/hybrid_op/0000/85bbf8dbad6acee3b88a6a006aca0632
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(11dd16d04f6d624884a59e3e77d22cc8)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 11dd16d04f6d624884a59e3e77d22cc8

