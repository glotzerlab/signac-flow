#PBS -N SubmissionTe/11dd16d0/mpi_gpu_op/0000/c1425cbecb357362efd4cc3d28ed3efa
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(11dd16d04f6d624884a59e3e77d22cc8)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 11dd16d04f6d624884a59e3e77d22cc8

