#PBS -N SubmissionTe/11dd16d0/mpi_op/0000/54147bb160b5bf3fd36e85a270046312
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(11dd16d04f6d624884a59e3e77d22cc8)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 11dd16d04f6d624884a59e3e77d22cc8

