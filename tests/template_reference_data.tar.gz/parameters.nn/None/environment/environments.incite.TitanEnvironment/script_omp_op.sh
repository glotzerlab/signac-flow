#PBS -N SubmissionTe/11dd16d0/omp_op/0000/28844500894cea56f0a401b9667f3ef8
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(11dd16d04f6d624884a59e3e77d22cc8)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 11dd16d04f6d624884a59e3e77d22cc8

