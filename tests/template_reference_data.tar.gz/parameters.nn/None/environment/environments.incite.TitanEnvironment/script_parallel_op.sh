#PBS -N SubmissionTe/11dd16d0/parallel_op/0000/0ed1d557d7c5cdcbbd074562eebd4241
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# parallel_op(11dd16d04f6d624884a59e3e77d22cc8)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 11dd16d04f6d624884a59e3e77d22cc8

