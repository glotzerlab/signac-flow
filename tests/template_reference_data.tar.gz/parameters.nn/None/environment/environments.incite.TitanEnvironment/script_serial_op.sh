#PBS -N SubmissionTe/11dd16d0/serial_op/0000/fdb22b98e228b77c1b596b796dde4081
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(11dd16d04f6d624884a59e3e77d22cc8)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 11dd16d04f6d624884a59e3e77d22cc8

