#PBS -N SubmissionTe/c86ac4a0/gpu_op/0000/074c759f70538df86440a739d3a66273
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# gpu_op(c86ac4a029a09cd4c94fa7704ca44235)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op c86ac4a029a09cd4c94fa7704ca44235

