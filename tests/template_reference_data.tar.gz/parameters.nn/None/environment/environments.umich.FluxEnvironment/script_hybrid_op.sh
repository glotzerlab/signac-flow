#PBS -N SubmissionTe/c86ac4a0/hybrid_op/0000/c82e0a20aff0b001b36ba5d4d42ea163
#PBS -V
#PBS -l nodes=4
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(c86ac4a029a09cd4c94fa7704ca44235)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op c86ac4a029a09cd4c94fa7704ca44235

