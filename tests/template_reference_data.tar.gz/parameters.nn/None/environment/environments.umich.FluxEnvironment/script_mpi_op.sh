#PBS -N SubmissionTe/c86ac4a0/mpi_op/0000/a5d1a2c6fc21cc30bf99fdd79cf8ea5f
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_op(c86ac4a029a09cd4c94fa7704ca44235)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op c86ac4a029a09cd4c94fa7704ca44235

