#PBS -N SubmissionTe/c86ac4a0/omp_op/0000/c5830f0bc7b3e6e837ba8094b446cf3d
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# omp_op(c86ac4a029a09cd4c94fa7704ca44235)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op c86ac4a029a09cd4c94fa7704ca44235

