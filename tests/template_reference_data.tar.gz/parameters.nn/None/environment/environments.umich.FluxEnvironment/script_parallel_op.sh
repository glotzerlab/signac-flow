#PBS -N SubmissionTe/c86ac4a0/parallel_op/0000/fbb5f1c9058077fc186f696b0b60fa36
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# parallel_op(c86ac4a029a09cd4c94fa7704ca44235)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op c86ac4a029a09cd4c94fa7704ca44235

