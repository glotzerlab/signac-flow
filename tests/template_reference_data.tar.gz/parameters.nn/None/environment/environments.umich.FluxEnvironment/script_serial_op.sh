#PBS -N SubmissionTe/c86ac4a0/serial_op/0000/3da91ec12f5df67de08662d1ce60280a
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# serial_op(c86ac4a029a09cd4c94fa7704ca44235)
/usr/local/bin/python generate_template_reference_data.py exec serial_op c86ac4a029a09cd4c94fa7704ca44235

