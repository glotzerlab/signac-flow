#!/bin/bash
#SBATCH --job-name="SubmissionTe/011496b3/hybrid_op/0000/1bddbebdbe841a3612b77523a4552343"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(011496b3448205ee7d3e04cfe9adc7e4)
export OMP_NUM_THREADS=2
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 011496b3448205ee7d3e04cfe9adc7e4

