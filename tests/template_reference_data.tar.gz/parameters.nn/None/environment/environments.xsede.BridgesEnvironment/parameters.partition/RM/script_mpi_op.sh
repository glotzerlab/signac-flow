#!/bin/bash
#SBATCH --job-name="SubmissionTe/011496b3/mpi_op/0000/67675663aae555ac7cdd4c4c16a8a789"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(011496b3448205ee7d3e04cfe9adc7e4)
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 011496b3448205ee7d3e04cfe9adc7e4

