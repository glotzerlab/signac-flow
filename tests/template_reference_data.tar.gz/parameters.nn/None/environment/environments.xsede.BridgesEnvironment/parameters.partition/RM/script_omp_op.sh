#!/bin/bash
#SBATCH --job-name="SubmissionTe/011496b3/omp_op/0000/5ba44be66b60d2e9a9e7a00c318bc498"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# omp_op(011496b3448205ee7d3e04cfe9adc7e4)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 011496b3448205ee7d3e04cfe9adc7e4

