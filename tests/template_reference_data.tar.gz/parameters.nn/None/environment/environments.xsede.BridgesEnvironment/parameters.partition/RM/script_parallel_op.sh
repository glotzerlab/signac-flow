#!/bin/bash
#SBATCH --job-name="SubmissionTe/011496b3/parallel_op/0000/4c62ef4f0a2f0746e848f2d630bb2e19"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(011496b3448205ee7d3e04cfe9adc7e4)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 011496b3448205ee7d3e04cfe9adc7e4

