#!/bin/bash
#SBATCH --job-name="SubmissionTe/63dbe882/hybrid_op/0000/d3b8c4bd633243f08cfbf9a393cb5b15"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(63dbe882db934c3da8d2b0bc21e5d099)
export OMP_NUM_THREADS=2
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 63dbe882db934c3da8d2b0bc21e5d099

