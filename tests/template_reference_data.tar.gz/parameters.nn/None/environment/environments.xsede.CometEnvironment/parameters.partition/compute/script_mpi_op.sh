#!/bin/bash
#SBATCH --job-name="SubmissionTe/63dbe882/mpi_op/0000/acc145a6d4419f9734e62ca1985e2a4d"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(63dbe882db934c3da8d2b0bc21e5d099)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 63dbe882db934c3da8d2b0bc21e5d099

