#!/bin/bash
#SBATCH --job-name="SubmissionTe/63dbe882/omp_op/0000/2b0f2d8aba9215b9bd58e4ac68bb76b8"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# omp_op(63dbe882db934c3da8d2b0bc21e5d099)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 63dbe882db934c3da8d2b0bc21e5d099

