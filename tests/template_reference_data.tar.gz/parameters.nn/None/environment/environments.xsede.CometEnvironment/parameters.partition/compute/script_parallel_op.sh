#!/bin/bash
#SBATCH --job-name="SubmissionTe/63dbe882/parallel_op/0000/580eb98f1f95de2f2413374285a20432"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(63dbe882db934c3da8d2b0bc21e5d099)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 63dbe882db934c3da8d2b0bc21e5d099

