#!/bin/bash
#SBATCH --job-name="SubmissionTe/63dbe882/serial_op/0000/956f08ce30c1ff442bfa39cc08bc6cac"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(63dbe882db934c3da8d2b0bc21e5d099)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 63dbe882db934c3da8d2b0bc21e5d099

