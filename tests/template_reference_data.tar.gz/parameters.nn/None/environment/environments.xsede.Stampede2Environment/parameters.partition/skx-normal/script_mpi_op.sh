#!/bin/bash
#SBATCH --job-name="SubmissionTe/c4295353/mpi_op/0000/d6e77d537bb18512b6886c9b274c9373"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# mpi_op(c42953534824b51690a2f0c81dd31caf)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op c42953534824b51690a2f0c81dd31caf

