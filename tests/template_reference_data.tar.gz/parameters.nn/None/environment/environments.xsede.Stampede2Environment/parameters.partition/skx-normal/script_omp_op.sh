#!/bin/bash
#SBATCH --job-name="SubmissionTe/c4295353/omp_op/0000/55b8637e01304f6dc1adf54f0a4dedad"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# omp_op(c42953534824b51690a2f0c81dd31caf)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op c42953534824b51690a2f0c81dd31caf

