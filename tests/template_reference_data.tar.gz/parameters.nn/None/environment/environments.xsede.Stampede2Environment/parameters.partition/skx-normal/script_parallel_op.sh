#!/bin/bash
#SBATCH --job-name="SubmissionTe/c4295353/parallel_op/0000/252cec1803a8dcf008a307e53cdc26c6"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# parallel_op(c42953534824b51690a2f0c81dd31caf)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op c42953534824b51690a2f0c81dd31caf

