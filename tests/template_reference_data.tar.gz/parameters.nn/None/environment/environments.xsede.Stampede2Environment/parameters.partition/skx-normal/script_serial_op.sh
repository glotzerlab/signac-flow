#!/bin/bash
#SBATCH --job-name="SubmissionTe/c4295353/serial_op/0000/020d14e40a5b55e84de385e35c0e6be2"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# serial_op(c42953534824b51690a2f0c81dd31caf)
/usr/local/bin/python generate_template_reference_data.py exec serial_op c42953534824b51690a2f0c81dd31caf

