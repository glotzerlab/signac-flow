#!/bin/bash
#SBATCH --job-name="TestProject/31398579b017d58a2b3c230f38560496/mpi_op/8fae40d6448410e8199c7ad686058be4"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(31398579b017d58a2b3c230f38560496)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 31398579b017d58a2b3c230f38560496
# Eligible to run:
# ibrun -n 5 -o 0 task_affinity  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 31398579b017d58a2b3c230f38560496


