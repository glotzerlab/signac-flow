#!/bin/bash
#SBATCH --job-name="SubmissionTe/31398579/mpi_op/0000/6c0adf77ebcaa85a71c0a58b85c7729c"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op(31398579b017d58a2b3c230f38560496)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 31398579b017d58a2b3c230f38560496
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 31398579b017d58a2b3c230f38560496

