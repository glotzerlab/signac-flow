#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/be21201f16c0fef2de385d30349dc90569ce00c5"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(799d4a980e82bba16a98ecff757a8fc0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 799d4a980e82bba16a98ecff757a8fc0
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 799d4a980e82bba16a98ecff757a8fc0

# omp_op(799d4a980e82bba16a98ecff757a8fc0)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 799d4a980e82bba16a98ecff757a8fc0
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 799d4a980e82bba16a98ecff757a8fc0

