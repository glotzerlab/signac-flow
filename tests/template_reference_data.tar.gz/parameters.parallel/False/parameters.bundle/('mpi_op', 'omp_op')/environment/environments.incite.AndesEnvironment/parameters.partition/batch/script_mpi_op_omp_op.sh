#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/f0194b3feec85be6141d0188045abec67546f440"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(4be2d42ad74a7039bdb6a402abc19afb)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 4be2d42ad74a7039bdb6a402abc19afb
# Eligible to run:
# srun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 4be2d42ad74a7039bdb6a402abc19afb

# omp_op(4be2d42ad74a7039bdb6a402abc19afb)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 4be2d42ad74a7039bdb6a402abc19afb
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 4be2d42ad74a7039bdb6a402abc19afb

