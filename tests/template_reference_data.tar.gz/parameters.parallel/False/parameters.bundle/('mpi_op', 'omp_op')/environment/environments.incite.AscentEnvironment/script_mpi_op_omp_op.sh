#!/bin/bash
#BSUB -J SubmissionTest/bundle/a0d7405dd529736503b25029d2cd5d2f58824f57
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(babc4e6abdbb4af9abf0412acdf1d2e7)
jsrun -n 5 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_op babc4e6abdbb4af9abf0412acdf1d2e7

# omp_op(babc4e6abdbb4af9abf0412acdf1d2e7)
export OMP_NUM_THREADS=4
jsrun -n 4 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec omp_op babc4e6abdbb4af9abf0412acdf1d2e7

