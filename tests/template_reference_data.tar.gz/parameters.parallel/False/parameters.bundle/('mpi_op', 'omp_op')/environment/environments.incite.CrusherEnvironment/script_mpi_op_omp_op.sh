#!/bin/bash
#SBATCH --job-name="TestProject/bundle/d67f97dfa063068e3eabbb52308cf75f8b0cdb32"
#SBATCH -N 1
#SBATCH -p batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(f5a4e07885d0393e1a9bdf8a74cf7ba7)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j f5a4e07885d0393e1a9bdf8a74cf7ba7
# Eligible to run:
# srun -N1 -n5 -c1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec mpi_op f5a4e07885d0393e1a9bdf8a74cf7ba7

# omp_op(f5a4e07885d0393e1a9bdf8a74cf7ba7)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j f5a4e07885d0393e1a9bdf8a74cf7ba7
# Eligible to run:
# export OMP_NUM_THREADS=4; srun -N1 -n0 -c4 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec omp_op f5a4e07885d0393e1a9bdf8a74cf7ba7

