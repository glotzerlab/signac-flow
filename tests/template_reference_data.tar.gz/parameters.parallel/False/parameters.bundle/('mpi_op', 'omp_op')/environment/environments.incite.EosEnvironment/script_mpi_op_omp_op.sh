#PBS -N SubmissionTest/bundle/54c1dd09932057f46afc0dc2c402f730be813c95
#PBS -V
#PBS -l nodes=1
#PBS -A MAT110

set -e
set -u

cd /home/user/project/

# mpi_op(636b26ebd5ec9548239c297990e1fe11)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 636b26ebd5ec9548239c297990e1fe11

# omp_op(636b26ebd5ec9548239c297990e1fe11)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 636b26ebd5ec9548239c297990e1fe11

