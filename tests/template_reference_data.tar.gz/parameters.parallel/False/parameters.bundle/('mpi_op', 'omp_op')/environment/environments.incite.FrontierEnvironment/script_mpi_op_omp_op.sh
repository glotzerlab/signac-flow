#!/bin/bash
#SBATCH --job-name="TestProject/bundle/35e16318c57b0f02fa48733e2ab09a0a8d9ad88a"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(5c4dad0daf120e3cecb848251396e536)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 5c4dad0daf120e3cecb848251396e536
# Eligible to run:
# srun --ntasks=5 --cpus-per-task=1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 5c4dad0daf120e3cecb848251396e536

# omp_op(5c4dad0daf120e3cecb848251396e536)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 5c4dad0daf120e3cecb848251396e536
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 5c4dad0daf120e3cecb848251396e536

