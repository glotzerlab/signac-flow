None
#!/bin/bash
#BSUB -J SubmissionTest/bundle/efdb5c1a66845d099189c819096b4e24ac1f3c13
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(d142d4b4f154ac5011dae8b58cd46b9a)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j d142d4b4f154ac5011dae8b58cd46b9a
# Eligible to run:
# jsrun -n 5 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec mpi_op d142d4b4f154ac5011dae8b58cd46b9a

# omp_op(d142d4b4f154ac5011dae8b58cd46b9a)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j d142d4b4f154ac5011dae8b58cd46b9a
# Eligible to run:
# export OMP_NUM_THREADS=4; jsrun -n 1 -a 1 -c 4 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec omp_op d142d4b4f154ac5011dae8b58cd46b9a

