#!/bin/bash
#BSUB -J SubmissionTest/bundle/53bbdc68c1daf6eaab11b73046816584f74eb311
#BSUB -nnodes 1
#BSUB -P MAT110

set -e
set -u

cd /home/user/project/

# mpi_op(d142d4b4f154ac5011dae8b58cd46b9a)
jsrun -n 5 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_op d142d4b4f154ac5011dae8b58cd46b9a

# omp_op(d142d4b4f154ac5011dae8b58cd46b9a)
export OMP_NUM_THREADS=4
jsrun -n 4 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec omp_op d142d4b4f154ac5011dae8b58cd46b9a

