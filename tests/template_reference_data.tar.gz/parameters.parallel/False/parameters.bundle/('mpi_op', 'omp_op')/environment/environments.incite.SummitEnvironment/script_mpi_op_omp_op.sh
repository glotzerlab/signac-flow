#!/bin/bash
#BSUB -J SubmissionTest/bundle/53bbdc68c1daf6eaab11b73046816584f74eb311
#BSUB -nnodes 1
#BSUB -P MAT110

set -e
set -u

cd /home/user/project/

# mpi_op(d142d4b4f154ac5011dae8b58cd46b9a)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j d142d4b4f154ac5011dae8b58cd46b9a
# Eligible to run:
# mpiexec -n 5  /home/bdice/miniconda3/envs/dice/bin/python generate_template_reference_data.py exec mpi_op d142d4b4f154ac5011dae8b58cd46b9a

# omp_op(d142d4b4f154ac5011dae8b58cd46b9a)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j d142d4b4f154ac5011dae8b58cd46b9a
# Eligible to run:
# export OMP_NUM_THREADS=4;  /home/bdice/miniconda3/envs/dice/bin/python generate_template_reference_data.py exec omp_op d142d4b4f154ac5011dae8b58cd46b9a

