#PBS -N SubmissionTest/bundle/81a6640dbc4c35962b21b6e95086f271f6e7ecfb
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# mpi_op(b293e1851c5881828462bb7a06dce02c)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op b293e1851c5881828462bb7a06dce02c

# omp_op(b293e1851c5881828462bb7a06dce02c)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op b293e1851c5881828462bb7a06dce02c

