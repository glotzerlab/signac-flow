#PBS -N SubmissionTest/bundle/f292d3ac1781697c918f0e78e383ff4dfb57b41c
#PBS -V
#PBS -l nodes=2:ppn=4
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/user/project/

# mpi_op(97fb213cec4e13f4044d47f5df1e217d)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 97fb213cec4e13f4044d47f5df1e217d

# omp_op(97fb213cec4e13f4044d47f5df1e217d)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 97fb213cec4e13f4044d47f5df1e217d

