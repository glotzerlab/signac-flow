#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/e65b1daefd4fcb2b18a496025a102326b26e87eb"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](7441eb4c64c1e8ebac38c41ffe945c97)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 7441eb4c64c1e8ebac38c41ffe945c97
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 7441eb4c64c1e8ebac38c41ffe945c97

# omp_op[#1](7441eb4c64c1e8ebac38c41ffe945c97)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 7441eb4c64c1e8ebac38c41ffe945c97
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 7441eb4c64c1e8ebac38c41ffe945c97

