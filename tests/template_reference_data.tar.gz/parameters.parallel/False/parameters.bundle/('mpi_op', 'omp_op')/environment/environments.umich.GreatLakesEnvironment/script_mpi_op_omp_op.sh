#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/d1b7bf2611aaa1c80f478704b76c6386fa021edd"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --account=sglotzer0

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(7441eb4c64c1e8ebac38c41ffe945c97)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 7441eb4c64c1e8ebac38c41ffe945c97
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 7441eb4c64c1e8ebac38c41ffe945c97

# omp_op(7441eb4c64c1e8ebac38c41ffe945c97)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 7441eb4c64c1e8ebac38c41ffe945c97
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 7441eb4c64c1e8ebac38c41ffe945c97

