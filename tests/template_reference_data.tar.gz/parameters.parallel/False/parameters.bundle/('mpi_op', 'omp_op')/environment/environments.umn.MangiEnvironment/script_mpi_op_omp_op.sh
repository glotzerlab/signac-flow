#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/497908f4209d7396506d90aa837b4ece4438e394"
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 3d229b7914b815e2aeb36dc1a9040f84

# omp_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 3d229b7914b815e2aeb36dc1a9040f84

