#!/bin/bash
#SBATCH --job-name="TestProject/bundle/1f7a2c906ddee864ae64b1262bdc9360084823bd"
#SBATCH --ntasks=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 3d229b7914b815e2aeb36dc1a9040f84

# omp_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 3d229b7914b815e2aeb36dc1a9040f84

