#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/a559df6f79cb4d3f701ac8720d187db320544646"
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 3d229b7914b815e2aeb36dc1a9040f84

# omp_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 3d229b7914b815e2aeb36dc1a9040f84

