#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/7ed53454e756920394c5d152f1ae9ac8d1ab885f"
#SBATCH --ntasks=5

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# mpi_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 3d229b7914b815e2aeb36dc1a9040f84

# omp_op(3d229b7914b815e2aeb36dc1a9040f84)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 3d229b7914b815e2aeb36dc1a9040f84
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 3d229b7914b815e2aeb36dc1a9040f84

