None
#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/73178ac1ae1821156f4c79aef6135b820fbcaa8a"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(125ea88a30aaac65a18e949189888b5e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 125ea88a30aaac65a18e949189888b5e
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 125ea88a30aaac65a18e949189888b5e

# omp_op(125ea88a30aaac65a18e949189888b5e)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 125ea88a30aaac65a18e949189888b5e
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 125ea88a30aaac65a18e949189888b5e

