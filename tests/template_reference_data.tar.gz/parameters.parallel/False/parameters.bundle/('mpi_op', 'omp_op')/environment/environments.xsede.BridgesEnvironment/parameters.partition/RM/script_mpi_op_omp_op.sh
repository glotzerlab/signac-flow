#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/3777b1399a382939e05c0dc641356d60b95873e7"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(5bea7f4064798af873fad258b21cf034)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 5bea7f4064798af873fad258b21cf034
# Eligible to run:
# mpiexec -n 5  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec mpi_op 5bea7f4064798af873fad258b21cf034

# omp_op(5bea7f4064798af873fad258b21cf034)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 5bea7f4064798af873fad258b21cf034
# Eligible to run:
# export OMP_NUM_THREADS=4;  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec omp_op 5bea7f4064798af873fad258b21cf034

