#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/6a4ae886aa00bd1a8cff7157d292e22ff6e8591b"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](5bea7f4064798af873fad258b21cf034)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 5bea7f4064798af873fad258b21cf034
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 5bea7f4064798af873fad258b21cf034

# omp_op[#1](5bea7f4064798af873fad258b21cf034)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 5bea7f4064798af873fad258b21cf034
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 5bea7f4064798af873fad258b21cf034

