#!/bin/bash
#SBATCH --job-name="TestProject/bundle/63e2c28a852b2abb66f7c0b7db3f5b7d162871b3"
#SBATCH --partition=cpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(4dad28745e1fb14f633db28a1bc019fb)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 4dad28745e1fb14f633db28a1bc019fb
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 4dad28745e1fb14f633db28a1bc019fb

# omp_op(4dad28745e1fb14f633db28a1bc019fb)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 4dad28745e1fb14f633db28a1bc019fb
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 4dad28745e1fb14f633db28a1bc019fb

