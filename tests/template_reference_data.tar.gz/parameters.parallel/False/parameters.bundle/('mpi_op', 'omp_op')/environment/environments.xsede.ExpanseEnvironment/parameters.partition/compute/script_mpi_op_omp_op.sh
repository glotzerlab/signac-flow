    #!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/20c7cba41f4ee1993c6535ca8375454844ad5c65"
#SBATCH --partition=compute

#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd "/home/user/project/"

# mpi_op(ac9f063cf3f7a2b3c533d608b95eb9bd)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j ac9f063cf3f7a2b3c533d608b95eb9bd
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op ac9f063cf3f7a2b3c533d608b95eb9bd

# omp_op(ac9f063cf3f7a2b3c533d608b95eb9bd)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j ac9f063cf3f7a2b3c533d608b95eb9bd
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op ac9f063cf3f7a2b3c533d608b95eb9bd

