    #!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/045b804d3a8713b61be970a2383acc314e51bf2d"
#SBATCH --partition=compute

#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# mpi_op(ac9f063cf3f7a2b3c533d608b95eb9bd)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j ac9f063cf3f7a2b3c533d608b95eb9bd
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op ac9f063cf3f7a2b3c533d608b95eb9bd

# omp_op(ac9f063cf3f7a2b3c533d608b95eb9bd)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j ac9f063cf3f7a2b3c533d608b95eb9bd
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op ac9f063cf3f7a2b3c533d608b95eb9bd

