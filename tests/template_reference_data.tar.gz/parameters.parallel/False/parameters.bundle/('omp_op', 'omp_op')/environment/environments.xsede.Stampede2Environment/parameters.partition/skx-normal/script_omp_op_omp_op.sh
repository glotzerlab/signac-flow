#!/bin/bash
#SBATCH --job-name="SubmissionTe/df25d491cfdf1210db245f94e765ec75/omp_op/688ee05c01804d7956316eca61d1988e"
#SBATCH --mem=4.0G
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# omp_op(df25d491cfdf1210db245f94e765ec75)
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o omp_op -j df25d491cfdf1210db245f94e765ec75
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op df25d491cfdf1210db245f94e765ec75


