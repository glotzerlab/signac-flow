#!/bin/bash
#SBATCH --job-name="SubmissionTe/df25d491cfdf1210db245f94e765ec75/omp_op/4bb51272472879ac3853f6ada898a60b"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(df25d491cfdf1210db245f94e765ec75)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j df25d491cfdf1210db245f94e765ec75
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op df25d491cfdf1210db245f94e765ec75


