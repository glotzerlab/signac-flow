#!/bin/bash
#SBATCH --job-name="SubmissionTe/df25d491/omp_op/0000/af85babdc1439faf24afb21d1acf2f88"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# omp_op(df25d491cfdf1210db245f94e765ec75)
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o omp_op -j df25d491cfdf1210db245f94e765ec75
# Eligible to run:
# export OMP_NUM_THREADS=4;  /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec omp_op df25d491cfdf1210db245f94e765ec75


