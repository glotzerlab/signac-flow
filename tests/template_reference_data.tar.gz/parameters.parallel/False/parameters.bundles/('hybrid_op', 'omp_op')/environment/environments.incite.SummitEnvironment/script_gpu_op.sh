'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/gpu_op/cad20bb557cdc296bb729be87cde18cc
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 

