'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/memory_oppar/992f7bc5cb771a1879e86a59cdd49e72
#BSUB -M 512MB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 
# 
# 
# 

