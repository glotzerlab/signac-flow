'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/memory_op/be4cb592882adb9bf98c742790e67cf2
#BSUB -M 512MB
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 

