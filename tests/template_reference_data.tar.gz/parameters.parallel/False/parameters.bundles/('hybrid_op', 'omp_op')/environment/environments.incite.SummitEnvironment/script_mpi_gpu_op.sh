'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/mpi_gpu_op/d023408adc3e1d5f3b758060fc3b026c
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 

