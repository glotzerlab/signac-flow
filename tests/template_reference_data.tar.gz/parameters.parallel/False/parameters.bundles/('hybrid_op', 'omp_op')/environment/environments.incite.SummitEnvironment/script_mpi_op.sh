'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/mpi_op/b695ed9e7e627da4efe62d0c6fda47b9
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 

