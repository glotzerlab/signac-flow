#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/multiline_cm/9181426a9276b450c4ddf9230a1a6b19
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# echo "First line"
# echo "Second line"

