'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/omp_op/af21c9ae3e34e37a67e42e3f7855fd9c
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 

