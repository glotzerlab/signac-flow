'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/parallel_op/b131f05b594b05d613e7fc129b83905a
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 

