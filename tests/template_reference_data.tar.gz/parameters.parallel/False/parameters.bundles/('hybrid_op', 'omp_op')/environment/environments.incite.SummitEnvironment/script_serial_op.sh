'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/980b954bb050a41fd8e4ead714bac9a1/serial_op/8c929285ce6212164257d912bb43d99d
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(980b954bb050a41fd8e4ead714bac9a1)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 980b954bb050a41fd8e4ead714bac9a1
# Eligible to run:
# 

