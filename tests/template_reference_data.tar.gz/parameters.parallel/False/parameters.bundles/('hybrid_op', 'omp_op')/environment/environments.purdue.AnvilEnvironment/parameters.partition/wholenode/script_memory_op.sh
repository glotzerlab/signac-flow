#!/bin/bash
#SBATCH --job-name="TestProject/cdbc4b3320d195c00359daae60634745/memory_op/04255e8510b4a35de17f34a4385e871e"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(cdbc4b3320d195c00359daae60634745)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j cdbc4b3320d195c00359daae60634745
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op cdbc4b3320d195c00359daae60634745

