#!/bin/bash
#SBATCH --job-name="TestProject/cdbc4b3320d195c00359daae60634745/walltime_op/2e9b0dda2960706b3d77b494a4b1cb94"
#SBATCH --partition=wholenode
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(cdbc4b3320d195c00359daae60634745)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j cdbc4b3320d195c00359daae60634745
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op cdbc4b3320d195c00359daae60634745

