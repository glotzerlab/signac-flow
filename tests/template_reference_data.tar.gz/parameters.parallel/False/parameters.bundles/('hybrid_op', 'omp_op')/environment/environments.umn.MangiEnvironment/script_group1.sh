#!/bin/bash
#SBATCH --job-name="TestProject/fe43298eab351c3ad1fe37400bc67b97/memory_oppar/1294cf37eebd92a7272758e0ac730dec"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem-per-task=171M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(fe43298eab351c3ad1fe37400bc67b97)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j fe43298eab351c3ad1fe37400bc67b97
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op fe43298eab351c3ad1fe37400bc67b97
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op fe43298eab351c3ad1fe37400bc67b97
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op fe43298eab351c3ad1fe37400bc67b97
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op fe43298eab351c3ad1fe37400bc67b97

