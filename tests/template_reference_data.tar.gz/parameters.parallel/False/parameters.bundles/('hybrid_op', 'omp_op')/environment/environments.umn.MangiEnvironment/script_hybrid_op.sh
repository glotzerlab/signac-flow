#!/bin/bash
#SBATCH --job-name="TestProject/fe43298eab351c3ad1fe37400bc67b97/hybrid_op/503295fbbc0d3e038a3abd29f7f65717"
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(fe43298eab351c3ad1fe37400bc67b97)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j fe43298eab351c3ad1fe37400bc67b97
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op fe43298eab351c3ad1fe37400bc67b97

