#!/bin/bash
#SBATCH --job-name="TestProject/fe43298eab351c3ad1fe37400bc67b97/memory_op/da712ba00dddf8745517b081a3342201"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(fe43298eab351c3ad1fe37400bc67b97)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j fe43298eab351c3ad1fe37400bc67b97
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op fe43298eab351c3ad1fe37400bc67b97

