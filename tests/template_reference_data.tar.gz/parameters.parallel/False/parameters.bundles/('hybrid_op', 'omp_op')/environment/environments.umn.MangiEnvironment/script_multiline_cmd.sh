#!/bin/bash
#SBATCH --job-name="TestProject/fe43298eab351c3ad1fe37400bc67b97/multiline_cm/4e8ad4213984c61cf300332695705670"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(fe43298eab351c3ad1fe37400bc67b97)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j fe43298eab351c3ad1fe37400bc67b97
# Eligible to run:
# echo "First line"
# echo "Second line"

