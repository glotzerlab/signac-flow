#!/bin/bash
#SBATCH --job-name="TestProject/fe43298eab351c3ad1fe37400bc67b97/omp_op/3f48212b4824bc357c7956caab04ce1f"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(fe43298eab351c3ad1fe37400bc67b97)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j fe43298eab351c3ad1fe37400bc67b97
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op fe43298eab351c3ad1fe37400bc67b97

