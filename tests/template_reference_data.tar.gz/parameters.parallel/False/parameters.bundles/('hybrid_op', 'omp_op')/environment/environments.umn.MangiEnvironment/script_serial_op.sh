#!/bin/bash
#SBATCH --job-name="TestProject/fe43298eab351c3ad1fe37400bc67b97/serial_op/414f137f2b4e23aa2bb76c06d7eeb52f"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(fe43298eab351c3ad1fe37400bc67b97)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j fe43298eab351c3ad1fe37400bc67b97
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op fe43298eab351c3ad1fe37400bc67b97

