#!/bin/bash
#SBATCH --job-name="TestProject/6635410091a81769034757ce61c18077/memory_oppar/d2b3f4a0b793402ccac37432c23661ae"
#SBATCH --partition=batch
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem-per-task=171M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(6635410091a81769034757ce61c18077)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 6635410091a81769034757ce61c18077
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 6635410091a81769034757ce61c18077
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 6635410091a81769034757ce61c18077
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 6635410091a81769034757ce61c18077
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 6635410091a81769034757ce61c18077

