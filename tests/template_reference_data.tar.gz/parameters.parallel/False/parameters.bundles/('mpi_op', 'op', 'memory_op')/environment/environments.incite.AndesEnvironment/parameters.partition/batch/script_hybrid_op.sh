#!/bin/bash
#SBATCH --job-name="TestProject/6635410091a81769034757ce61c18077/hybrid_op/ad17dbc7181bb71800d62bd4ad40c343"
#SBATCH --partition=batch
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(6635410091a81769034757ce61c18077)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 6635410091a81769034757ce61c18077
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 6635410091a81769034757ce61c18077

