#!/bin/bash
#SBATCH --job-name="TestProject/6635410091a81769034757ce61c18077/mpi_op/035267dd6b1731f72bc8587079fc637a"
#SBATCH --partition=batch
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(6635410091a81769034757ce61c18077)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 6635410091a81769034757ce61c18077
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 6635410091a81769034757ce61c18077

