#!/bin/bash
#SBATCH --job-name="TestProject/6635410091a81769034757ce61c18077/multiline_cm/0059daf888fdb46dee2d93c79f56c5b2"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(6635410091a81769034757ce61c18077)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 6635410091a81769034757ce61c18077
# Eligible to run:
# echo "First line"
# echo "Second line"

