#!/bin/bash
#SBATCH --job-name="TestProject/6635410091a81769034757ce61c18077/omp_op/f5559e6e6a7ac2bbe9c38f9206b3863c"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(6635410091a81769034757ce61c18077)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 6635410091a81769034757ce61c18077
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 6635410091a81769034757ce61c18077

