#!/bin/bash
#SBATCH --job-name="TestProject/b74a5561fa91df3d96f442b923fbddf9/gpu_op/aac730bdfe523d84665962face89efa1"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(b74a5561fa91df3d96f442b923fbddf9)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j b74a5561fa91df3d96f442b923fbddf9
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op b74a5561fa91df3d96f442b923fbddf9

