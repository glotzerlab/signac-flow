#!/bin/bash
#SBATCH --job-name="TestProject/b74a5561fa91df3d96f442b923fbddf9/hybrid_op/a0fca0825334cb8905fc8901ea86d451"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(b74a5561fa91df3d96f442b923fbddf9)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j b74a5561fa91df3d96f442b923fbddf9
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op b74a5561fa91df3d96f442b923fbddf9

