#!/bin/bash
#SBATCH --job-name="TestProject/b74a5561fa91df3d96f442b923fbddf9/memory_op/df5a704a96d954bba008ba297fac6809"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(b74a5561fa91df3d96f442b923fbddf9)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j b74a5561fa91df3d96f442b923fbddf9
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op b74a5561fa91df3d96f442b923fbddf9

