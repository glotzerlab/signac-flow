#!/bin/bash
#SBATCH --job-name="TestProject/b74a5561fa91df3d96f442b923fbddf9/multiline_cm/d2209a7c8b58bee2ebba9b7011a80f00"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(b74a5561fa91df3d96f442b923fbddf9)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j b74a5561fa91df3d96f442b923fbddf9
# Eligible to run:
# echo "First line"
# echo "Second line"

