#!/bin/bash
#SBATCH --job-name="TestProject/9a66e07951a28a9d47c0ba12637f5ce2/hybrid_op/00fe5dbfafd4b7ad9f67cc8938e52d17"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(9a66e07951a28a9d47c0ba12637f5ce2)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 9a66e07951a28a9d47c0ba12637f5ce2
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 9a66e07951a28a9d47c0ba12637f5ce2

