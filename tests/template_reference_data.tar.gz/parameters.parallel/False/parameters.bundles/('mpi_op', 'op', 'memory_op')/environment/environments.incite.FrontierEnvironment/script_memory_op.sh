#!/bin/bash
#SBATCH --job-name="TestProject/9a66e07951a28a9d47c0ba12637f5ce2/memory_op/2702779f14f2e53e4937c4bd5acf5fb9"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(9a66e07951a28a9d47c0ba12637f5ce2)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 9a66e07951a28a9d47c0ba12637f5ce2
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 9a66e07951a28a9d47c0ba12637f5ce2

