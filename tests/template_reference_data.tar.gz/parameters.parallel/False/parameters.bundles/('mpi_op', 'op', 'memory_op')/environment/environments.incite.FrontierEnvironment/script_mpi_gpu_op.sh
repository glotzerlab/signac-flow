#!/bin/bash
#SBATCH --job-name="TestProject/9a66e07951a28a9d47c0ba12637f5ce2/mpi_gpu_op/e40854a0fb9e4f2dee070a869e2b0815"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(9a66e07951a28a9d47c0ba12637f5ce2)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 9a66e07951a28a9d47c0ba12637f5ce2
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 9a66e07951a28a9d47c0ba12637f5ce2

