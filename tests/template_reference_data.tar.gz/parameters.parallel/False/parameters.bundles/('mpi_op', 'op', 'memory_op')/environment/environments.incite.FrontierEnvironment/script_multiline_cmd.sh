#!/bin/bash
#SBATCH --job-name="TestProject/9a66e07951a28a9d47c0ba12637f5ce2/multiline_cm/bcd7427b0ccd1ccdda2b48c92abf20a4"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(9a66e07951a28a9d47c0ba12637f5ce2)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 9a66e07951a28a9d47c0ba12637f5ce2
# Eligible to run:
# echo "First line"
# echo "Second line"

