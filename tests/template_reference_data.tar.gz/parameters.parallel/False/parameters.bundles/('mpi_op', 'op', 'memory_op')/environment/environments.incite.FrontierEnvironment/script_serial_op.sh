#!/bin/bash
#SBATCH --job-name="TestProject/9a66e07951a28a9d47c0ba12637f5ce2/serial_op/2a5a569193c231a4df545a7da03576fa"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(9a66e07951a28a9d47c0ba12637f5ce2)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 9a66e07951a28a9d47c0ba12637f5ce2
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 9a66e07951a28a9d47c0ba12637f5ce2

