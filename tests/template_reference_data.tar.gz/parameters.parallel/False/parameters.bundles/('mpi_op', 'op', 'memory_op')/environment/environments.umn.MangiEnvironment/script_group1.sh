#!/bin/bash
#SBATCH --job-name="TestProject/0fc295141cc74889f32618c54b6af37e/memory_oppar/d958fe3bf8c1d4de27bf5cbe99b6e875"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem-per-task=171M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(0fc295141cc74889f32618c54b6af37e)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 0fc295141cc74889f32618c54b6af37e
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 0fc295141cc74889f32618c54b6af37e
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 0fc295141cc74889f32618c54b6af37e
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 0fc295141cc74889f32618c54b6af37e
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 0fc295141cc74889f32618c54b6af37e

