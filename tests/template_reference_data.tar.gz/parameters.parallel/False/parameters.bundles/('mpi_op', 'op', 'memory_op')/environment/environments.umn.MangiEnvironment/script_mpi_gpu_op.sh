#!/bin/bash
#SBATCH --job-name="TestProject/0fc295141cc74889f32618c54b6af37e/mpi_gpu_op/3e91a13427ac37a03c01881e3946ca19"
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(0fc295141cc74889f32618c54b6af37e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 0fc295141cc74889f32618c54b6af37e
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 0fc295141cc74889f32618c54b6af37e

