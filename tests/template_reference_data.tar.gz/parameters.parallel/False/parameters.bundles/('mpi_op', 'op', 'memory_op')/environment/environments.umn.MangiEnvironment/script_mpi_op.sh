#!/bin/bash
#SBATCH --job-name="TestProject/0fc295141cc74889f32618c54b6af37e/mpi_op/8a68cf0a19983c5d15f342fe3b7014e9"
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(0fc295141cc74889f32618c54b6af37e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0fc295141cc74889f32618c54b6af37e
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 0fc295141cc74889f32618c54b6af37e

