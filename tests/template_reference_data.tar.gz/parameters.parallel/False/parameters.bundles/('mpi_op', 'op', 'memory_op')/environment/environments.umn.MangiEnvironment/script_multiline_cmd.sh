#!/bin/bash
#SBATCH --job-name="TestProject/0fc295141cc74889f32618c54b6af37e/multiline_cm/6cbaad537c9eff353b09fca56154e406"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(0fc295141cc74889f32618c54b6af37e)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 0fc295141cc74889f32618c54b6af37e
# Eligible to run:
# echo "First line"
# echo "Second line"

