#!/bin/bash
#SBATCH --job-name="TestProject/0fc295141cc74889f32618c54b6af37e/serial_op/5d4bcdfd288b2828e7494e6e2a980bfa"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(0fc295141cc74889f32618c54b6af37e)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 0fc295141cc74889f32618c54b6af37e
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 0fc295141cc74889f32618c54b6af37e

