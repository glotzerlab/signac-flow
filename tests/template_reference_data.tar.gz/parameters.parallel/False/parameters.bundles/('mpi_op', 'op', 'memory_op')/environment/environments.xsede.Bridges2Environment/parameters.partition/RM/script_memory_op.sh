#!/bin/bash
#SBATCH --job-name="TestProject/21d065a6b80f71a092e875fea68cc6aa/memory_op/074a5cd4fd6e41289947f23c10ee1bc8"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(21d065a6b80f71a092e875fea68cc6aa)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 21d065a6b80f71a092e875fea68cc6aa
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 21d065a6b80f71a092e875fea68cc6aa

