#!/bin/bash
#SBATCH --job-name="TestProject/21d065a6b80f71a092e875fea68cc6aa/mpi_op/d1b6a287ea834158b9f9228957b74b77"
#SBATCH --partition=RM
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(21d065a6b80f71a092e875fea68cc6aa)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 21d065a6b80f71a092e875fea68cc6aa
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 21d065a6b80f71a092e875fea68cc6aa

