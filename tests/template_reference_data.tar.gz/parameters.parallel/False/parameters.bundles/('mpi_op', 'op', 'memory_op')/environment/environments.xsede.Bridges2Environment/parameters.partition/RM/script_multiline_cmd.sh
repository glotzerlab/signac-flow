#!/bin/bash
#SBATCH --job-name="TestProject/21d065a6b80f71a092e875fea68cc6aa/multiline_cm/89ce10de09dbf0803c58d0d781b8a236"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(21d065a6b80f71a092e875fea68cc6aa)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 21d065a6b80f71a092e875fea68cc6aa
# Eligible to run:
# echo "First line"
# echo "Second line"

