#!/bin/bash
#SBATCH --job-name="TestProject/21d065a6b80f71a092e875fea68cc6aa/omp_op/0221de79d389c7e92cafdc5c0a99c8dc"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(21d065a6b80f71a092e875fea68cc6aa)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 21d065a6b80f71a092e875fea68cc6aa
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 21d065a6b80f71a092e875fea68cc6aa

