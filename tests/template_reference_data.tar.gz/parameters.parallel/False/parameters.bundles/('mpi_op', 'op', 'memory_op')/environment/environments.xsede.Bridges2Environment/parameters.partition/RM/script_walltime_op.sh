#!/bin/bash
#SBATCH --job-name="TestProject/21d065a6b80f71a092e875fea68cc6aa/walltime_op/a0019569f8aa4964f844e30bd2ea4895"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(21d065a6b80f71a092e875fea68cc6aa)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 21d065a6b80f71a092e875fea68cc6aa
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 21d065a6b80f71a092e875fea68cc6aa

