#!/bin/bash
#SBATCH --job-name="TestProject/825be3d4fe5807e2fd2166afa6195a51/mpi_op/8297ffdb68a85d6386c88b3dfe07f812"
#SBATCH --partition=cpu
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(825be3d4fe5807e2fd2166afa6195a51)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 825be3d4fe5807e2fd2166afa6195a51
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 825be3d4fe5807e2fd2166afa6195a51

