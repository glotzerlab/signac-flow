#!/bin/bash
#SBATCH --job-name="TestProject/825be3d4fe5807e2fd2166afa6195a51/multiline_cm/6eee08baeaddc8eaf80e90f5726f3df6"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(825be3d4fe5807e2fd2166afa6195a51)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 825be3d4fe5807e2fd2166afa6195a51
# Eligible to run:
# echo "First line"
# echo "Second line"

