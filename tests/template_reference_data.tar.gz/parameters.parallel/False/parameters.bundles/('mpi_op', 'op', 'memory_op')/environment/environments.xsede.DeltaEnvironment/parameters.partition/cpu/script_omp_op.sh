#!/bin/bash
#SBATCH --job-name="TestProject/825be3d4fe5807e2fd2166afa6195a51/omp_op/73765b921159ed93e5e48d40e57a4bda"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(825be3d4fe5807e2fd2166afa6195a51)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 825be3d4fe5807e2fd2166afa6195a51
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 825be3d4fe5807e2fd2166afa6195a51

