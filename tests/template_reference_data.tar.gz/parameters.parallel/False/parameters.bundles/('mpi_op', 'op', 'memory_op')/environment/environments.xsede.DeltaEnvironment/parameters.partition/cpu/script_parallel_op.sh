#!/bin/bash
#SBATCH --job-name="TestProject/825be3d4fe5807e2fd2166afa6195a51/parallel_op/341f542c13a5a1614746d94e54c42096"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(825be3d4fe5807e2fd2166afa6195a51)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 825be3d4fe5807e2fd2166afa6195a51
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 825be3d4fe5807e2fd2166afa6195a51

