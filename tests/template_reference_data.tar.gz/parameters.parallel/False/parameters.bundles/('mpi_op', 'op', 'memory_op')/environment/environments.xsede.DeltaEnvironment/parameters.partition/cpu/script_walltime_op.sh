#!/bin/bash
#SBATCH --job-name="TestProject/825be3d4fe5807e2fd2166afa6195a51/walltime_op/f06584e9931733e52585233bfcb6549c"
#SBATCH --partition=cpu
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(825be3d4fe5807e2fd2166afa6195a51)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 825be3d4fe5807e2fd2166afa6195a51
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 825be3d4fe5807e2fd2166afa6195a51

