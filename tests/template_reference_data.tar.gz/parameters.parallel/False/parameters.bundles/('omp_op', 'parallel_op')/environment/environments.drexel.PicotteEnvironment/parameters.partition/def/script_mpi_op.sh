#!/bin/bash
#SBATCH --job-name="TestProject/da44cc3f3f04b17f5e5b47b4cfbabe9d/mpi_op/299f3860377f5e689d2a8f674bb1dd54"
#SBATCH --partition=def
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(da44cc3f3f04b17f5e5b47b4cfbabe9d)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j da44cc3f3f04b17f5e5b47b4cfbabe9d
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op da44cc3f3f04b17f5e5b47b4cfbabe9d

