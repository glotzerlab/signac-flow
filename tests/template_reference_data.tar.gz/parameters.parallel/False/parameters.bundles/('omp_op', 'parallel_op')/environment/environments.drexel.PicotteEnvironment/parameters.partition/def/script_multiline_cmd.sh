#!/bin/bash
#SBATCH --job-name="TestProject/da44cc3f3f04b17f5e5b47b4cfbabe9d/multiline_cm/274a59e188d8094470013f0740ae5e4f"
#SBATCH --partition=def
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(da44cc3f3f04b17f5e5b47b4cfbabe9d)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j da44cc3f3f04b17f5e5b47b4cfbabe9d
# Eligible to run:
# echo "First line"
# echo "Second line"

