#!/bin/bash
#SBATCH --job-name="TestProject/da44cc3f3f04b17f5e5b47b4cfbabe9d/omp_op/c8d1f83daa6ef8bc1b596d4b29f2dee8"
#SBATCH --partition=def
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(da44cc3f3f04b17f5e5b47b4cfbabe9d)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j da44cc3f3f04b17f5e5b47b4cfbabe9d
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op da44cc3f3f04b17f5e5b47b4cfbabe9d

