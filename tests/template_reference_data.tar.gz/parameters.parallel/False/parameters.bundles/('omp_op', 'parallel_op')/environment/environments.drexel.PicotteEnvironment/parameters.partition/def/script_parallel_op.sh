#!/bin/bash
#SBATCH --job-name="TestProject/da44cc3f3f04b17f5e5b47b4cfbabe9d/parallel_op/2a36830772d602d7c9b4789898e8a61b"
#SBATCH --partition=def
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(da44cc3f3f04b17f5e5b47b4cfbabe9d)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j da44cc3f3f04b17f5e5b47b4cfbabe9d
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op da44cc3f3f04b17f5e5b47b4cfbabe9d

