#!/bin/bash
#SBATCH --job-name="TestProject/01a248645ee5a8c0c82dd8f9be369f6b/gpu_op/ce3523aa31659774c6010d5d10b04cf8"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(01a248645ee5a8c0c82dd8f9be369f6b)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 01a248645ee5a8c0c82dd8f9be369f6b
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op 01a248645ee5a8c0c82dd8f9be369f6b

