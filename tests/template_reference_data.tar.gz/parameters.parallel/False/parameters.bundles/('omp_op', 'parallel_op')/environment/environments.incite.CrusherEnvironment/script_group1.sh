#!/bin/bash
#SBATCH --job-name="TestProject/01a248645ee5a8c0c82dd8f9be369f6b/memory_oppar/b4e3d9302b3108111abf1429fbfd95c9"
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(01a248645ee5a8c0c82dd8f9be369f6b)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 01a248645ee5a8c0c82dd8f9be369f6b
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 01a248645ee5a8c0c82dd8f9be369f6b
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 01a248645ee5a8c0c82dd8f9be369f6b
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 01a248645ee5a8c0c82dd8f9be369f6b
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 01a248645ee5a8c0c82dd8f9be369f6b

