#!/bin/bash
#SBATCH --job-name="TestProject/01a248645ee5a8c0c82dd8f9be369f6b/memory_op/3ae287c5831992217400cedfaff44e26"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(01a248645ee5a8c0c82dd8f9be369f6b)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 01a248645ee5a8c0c82dd8f9be369f6b
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 01a248645ee5a8c0c82dd8f9be369f6b

