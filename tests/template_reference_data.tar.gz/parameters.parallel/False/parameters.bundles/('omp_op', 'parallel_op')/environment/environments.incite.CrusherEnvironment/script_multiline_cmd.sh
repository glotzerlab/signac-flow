#!/bin/bash
#SBATCH --job-name="TestProject/01a248645ee5a8c0c82dd8f9be369f6b/multiline_cm/d86a24e22cd1b5123aec9e8da022a88d"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(01a248645ee5a8c0c82dd8f9be369f6b)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 01a248645ee5a8c0c82dd8f9be369f6b
# Eligible to run:
# echo "First line"
# echo "Second line"

