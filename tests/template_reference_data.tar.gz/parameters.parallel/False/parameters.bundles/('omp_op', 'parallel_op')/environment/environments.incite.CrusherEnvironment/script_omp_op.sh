#!/bin/bash
#SBATCH --job-name="TestProject/01a248645ee5a8c0c82dd8f9be369f6b/omp_op/248f60840f3279e638d986de73dc6046"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(01a248645ee5a8c0c82dd8f9be369f6b)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 01a248645ee5a8c0c82dd8f9be369f6b
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 01a248645ee5a8c0c82dd8f9be369f6b

