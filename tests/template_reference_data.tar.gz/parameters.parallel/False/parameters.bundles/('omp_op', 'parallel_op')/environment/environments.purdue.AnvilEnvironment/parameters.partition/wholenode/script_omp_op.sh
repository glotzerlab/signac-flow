#!/bin/bash
#SBATCH --job-name="TestProject/05873a00521233b10edf9d7af980d6a9/omp_op/ff2f5eeaac33857553e7e1a859e8a35f"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(05873a00521233b10edf9d7af980d6a9)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 05873a00521233b10edf9d7af980d6a9
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 05873a00521233b10edf9d7af980d6a9

