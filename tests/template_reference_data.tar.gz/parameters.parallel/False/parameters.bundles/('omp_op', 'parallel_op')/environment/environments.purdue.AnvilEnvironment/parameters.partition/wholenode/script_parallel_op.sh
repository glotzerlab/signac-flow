#!/bin/bash
#SBATCH --job-name="TestProject/05873a00521233b10edf9d7af980d6a9/parallel_op/2bca21cf9e3aa9422733a6fc911d400c"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(05873a00521233b10edf9d7af980d6a9)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 05873a00521233b10edf9d7af980d6a9
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 05873a00521233b10edf9d7af980d6a9

