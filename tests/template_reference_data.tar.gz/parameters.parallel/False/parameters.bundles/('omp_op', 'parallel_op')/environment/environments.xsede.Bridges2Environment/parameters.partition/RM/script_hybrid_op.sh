#!/bin/bash
#SBATCH --job-name="TestProject/82a2b246ced909a3b3b171869bf2d50e/hybrid_op/0ec64f37c7932ecc5c44512daddd936b"
#SBATCH --partition=RM
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(82a2b246ced909a3b3b171869bf2d50e)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 82a2b246ced909a3b3b171869bf2d50e
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 82a2b246ced909a3b3b171869bf2d50e

