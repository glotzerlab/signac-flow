#!/bin/bash
#SBATCH --job-name="TestProject/82a2b246ced909a3b3b171869bf2d50e/memory_op/0650cf1f9ebb7295cd218fc0b421ed8f"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(82a2b246ced909a3b3b171869bf2d50e)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 82a2b246ced909a3b3b171869bf2d50e
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 82a2b246ced909a3b3b171869bf2d50e

