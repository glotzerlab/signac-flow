#!/bin/bash
#SBATCH --job-name="TestProject/82a2b246ced909a3b3b171869bf2d50e/mpi_op/9555d76c3b2fdb8cd34b9fb620970872"
#SBATCH --partition=RM
#SBATCH --ntasks=3
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(82a2b246ced909a3b3b171869bf2d50e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 82a2b246ced909a3b3b171869bf2d50e
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 82a2b246ced909a3b3b171869bf2d50e

