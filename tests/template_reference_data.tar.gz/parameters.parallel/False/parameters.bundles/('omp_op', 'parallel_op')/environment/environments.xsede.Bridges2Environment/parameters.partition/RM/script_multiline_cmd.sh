#!/bin/bash
#SBATCH --job-name="TestProject/82a2b246ced909a3b3b171869bf2d50e/multiline_cm/fbbfde8661e816a6a45641bf5937e655"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(82a2b246ced909a3b3b171869bf2d50e)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 82a2b246ced909a3b3b171869bf2d50e
# Eligible to run:
# echo "First line"
# echo "Second line"

