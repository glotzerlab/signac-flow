#!/bin/bash
#SBATCH --job-name="TestProject/82a2b246ced909a3b3b171869bf2d50e/omp_op/1cfc9dc941df4b53007bc4abd93f6af4"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(82a2b246ced909a3b3b171869bf2d50e)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 82a2b246ced909a3b3b171869bf2d50e
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 82a2b246ced909a3b3b171869bf2d50e

