#!/bin/bash
#SBATCH --job-name="TestProject/78430a2c66d3793e121b5320c74ec0f0/memory_op/1378a25be5f0eabb1a9adf3737498d9c"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(78430a2c66d3793e121b5320c74ec0f0)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 78430a2c66d3793e121b5320c74ec0f0
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 78430a2c66d3793e121b5320c74ec0f0

