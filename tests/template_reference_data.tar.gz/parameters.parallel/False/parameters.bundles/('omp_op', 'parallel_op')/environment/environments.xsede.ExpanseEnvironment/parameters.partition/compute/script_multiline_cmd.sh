#!/bin/bash
#SBATCH --job-name="TestProject/78430a2c66d3793e121b5320c74ec0f0/multiline_cm/9697ded6c6428075e5c246c1e3303379"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(78430a2c66d3793e121b5320c74ec0f0)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 78430a2c66d3793e121b5320c74ec0f0
# Eligible to run:
# echo "First line"
# echo "Second line"

