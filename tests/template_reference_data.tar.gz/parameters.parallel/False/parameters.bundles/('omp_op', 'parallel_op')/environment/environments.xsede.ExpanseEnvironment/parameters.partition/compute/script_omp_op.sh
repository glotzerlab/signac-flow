#!/bin/bash
#SBATCH --job-name="TestProject/78430a2c66d3793e121b5320c74ec0f0/omp_op/b20a7b6438363b9ac47557fd91b18766"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(78430a2c66d3793e121b5320c74ec0f0)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 78430a2c66d3793e121b5320c74ec0f0
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 78430a2c66d3793e121b5320c74ec0f0

