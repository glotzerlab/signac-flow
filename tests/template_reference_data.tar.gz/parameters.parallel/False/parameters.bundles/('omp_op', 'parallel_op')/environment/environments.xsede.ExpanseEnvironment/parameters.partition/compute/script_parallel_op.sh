#!/bin/bash
#SBATCH --job-name="TestProject/78430a2c66d3793e121b5320c74ec0f0/parallel_op/419ab5995cef932fdbd546e159ba627e"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(78430a2c66d3793e121b5320c74ec0f0)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 78430a2c66d3793e121b5320c74ec0f0
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 78430a2c66d3793e121b5320c74ec0f0

