#!/bin/bash
#SBATCH --job-name="TestProject/78430a2c66d3793e121b5320c74ec0f0/walltime_op/4df257fcc4540c0f250b84eb3a665b09"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(78430a2c66d3793e121b5320c74ec0f0)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 78430a2c66d3793e121b5320c74ec0f0
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 78430a2c66d3793e121b5320c74ec0f0

