#!/bin/bash
#SBATCH --job-name="SubmissionTe/9e2461fe/mpi_op/0000/ab904874f9d3547eaa8f9085993d4f66"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op(9e2461fecf22da9d3a066c883cd7f10a)
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 9e2461fecf22da9d3a066c883cd7f10a &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 9e2461fecf22da9d3a066c883cd7f10a

wait

