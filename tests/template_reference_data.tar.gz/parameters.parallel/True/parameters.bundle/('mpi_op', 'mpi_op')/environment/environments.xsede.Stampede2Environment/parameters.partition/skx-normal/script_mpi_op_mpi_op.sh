#!/bin/bash
#SBATCH --job-name="SubmissionTe/9e2461fe/mpi_op/0000/8e35b3b6ffee3da2069ae2665530817f"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(9e2461fecf22da9d3a066c883cd7f10a)
ibrun -n 5 -o 0 task_affinity /usr/local/bin/python generate_template_reference_data.py exec mpi_op 9e2461fecf22da9d3a066c883cd7f10a &
wait

