#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/f8a3ce4c39881232e35b662c45787841e887beae"
#SBATCH --partition=def
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd /home/user/project/

# mpi_op(a9049bd72bc8dd97cd1f92c20b1422c8)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a9049bd72bc8dd97cd1f92c20b1422c8 &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op a9049bd72bc8dd97cd1f92c20b1422c8

# omp_op(a9049bd72bc8dd97cd1f92c20b1422c8)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a9049bd72bc8dd97cd1f92c20b1422c8 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op a9049bd72bc8dd97cd1f92c20b1422c8
wait

