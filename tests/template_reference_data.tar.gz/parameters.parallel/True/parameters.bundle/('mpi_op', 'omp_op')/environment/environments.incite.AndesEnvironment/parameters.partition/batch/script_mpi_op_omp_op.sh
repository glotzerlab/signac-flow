#!/bin/bash
#SBATCH --job-name="TestProject/bundle/2ed4c0da0bfbe42382f5f3871714dfb25fa80022"
#SBATCH --partition=batch
#SBATCH -N 1
#SBATCH --ntasks=

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(ebc20d2a814c515e90c3b6539fa4a26a)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j ebc20d2a814c515e90c3b6539fa4a26a &
# Eligible to run:
# srun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op ebc20d2a814c515e90c3b6539fa4a26a

# omp_op(ebc20d2a814c515e90c3b6539fa4a26a)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j ebc20d2a814c515e90c3b6539fa4a26a &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op ebc20d2a814c515e90c3b6539fa4a26a
wait

