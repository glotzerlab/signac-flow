#!/bin/bash
#BSUB -J SubmissionTest/bundle/9dd6bb4b79036f6b4b59bbc7f314ff45a49cc3a3
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(b5e1e432028b526a72809767e5e0074f)
jsrun -n 5 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_op b5e1e432028b526a72809767e5e0074f &

# omp_op(b5e1e432028b526a72809767e5e0074f)
export OMP_NUM_THREADS=4
jsrun -n 1 -a 1 -c 4 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec omp_op b5e1e432028b526a72809767e5e0074f &
wait

