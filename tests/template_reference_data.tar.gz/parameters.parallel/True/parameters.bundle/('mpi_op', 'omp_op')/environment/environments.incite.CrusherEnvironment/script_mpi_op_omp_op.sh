ERROR: Template requires GPU jobs.
