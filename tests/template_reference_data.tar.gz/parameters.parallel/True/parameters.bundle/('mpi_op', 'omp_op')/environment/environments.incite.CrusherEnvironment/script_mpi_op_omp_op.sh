#!/bin/bash
#SBATCH --job-name="TestProject/bundle/8b1d4ff1e9560456853a4030896bee52d8de52e5"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(0286f7b4ccfe0ee6ac7e749fbad35fe4)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0286f7b4ccfe0ee6ac7e749fbad35fe4 &
# Eligible to run:
# srun --ntasks=5 --cpus-per-task=1 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 0286f7b4ccfe0ee6ac7e749fbad35fe4

# omp_op(0286f7b4ccfe0ee6ac7e749fbad35fe4)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0286f7b4ccfe0ee6ac7e749fbad35fe4 &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=0 --cpus-per-task=4 --gpus=0 /usr/local/bin/python generate_template_reference_data.py exec omp_op 0286f7b4ccfe0ee6ac7e749fbad35fe4
wait

