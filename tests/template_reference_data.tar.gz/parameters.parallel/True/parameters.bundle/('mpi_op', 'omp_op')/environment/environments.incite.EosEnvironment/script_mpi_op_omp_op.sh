#PBS -N SubmissionTest/bundle/c5da7ea4cd8962488ad112586f47595f23ee307b
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# mpi_op(def67f27e79966e068d16dcf943a7921)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op def67f27e79966e068d16dcf943a7921 &

# omp_op(def67f27e79966e068d16dcf943a7921)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op def67f27e79966e068d16dcf943a7921 &
wait

