#!/bin/bash
#BSUB -J SubmissionTest/bundle/c515991e268ec637ffe5a1f39e023c6abf3a5695
#BSUB -nnodes 1
#BSUB -P MAT110

set -e
set -u

cd /home/user/project/

# mpi_op(9eadf93ad5371afb3e6e353591ea62d1)
jsrun -n 5 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_op 9eadf93ad5371afb3e6e353591ea62d1 &

# omp_op(9eadf93ad5371afb3e6e353591ea62d1)
export OMP_NUM_THREADS=4
jsrun -n 1 -a 1 -c 4 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec omp_op 9eadf93ad5371afb3e6e353591ea62d1 &
wait

