#!/bin/bash
#BSUB -J TestProject/bundle/7f5f7b20379d3b3dc37d5bd79a11745822f1e7d1
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(9eadf93ad5371afb3e6e353591ea62d1)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 9eadf93ad5371afb3e6e353591ea62d1 &
# Eligible to run:
# jsrun -n 5 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 9eadf93ad5371afb3e6e353591ea62d1

# omp_op(9eadf93ad5371afb3e6e353591ea62d1)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 9eadf93ad5371afb3e6e353591ea62d1 &
# Eligible to run:
# export OMP_NUM_THREADS=4; jsrun -n 1 -a 1 -c 4 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec omp_op 9eadf93ad5371afb3e6e353591ea62d1
wait

