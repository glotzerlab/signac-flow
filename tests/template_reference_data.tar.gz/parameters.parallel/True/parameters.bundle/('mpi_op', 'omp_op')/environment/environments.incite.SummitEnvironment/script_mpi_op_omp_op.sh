#!/bin/bash
#BSUB -J SubmissionTest/bundle/c515991e268ec637ffe5a1f39e023c6abf3a5695
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(9eadf93ad5371afb3e6e353591ea62d1)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 9eadf93ad5371afb3e6e353591ea62d1 &
# Eligible to run:
# mpiexec -n 5  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec mpi_op 9eadf93ad5371afb3e6e353591ea62d1

# omp_op(9eadf93ad5371afb3e6e353591ea62d1)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 9eadf93ad5371afb3e6e353591ea62d1 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec omp_op 9eadf93ad5371afb3e6e353591ea62d1
wait

