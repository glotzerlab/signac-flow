#!/bin/bash
#BSUB -J SubmissionTest/bundle/db230a9ddc3ffed1595cac5b4ea8c529e1bb14b6
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op[#1](9ea)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 9eadf93ad5371afb3e6e353591ea62d1 &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 9eadf93ad5371afb3e6e353591ea62d1

# omp_op[#1](9ea)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 9eadf93ad5371afb3e6e353591ea62d1 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 9eadf93ad5371afb3e6e353591ea62d1
wait

