#PBS -N SubmissionTest/bundle/78748be2c9868c4413c3919baf1e2315f603330f
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# mpi_op(29110bb20bd8a85768c9201d72139c85)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 29110bb20bd8a85768c9201d72139c85 &

# omp_op(29110bb20bd8a85768c9201d72139c85)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 29110bb20bd8a85768c9201d72139c85 &
wait

