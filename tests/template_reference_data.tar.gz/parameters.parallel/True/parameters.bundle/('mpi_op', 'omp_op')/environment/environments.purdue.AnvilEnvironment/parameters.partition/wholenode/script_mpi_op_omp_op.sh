#!/bin/bash
#SBATCH --job-name="TestProject/bundle/97a6ead76705db66ba56f33b31e698b52632df92"
#SBATCH --partition=wholenode
#SBATCH --ntasks=9

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(a61d7432147fcc19abe2be3c6104753e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a61d7432147fcc19abe2be3c6104753e &
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op a61d7432147fcc19abe2be3c6104753e

# omp_op(a61d7432147fcc19abe2be3c6104753e)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a61d7432147fcc19abe2be3c6104753e &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op a61d7432147fcc19abe2be3c6104753e
wait

