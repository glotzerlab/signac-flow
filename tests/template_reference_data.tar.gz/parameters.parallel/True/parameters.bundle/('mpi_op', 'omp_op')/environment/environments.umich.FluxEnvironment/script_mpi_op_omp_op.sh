#PBS -N SubmissionTest/bundle/264275995a49336b2e89838f6784cb2cd144e90b
#PBS -V
#PBS -l nodes=3:ppn=4
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/user/project/

# mpi_op(4337ec17629a91d60dd5750b224ebedc)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 4337ec17629a91d60dd5750b224ebedc &

# omp_op(4337ec17629a91d60dd5750b224ebedc)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 4337ec17629a91d60dd5750b224ebedc &
wait

