#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/a3503161fe2c9b9158456e20dcb7f7ae169ace7f"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd /home/user/project/

# mpi_op[#1](b9400a2ff992d9bd5ccfd2ced78b21e6)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j b9400a2ff992d9bd5ccfd2ced78b21e6 &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op b9400a2ff992d9bd5ccfd2ced78b21e6

# omp_op[#1](b9400a2ff992d9bd5ccfd2ced78b21e6)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j b9400a2ff992d9bd5ccfd2ced78b21e6 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op b9400a2ff992d9bd5ccfd2ced78b21e6
wait

