#!/bin/bash
#SBATCH --job-name="TestProject/bundle/33583db04b7daa02725285c6c5013b204c7416fd"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks=9

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(b9400a2ff992d9bd5ccfd2ced78b21e6)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j b9400a2ff992d9bd5ccfd2ced78b21e6 &
# Eligible to run:
# srun -u --export=ALL -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op b9400a2ff992d9bd5ccfd2ced78b21e6

# omp_op(b9400a2ff992d9bd5ccfd2ced78b21e6)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j b9400a2ff992d9bd5ccfd2ced78b21e6 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op b9400a2ff992d9bd5ccfd2ced78b21e6
wait

