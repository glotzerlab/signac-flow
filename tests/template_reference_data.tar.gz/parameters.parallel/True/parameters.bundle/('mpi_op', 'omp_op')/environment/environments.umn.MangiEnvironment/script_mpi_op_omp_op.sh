#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/816673c14a5d154b96ff355686361742b2f532c6"
#SBATCH -t 12:00:00
#SBATCH --ntasks=9

set -e
set -u

cd /home/user/project/

# mpi_op(478b051469a922cc03d12a8993f42719)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 478b051469a922cc03d12a8993f42719 &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 478b051469a922cc03d12a8993f42719

# omp_op(478b051469a922cc03d12a8993f42719)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 478b051469a922cc03d12a8993f42719 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 478b051469a922cc03d12a8993f42719
wait

