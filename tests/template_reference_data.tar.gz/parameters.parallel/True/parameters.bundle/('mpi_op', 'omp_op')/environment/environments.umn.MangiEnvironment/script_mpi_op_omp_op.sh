#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/e0b466998280ab253402edf81aa6679cc491658a"
#SBATCH --ntasks=9

set -e
set -u

cd /home/user/project/

# mpi_op[#1](478b051469a922cc03d12a8993f42719)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 478b051469a922cc03d12a8993f42719 &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 478b051469a922cc03d12a8993f42719

# omp_op[#1](478b051469a922cc03d12a8993f42719)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 478b051469a922cc03d12a8993f42719 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 478b051469a922cc03d12a8993f42719
wait

