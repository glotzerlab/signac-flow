#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/e04adabb2bc7994634e27d844d7d1560ea85d001"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd "/home/user/path with spaces and \"quotes\" and \\backslashes/"

# mpi_op(961479e1f41d9d51d5e541b3c1b76661)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 961479e1f41d9d51d5e541b3c1b76661 &
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 961479e1f41d9d51d5e541b3c1b76661

# omp_op(961479e1f41d9d51d5e541b3c1b76661)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 961479e1f41d9d51d5e541b3c1b76661 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 961479e1f41d9d51d5e541b3c1b76661
wait

