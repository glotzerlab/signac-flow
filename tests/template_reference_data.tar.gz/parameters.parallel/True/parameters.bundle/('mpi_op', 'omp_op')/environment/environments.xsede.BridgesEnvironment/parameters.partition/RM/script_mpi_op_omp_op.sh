#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/7f2d0124f56d904c3a20ce85dee454a02195ed17"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd /home/user/project/

# mpi_op(a5e3b313aaf6e78c0f4dd8b58e83949e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a5e3b313aaf6e78c0f4dd8b58e83949e &
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op a5e3b313aaf6e78c0f4dd8b58e83949e

# omp_op(a5e3b313aaf6e78c0f4dd8b58e83949e)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a5e3b313aaf6e78c0f4dd8b58e83949e &
# Eligible to run:
# export OMP_NUM_THREADS=4
 /usr/local/bin/python generate_template_reference_data.py exec omp_op a5e3b313aaf6e78c0f4dd8b58e83949e
wait

