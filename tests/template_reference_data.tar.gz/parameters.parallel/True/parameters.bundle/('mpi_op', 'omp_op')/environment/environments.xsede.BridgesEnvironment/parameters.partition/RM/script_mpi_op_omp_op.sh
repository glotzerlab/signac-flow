#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/7f2d0124f56d904c3a20ce85dee454a02195ed17"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd /home/user/project/

# mpi_op(a5e3b313aaf6e78c0f4dd8b58e83949e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a5e3b313aaf6e78c0f4dd8b58e83949e --parallel &

# omp_op(a5e3b313aaf6e78c0f4dd8b58e83949e)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a5e3b313aaf6e78c0f4dd8b58e83949e --parallel &
wait

