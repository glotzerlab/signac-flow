#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/988b8cd7a2b7a89df5f5927bfec1ff02bc66f246"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd /home/johndoe/project/

# mpi_op(a5e3b313aaf6e78c0f4dd8b58e83949e)
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op a5e3b313aaf6e78c0f4dd8b58e83949e &

# omp_op(a5e3b313aaf6e78c0f4dd8b58e83949e)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op a5e3b313aaf6e78c0f4dd8b58e83949e &
wait

