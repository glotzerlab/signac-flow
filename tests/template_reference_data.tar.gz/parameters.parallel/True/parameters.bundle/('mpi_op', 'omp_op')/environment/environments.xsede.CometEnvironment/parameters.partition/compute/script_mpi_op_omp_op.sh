#!/bin/bash
#SBATCH --job-name="SubmissionTest/bundle/e035a850eeae778213f4fcbefccfdeb8109446d0"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=9

set -e
set -u

cd /home/user/project/

# mpi_op(f10cfc6dd4fd8c29187aa1971ff2fd87)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j f10cfc6dd4fd8c29187aa1971ff2fd87 --parallel &
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec mpi_op f10cfc6dd4fd8c29187aa1971ff2fd87

# omp_op(f10cfc6dd4fd8c29187aa1971ff2fd87)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j f10cfc6dd4fd8c29187aa1971ff2fd87 --parallel &
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec omp_op f10cfc6dd4fd8c29187aa1971ff2fd87
wait

