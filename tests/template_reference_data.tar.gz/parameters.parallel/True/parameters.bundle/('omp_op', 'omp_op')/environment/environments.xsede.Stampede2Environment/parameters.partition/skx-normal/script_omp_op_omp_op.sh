None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/593a9106d2d57ba02b9ed29df92002e5/omp_op/2a16247c5a1cef9ffaecbdcd6cf19339"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# omp_op(593a9106d2d57ba02b9ed29df92002e5)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 593a9106d2d57ba02b9ed29df92002e5 &
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 593a9106d2d57ba02b9ed29df92002e5

wait

