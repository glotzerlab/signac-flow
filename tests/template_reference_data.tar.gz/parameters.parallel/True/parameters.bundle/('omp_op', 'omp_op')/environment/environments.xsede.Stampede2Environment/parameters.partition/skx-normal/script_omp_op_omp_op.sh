#!/bin/bash
#SBATCH --job-name="SubmissionTe/593a9106/omp_op/0000/eb631642781f6cb888181d3937251c2b"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(593a9106d2d57ba02b9ed29df92002e5)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 593a9106d2d57ba02b9ed29df92002e5 &
wait

