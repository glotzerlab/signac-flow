#!/bin/bash
#SBATCH --job-name="TestProject/60117e9976c1b060abcff2cd0ad82f08/memory_oppar/284b08206f19537f904e9241708b4ad3"
#SBATCH --partition=batch
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem-per-task=171M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(60117e9976c1b060abcff2cd0ad82f08)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 60117e9976c1b060abcff2cd0ad82f08 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 60117e9976c1b060abcff2cd0ad82f08
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 60117e9976c1b060abcff2cd0ad82f08
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 60117e9976c1b060abcff2cd0ad82f08
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 60117e9976c1b060abcff2cd0ad82f08
wait

