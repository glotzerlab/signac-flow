#!/bin/bash
#SBATCH --job-name="TestProject/60117e9976c1b060abcff2cd0ad82f08/hybrid_op/15f292800219480ac9274230d05bfd86"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(60117e9976c1b060abcff2cd0ad82f08)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 60117e9976c1b060abcff2cd0ad82f08 &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 60117e9976c1b060abcff2cd0ad82f08
wait

