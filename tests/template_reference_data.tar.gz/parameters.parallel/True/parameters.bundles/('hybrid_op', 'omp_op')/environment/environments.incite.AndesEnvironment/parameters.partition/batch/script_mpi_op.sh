#!/bin/bash
#SBATCH --job-name="TestProject/60117e9976c1b060abcff2cd0ad82f08/mpi_op/9d0ae1cf267f1ebee9e8348226028676"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(60117e9976c1b060abcff2cd0ad82f08)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 60117e9976c1b060abcff2cd0ad82f08 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 60117e9976c1b060abcff2cd0ad82f08
wait

