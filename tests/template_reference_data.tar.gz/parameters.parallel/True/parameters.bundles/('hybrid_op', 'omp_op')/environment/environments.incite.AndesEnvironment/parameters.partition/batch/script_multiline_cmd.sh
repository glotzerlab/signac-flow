#!/bin/bash
#SBATCH --job-name="TestProject/60117e9976c1b060abcff2cd0ad82f08/multiline_cm/9b05ee1c1a3d2e2f54d83fe5068808ea"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(60117e9976c1b060abcff2cd0ad82f08)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 60117e9976c1b060abcff2cd0ad82f08 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

