#!/bin/bash
#SBATCH --job-name="TestProject/60117e9976c1b060abcff2cd0ad82f08/omp_op/be8fc5d995e7d9d29a9257b34533866a"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(60117e9976c1b060abcff2cd0ad82f08)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 60117e9976c1b060abcff2cd0ad82f08 &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 60117e9976c1b060abcff2cd0ad82f08
wait

