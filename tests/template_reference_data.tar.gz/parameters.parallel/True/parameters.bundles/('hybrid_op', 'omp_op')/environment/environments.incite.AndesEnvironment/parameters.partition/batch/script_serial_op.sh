#!/bin/bash
#SBATCH --job-name="TestProject/60117e9976c1b060abcff2cd0ad82f08/serial_op/b1bfe89d19a4494532348cd1a24ef8ed"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(60117e9976c1b060abcff2cd0ad82f08)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 60117e9976c1b060abcff2cd0ad82f08 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 60117e9976c1b060abcff2cd0ad82f08
wait

