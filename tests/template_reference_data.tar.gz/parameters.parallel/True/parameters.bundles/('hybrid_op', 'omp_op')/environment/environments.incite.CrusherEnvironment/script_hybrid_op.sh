#!/bin/bash
#SBATCH --job-name="TestProject/b40e714d325c28ea81c452dad7c1c97b/hybrid_op/f7b2bf593bdad05a7d21b445572bb439"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(b40e714d325c28ea81c452dad7c1c97b)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j b40e714d325c28ea81c452dad7c1c97b &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op b40e714d325c28ea81c452dad7c1c97b
wait

