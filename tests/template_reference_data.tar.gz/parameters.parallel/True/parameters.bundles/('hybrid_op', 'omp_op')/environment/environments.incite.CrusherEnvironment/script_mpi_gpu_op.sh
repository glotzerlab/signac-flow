#!/bin/bash
#SBATCH --job-name="TestProject/b40e714d325c28ea81c452dad7c1c97b/mpi_gpu_op/075a73faaa82ebfc80afd145c97e22f5"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(b40e714d325c28ea81c452dad7c1c97b)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j b40e714d325c28ea81c452dad7c1c97b &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op b40e714d325c28ea81c452dad7c1c97b
wait

