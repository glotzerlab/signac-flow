#!/bin/bash
#SBATCH --job-name="TestProject/b40e714d325c28ea81c452dad7c1c97b/multiline_cm/4c4f1988304b2359cc7f330cdcb51a24"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(b40e714d325c28ea81c452dad7c1c97b)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j b40e714d325c28ea81c452dad7c1c97b &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

