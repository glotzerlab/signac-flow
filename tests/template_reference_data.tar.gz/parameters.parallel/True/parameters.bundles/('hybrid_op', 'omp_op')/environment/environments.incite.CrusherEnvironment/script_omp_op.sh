#!/bin/bash
#SBATCH --job-name="TestProject/b40e714d325c28ea81c452dad7c1c97b/omp_op/9c9d496701b5825cd964d03cc6a61325"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(b40e714d325c28ea81c452dad7c1c97b)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j b40e714d325c28ea81c452dad7c1c97b &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op b40e714d325c28ea81c452dad7c1c97b
wait

