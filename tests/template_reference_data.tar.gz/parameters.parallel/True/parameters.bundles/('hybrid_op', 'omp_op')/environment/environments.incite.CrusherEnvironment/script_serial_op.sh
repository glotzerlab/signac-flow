#!/bin/bash
#SBATCH --job-name="TestProject/b40e714d325c28ea81c452dad7c1c97b/serial_op/8a7be885d9b96ecd42d3d13dc0c6d38b"
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(b40e714d325c28ea81c452dad7c1c97b)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j b40e714d325c28ea81c452dad7c1c97b &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op b40e714d325c28ea81c452dad7c1c97b
wait

