#!/bin/bash
#SBATCH --job-name="TestProject/b40e714d325c28ea81c452dad7c1c97b/walltime_op/e87b4e19f618e83dd3b605a94745a48d"
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --partition=batch

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(b40e714d325c28ea81c452dad7c1c97b)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j b40e714d325c28ea81c452dad7c1c97b &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op b40e714d325c28ea81c452dad7c1c97b
wait

