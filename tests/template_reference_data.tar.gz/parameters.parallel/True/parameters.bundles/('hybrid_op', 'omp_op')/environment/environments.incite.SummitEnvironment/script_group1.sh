'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/memory_oppar/3c7a2883e5cd2f806739a039e23e3eca
#BSUB -M 512MB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
# 
# 
# 
wait

