'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/hybrid_op/ed1e74910fccf265217d4ad3fb671f87
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
wait

