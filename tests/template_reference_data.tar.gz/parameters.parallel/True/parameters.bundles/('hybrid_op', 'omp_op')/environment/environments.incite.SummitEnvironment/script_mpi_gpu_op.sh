'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/mpi_gpu_op/10b7974001f631dc5d4c59f2eb5161c1
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
wait

