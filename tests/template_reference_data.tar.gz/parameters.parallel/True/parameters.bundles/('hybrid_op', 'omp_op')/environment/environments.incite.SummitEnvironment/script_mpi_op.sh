'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/mpi_op/9a592f7c44409228a86f84fa762a7368
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
wait

