#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/multiline_cm/cf71b2d9cacad7794e77e4d49d886185
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

