'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/omp_op/622fe140cf055ee7ced67ab19858a65a
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
wait

