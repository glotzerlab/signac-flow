'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/parallel_op/3dc041343508783fbae64c55b90ca561
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
wait

