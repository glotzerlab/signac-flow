'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/serial_op/dffadd6bce62d16f1cf9e18436a20263
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
wait

