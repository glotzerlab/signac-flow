'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/0c80b66f0efc31354526485fb2858f3b/walltime_op/91331072cd0fc265dab7769c8bc41826
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(0c80b66f0efc31354526485fb2858f3b)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 0c80b66f0efc31354526485fb2858f3b &
# Eligible to run:
# 
wait

