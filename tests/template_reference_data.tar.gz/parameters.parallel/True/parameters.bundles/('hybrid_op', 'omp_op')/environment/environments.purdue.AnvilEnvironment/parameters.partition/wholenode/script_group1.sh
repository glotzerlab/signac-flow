#!/bin/bash
#SBATCH --job-name="TestProject/d6ac73e48003156cba20ea81d201c255/memory_oppar/837203f90d7f66038136a6689fbd89ac"
#SBATCH --partition=wholenode
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem-per-task=171M
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(d6ac73e48003156cba20ea81d201c255)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j d6ac73e48003156cba20ea81d201c255 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op d6ac73e48003156cba20ea81d201c255
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op d6ac73e48003156cba20ea81d201c255
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op d6ac73e48003156cba20ea81d201c255
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op d6ac73e48003156cba20ea81d201c255
wait

