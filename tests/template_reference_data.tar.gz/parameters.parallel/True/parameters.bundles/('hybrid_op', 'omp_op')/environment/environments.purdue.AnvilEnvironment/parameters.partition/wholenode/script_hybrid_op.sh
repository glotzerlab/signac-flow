#!/bin/bash
#SBATCH --job-name="TestProject/d6ac73e48003156cba20ea81d201c255/hybrid_op/40a32342a810aad313aab1f60543953f"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(d6ac73e48003156cba20ea81d201c255)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j d6ac73e48003156cba20ea81d201c255 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op d6ac73e48003156cba20ea81d201c255
wait

