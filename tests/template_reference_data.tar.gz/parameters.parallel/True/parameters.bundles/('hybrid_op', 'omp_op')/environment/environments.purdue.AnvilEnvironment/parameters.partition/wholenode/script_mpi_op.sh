#!/bin/bash
#SBATCH --job-name="TestProject/d6ac73e48003156cba20ea81d201c255/mpi_op/f387271f203348db61e3a281e7066bd2"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(d6ac73e48003156cba20ea81d201c255)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j d6ac73e48003156cba20ea81d201c255 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op d6ac73e48003156cba20ea81d201c255
wait

