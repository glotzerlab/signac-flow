#!/bin/bash
#SBATCH --job-name="TestProject/d6ac73e48003156cba20ea81d201c255/omp_op/e9cb299092a109a65b32e8fffff1aa95"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(d6ac73e48003156cba20ea81d201c255)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j d6ac73e48003156cba20ea81d201c255 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op d6ac73e48003156cba20ea81d201c255
wait

