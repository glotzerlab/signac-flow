#!/bin/bash
#SBATCH --job-name="TestProject/0fb7f07d861ea25d0c4d647c402182f9/gpu_op/6ba5386ed8872b3251ccd05ed0966c00"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(0fb7f07d861ea25d0c4d647c402182f9)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 0fb7f07d861ea25d0c4d647c402182f9 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op 0fb7f07d861ea25d0c4d647c402182f9
wait

