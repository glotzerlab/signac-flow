#!/bin/bash
#SBATCH --job-name="TestProject/0fb7f07d861ea25d0c4d647c402182f9/memory_op/689617a7326106296e0819cd865270a6"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(0fb7f07d861ea25d0c4d647c402182f9)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 0fb7f07d861ea25d0c4d647c402182f9 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 0fb7f07d861ea25d0c4d647c402182f9
wait

