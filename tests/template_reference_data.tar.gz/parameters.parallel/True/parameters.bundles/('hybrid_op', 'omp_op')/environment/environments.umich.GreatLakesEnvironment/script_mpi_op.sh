#!/bin/bash
#SBATCH --job-name="TestProject/0fb7f07d861ea25d0c4d647c402182f9/mpi_op/2d77466e020b742a6ac9aa8b20c52e42"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(0fb7f07d861ea25d0c4d647c402182f9)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0fb7f07d861ea25d0c4d647c402182f9 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 0fb7f07d861ea25d0c4d647c402182f9
wait

