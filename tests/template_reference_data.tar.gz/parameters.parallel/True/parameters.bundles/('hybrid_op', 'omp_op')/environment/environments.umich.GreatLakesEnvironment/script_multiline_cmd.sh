#!/bin/bash
#SBATCH --job-name="TestProject/0fb7f07d861ea25d0c4d647c402182f9/multiline_cm/9ecc0f4ad60c3c643a12616703a90a63"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(0fb7f07d861ea25d0c4d647c402182f9)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 0fb7f07d861ea25d0c4d647c402182f9 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

