#!/bin/bash
#SBATCH --job-name="TestProject/0fb7f07d861ea25d0c4d647c402182f9/walltime_op/cac3ebfc4b366e44dd2dec785853223e"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(0fb7f07d861ea25d0c4d647c402182f9)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 0fb7f07d861ea25d0c4d647c402182f9 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 0fb7f07d861ea25d0c4d647c402182f9
wait

