#!/bin/bash
#SBATCH --job-name="TestProject/bf6c8cfc2446a71aa58d039d0ad6969e/gpu_op/b6ac327afa4ff5578c8c59abacaaaa05"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(bf6c8cfc2446a71aa58d039d0ad6969e)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j bf6c8cfc2446a71aa58d039d0ad6969e &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op bf6c8cfc2446a71aa58d039d0ad6969e
wait

