#!/bin/bash
#SBATCH --job-name="TestProject/bf6c8cfc2446a71aa58d039d0ad6969e/memory_oppar/6c2187323ca5d58d3e56d09d98cf3a96"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem-per-task=171M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(bf6c8cfc2446a71aa58d039d0ad6969e)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j bf6c8cfc2446a71aa58d039d0ad6969e &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op bf6c8cfc2446a71aa58d039d0ad6969e
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op bf6c8cfc2446a71aa58d039d0ad6969e
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op bf6c8cfc2446a71aa58d039d0ad6969e
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op bf6c8cfc2446a71aa58d039d0ad6969e
wait

