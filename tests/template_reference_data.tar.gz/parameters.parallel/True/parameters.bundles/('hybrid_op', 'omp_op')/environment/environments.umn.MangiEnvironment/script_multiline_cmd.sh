#!/bin/bash
#SBATCH --job-name="TestProject/bf6c8cfc2446a71aa58d039d0ad6969e/multiline_cm/06af9bbe037c69951aa3495175300564"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(bf6c8cfc2446a71aa58d039d0ad6969e)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j bf6c8cfc2446a71aa58d039d0ad6969e &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

