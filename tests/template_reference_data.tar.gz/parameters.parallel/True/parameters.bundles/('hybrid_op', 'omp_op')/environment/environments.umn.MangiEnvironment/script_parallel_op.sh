#!/bin/bash
#SBATCH --job-name="TestProject/bf6c8cfc2446a71aa58d039d0ad6969e/parallel_op/df56479e91ddd820d755cb9a168a07d7"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(bf6c8cfc2446a71aa58d039d0ad6969e)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j bf6c8cfc2446a71aa58d039d0ad6969e &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op bf6c8cfc2446a71aa58d039d0ad6969e
wait

