#!/bin/bash
#SBATCH --job-name="TestProject/bf6c8cfc2446a71aa58d039d0ad6969e/serial_op/e03b6001d7899403566a4b18715b69d2"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(bf6c8cfc2446a71aa58d039d0ad6969e)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j bf6c8cfc2446a71aa58d039d0ad6969e &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op bf6c8cfc2446a71aa58d039d0ad6969e
wait

