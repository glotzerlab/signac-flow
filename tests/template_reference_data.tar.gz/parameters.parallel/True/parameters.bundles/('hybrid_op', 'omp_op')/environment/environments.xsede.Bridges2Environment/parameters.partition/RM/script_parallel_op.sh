#!/bin/bash
#SBATCH --job-name="TestProject/1fa63347af13ed5e420444dfcf3ba81b/parallel_op/ebb4369d69af03c6ead4cee25cb87bd3"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(1fa63347af13ed5e420444dfcf3ba81b)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 1fa63347af13ed5e420444dfcf3ba81b &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 1fa63347af13ed5e420444dfcf3ba81b
wait

