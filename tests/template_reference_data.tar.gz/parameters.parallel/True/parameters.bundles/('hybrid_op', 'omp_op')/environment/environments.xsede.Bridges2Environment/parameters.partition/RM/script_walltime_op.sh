#!/bin/bash
#SBATCH --job-name="TestProject/1fa63347af13ed5e420444dfcf3ba81b/walltime_op/4cb16b35be0564511fe4fbb939b0f18a"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(1fa63347af13ed5e420444dfcf3ba81b)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 1fa63347af13ed5e420444dfcf3ba81b &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 1fa63347af13ed5e420444dfcf3ba81b
wait

