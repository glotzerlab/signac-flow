#!/bin/bash
#SBATCH --job-name="TestProject/a7e6fd7cd9edcae9ec7c3bf05dc47862/mpi_op/e5b2a97bca9439b647eca65dda71d05e"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(a7e6fd7cd9edcae9ec7c3bf05dc47862)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a7e6fd7cd9edcae9ec7c3bf05dc47862 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op a7e6fd7cd9edcae9ec7c3bf05dc47862
wait

