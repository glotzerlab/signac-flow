#!/bin/bash
#SBATCH --job-name="TestProject/a7e6fd7cd9edcae9ec7c3bf05dc47862/multiline_cm/832be5f9aa96c774a5b2faf8bb049dac"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(a7e6fd7cd9edcae9ec7c3bf05dc47862)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j a7e6fd7cd9edcae9ec7c3bf05dc47862 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

