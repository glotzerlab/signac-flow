#!/bin/bash
#SBATCH --job-name="TestProject/a7e6fd7cd9edcae9ec7c3bf05dc47862/omp_op/b37e0756514d5f9755163d83f5990141"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(a7e6fd7cd9edcae9ec7c3bf05dc47862)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a7e6fd7cd9edcae9ec7c3bf05dc47862 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op a7e6fd7cd9edcae9ec7c3bf05dc47862
wait

