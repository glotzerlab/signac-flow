#!/bin/bash
#SBATCH --job-name="TestProject/a7e6fd7cd9edcae9ec7c3bf05dc47862/parallel_op/ecc641f524aad3dd06a658c9986b191e"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(a7e6fd7cd9edcae9ec7c3bf05dc47862)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j a7e6fd7cd9edcae9ec7c3bf05dc47862 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op a7e6fd7cd9edcae9ec7c3bf05dc47862
wait

