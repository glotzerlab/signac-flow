#!/bin/bash
#SBATCH --job-name="TestProject/a7e6fd7cd9edcae9ec7c3bf05dc47862/walltime_op/6aa0bf3c24d96111edc8cf24f597de3a"
#SBATCH --partition=cpu
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(a7e6fd7cd9edcae9ec7c3bf05dc47862)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j a7e6fd7cd9edcae9ec7c3bf05dc47862 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op a7e6fd7cd9edcae9ec7c3bf05dc47862
wait

