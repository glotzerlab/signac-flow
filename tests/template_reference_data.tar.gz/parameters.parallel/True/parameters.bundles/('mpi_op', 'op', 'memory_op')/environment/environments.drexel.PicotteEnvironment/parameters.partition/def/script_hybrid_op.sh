#!/bin/bash
#SBATCH --job-name="TestProject/f6e9886a13bd3fccd61ca6a77291f70a/hybrid_op/37d770093c4ce35b23fef77ed11d75ca"
#SBATCH --partition=def
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(f6e9886a13bd3fccd61ca6a77291f70a)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j f6e9886a13bd3fccd61ca6a77291f70a &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op f6e9886a13bd3fccd61ca6a77291f70a
wait

