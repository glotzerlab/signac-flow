#!/bin/bash
#SBATCH --job-name="TestProject/f6e9886a13bd3fccd61ca6a77291f70a/memory_op/f631d0e7ca88f4a16a25ffbeb7d015cc"
#SBATCH --partition=def
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(f6e9886a13bd3fccd61ca6a77291f70a)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j f6e9886a13bd3fccd61ca6a77291f70a &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op f6e9886a13bd3fccd61ca6a77291f70a
wait

