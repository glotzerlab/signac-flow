#!/bin/bash
#SBATCH --job-name="TestProject/f6e9886a13bd3fccd61ca6a77291f70a/multiline_cm/192d4de45773ba4c929a762f5966863b"
#SBATCH --partition=def
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(f6e9886a13bd3fccd61ca6a77291f70a)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j f6e9886a13bd3fccd61ca6a77291f70a &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

