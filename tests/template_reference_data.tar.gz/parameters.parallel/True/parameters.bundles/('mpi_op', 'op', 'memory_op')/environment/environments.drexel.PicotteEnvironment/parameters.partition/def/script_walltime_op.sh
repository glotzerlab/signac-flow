#!/bin/bash
#SBATCH --job-name="TestProject/f6e9886a13bd3fccd61ca6a77291f70a/walltime_op/1df969e952b04728d18deec16916e1a7"
#SBATCH --partition=def
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(f6e9886a13bd3fccd61ca6a77291f70a)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j f6e9886a13bd3fccd61ca6a77291f70a &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op f6e9886a13bd3fccd61ca6a77291f70a
wait

