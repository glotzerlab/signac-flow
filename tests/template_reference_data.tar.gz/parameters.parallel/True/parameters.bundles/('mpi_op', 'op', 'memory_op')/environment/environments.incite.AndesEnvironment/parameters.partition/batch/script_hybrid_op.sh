#!/bin/bash
#SBATCH --job-name="TestProject/9d46a056063eb8f9b16dc83fe77a6162/hybrid_op/05a161afc4ed2bd106897da81c152e81"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(9d46a056063eb8f9b16dc83fe77a6162)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 9d46a056063eb8f9b16dc83fe77a6162 &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 9d46a056063eb8f9b16dc83fe77a6162
wait

