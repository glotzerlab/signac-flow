#!/bin/bash
#SBATCH --job-name="TestProject/9d46a056063eb8f9b16dc83fe77a6162/mpi_op/39d4c0c8c75f600204d3f2313fdb648d"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(9d46a056063eb8f9b16dc83fe77a6162)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 9d46a056063eb8f9b16dc83fe77a6162 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 9d46a056063eb8f9b16dc83fe77a6162
wait

