#!/bin/bash
#SBATCH --job-name="TestProject/9d46a056063eb8f9b16dc83fe77a6162/multiline_cm/9261f5e81608ae5dfb9d21fc500de5ae"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(9d46a056063eb8f9b16dc83fe77a6162)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 9d46a056063eb8f9b16dc83fe77a6162 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

