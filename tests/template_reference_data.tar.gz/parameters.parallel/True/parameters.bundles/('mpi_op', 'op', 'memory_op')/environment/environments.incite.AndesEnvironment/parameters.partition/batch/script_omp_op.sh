#!/bin/bash
#SBATCH --job-name="TestProject/9d46a056063eb8f9b16dc83fe77a6162/omp_op/cebf618483b5cf04f8df1324cbdde47b"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(9d46a056063eb8f9b16dc83fe77a6162)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 9d46a056063eb8f9b16dc83fe77a6162 &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 9d46a056063eb8f9b16dc83fe77a6162
wait

