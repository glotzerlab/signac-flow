#!/bin/bash
#SBATCH --job-name="TestProject/9d46a056063eb8f9b16dc83fe77a6162/serial_op/b066c9a09cdcf5ad8c967b85fa8a2922"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(9d46a056063eb8f9b16dc83fe77a6162)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 9d46a056063eb8f9b16dc83fe77a6162 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 9d46a056063eb8f9b16dc83fe77a6162
wait

