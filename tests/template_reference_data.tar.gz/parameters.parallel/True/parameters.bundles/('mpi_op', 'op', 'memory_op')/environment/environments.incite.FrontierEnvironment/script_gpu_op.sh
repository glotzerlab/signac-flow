#!/bin/bash
#SBATCH --job-name="TestProject/99f905a58be96e7bf7a92af7a935b251/gpu_op/e7507b12b3521be1ae6a14e79cce1dc3"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(99f905a58be96e7bf7a92af7a935b251)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 99f905a58be96e7bf7a92af7a935b251 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op 99f905a58be96e7bf7a92af7a935b251
wait

