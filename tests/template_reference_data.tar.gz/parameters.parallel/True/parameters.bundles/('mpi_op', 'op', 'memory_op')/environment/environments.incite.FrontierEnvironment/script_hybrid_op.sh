#!/bin/bash
#SBATCH --job-name="TestProject/99f905a58be96e7bf7a92af7a935b251/hybrid_op/c9b160d9c44d3cf12081339b0b4b1291"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(99f905a58be96e7bf7a92af7a935b251)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 99f905a58be96e7bf7a92af7a935b251 &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 99f905a58be96e7bf7a92af7a935b251
wait

