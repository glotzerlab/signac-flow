#!/bin/bash
#SBATCH --job-name="TestProject/99f905a58be96e7bf7a92af7a935b251/multiline_cm/a7c89b63866d3408e149b6082e6aa0e7"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(99f905a58be96e7bf7a92af7a935b251)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 99f905a58be96e7bf7a92af7a935b251 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

