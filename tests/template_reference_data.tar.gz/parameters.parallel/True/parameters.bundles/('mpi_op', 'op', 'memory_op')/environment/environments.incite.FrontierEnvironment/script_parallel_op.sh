#!/bin/bash
#SBATCH --job-name="TestProject/99f905a58be96e7bf7a92af7a935b251/parallel_op/310ec830010648ce5f6b9b67e1c00914"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(99f905a58be96e7bf7a92af7a935b251)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 99f905a58be96e7bf7a92af7a935b251 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 99f905a58be96e7bf7a92af7a935b251
wait

