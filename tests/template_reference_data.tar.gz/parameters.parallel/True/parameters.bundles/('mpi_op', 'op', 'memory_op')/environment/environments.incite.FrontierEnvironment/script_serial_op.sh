#!/bin/bash
#SBATCH --job-name="TestProject/99f905a58be96e7bf7a92af7a935b251/serial_op/6256630eee60aeca2bd72ceabe62c7c0"
#SBATCH --nodes=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(99f905a58be96e7bf7a92af7a935b251)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 99f905a58be96e7bf7a92af7a935b251 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 99f905a58be96e7bf7a92af7a935b251
wait

