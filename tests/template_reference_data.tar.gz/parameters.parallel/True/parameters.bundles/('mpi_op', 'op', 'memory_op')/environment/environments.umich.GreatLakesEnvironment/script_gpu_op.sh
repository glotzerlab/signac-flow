#!/bin/bash
#SBATCH --job-name="TestProject/12d42819ef049104f8032ad6ea590f7e/gpu_op/c42cea04e91c3c4c09f67b8033f53005"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(12d42819ef049104f8032ad6ea590f7e)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 12d42819ef049104f8032ad6ea590f7e &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op 12d42819ef049104f8032ad6ea590f7e
wait

