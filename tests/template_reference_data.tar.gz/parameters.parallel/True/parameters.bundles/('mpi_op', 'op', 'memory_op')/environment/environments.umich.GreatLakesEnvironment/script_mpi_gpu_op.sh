#!/bin/bash
#SBATCH --job-name="TestProject/12d42819ef049104f8032ad6ea590f7e/mpi_gpu_op/95b3242c45007e69fe4865637355f9e1"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --gpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(12d42819ef049104f8032ad6ea590f7e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 12d42819ef049104f8032ad6ea590f7e &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=3 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 12d42819ef049104f8032ad6ea590f7e
wait

