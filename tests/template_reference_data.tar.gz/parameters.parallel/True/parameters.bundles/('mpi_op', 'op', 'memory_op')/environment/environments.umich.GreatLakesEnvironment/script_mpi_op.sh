#!/bin/bash
#SBATCH --job-name="TestProject/12d42819ef049104f8032ad6ea590f7e/mpi_op/041a7eb769aa543bcb5a589277679b2f"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(12d42819ef049104f8032ad6ea590f7e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 12d42819ef049104f8032ad6ea590f7e &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 12d42819ef049104f8032ad6ea590f7e
wait

