#!/bin/bash
#SBATCH --job-name="TestProject/12d42819ef049104f8032ad6ea590f7e/multiline_cm/e5bc1525c7650d763fcd39f69edd8a59"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(12d42819ef049104f8032ad6ea590f7e)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 12d42819ef049104f8032ad6ea590f7e &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

