#!/bin/bash
#SBATCH --job-name="TestProject/12d42819ef049104f8032ad6ea590f7e/omp_op/518ff0a26263f6fac052c8390e1d8026"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(12d42819ef049104f8032ad6ea590f7e)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 12d42819ef049104f8032ad6ea590f7e &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun -u --export=ALL --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 12d42819ef049104f8032ad6ea590f7e
wait

