#!/bin/bash
#SBATCH --job-name="TestProject/12d42819ef049104f8032ad6ea590f7e/walltime_op/f262738052d40eb1c7525c606ff35e98"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(12d42819ef049104f8032ad6ea590f7e)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 12d42819ef049104f8032ad6ea590f7e &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 12d42819ef049104f8032ad6ea590f7e
wait

