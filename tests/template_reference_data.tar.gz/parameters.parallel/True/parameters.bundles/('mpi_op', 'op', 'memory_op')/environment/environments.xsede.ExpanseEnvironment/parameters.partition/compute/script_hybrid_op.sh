#!/bin/bash
#SBATCH --job-name="TestProject/a15e408bf4116e02f5ab455cc4151c46/hybrid_op/332b192588b48242f2b02f0918883090"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(a15e408bf4116e02f5ab455cc4151c46)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j a15e408bf4116e02f5ab455cc4151c46 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op a15e408bf4116e02f5ab455cc4151c46
wait

