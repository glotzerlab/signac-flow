#!/bin/bash
#SBATCH --job-name="TestProject/a15e408bf4116e02f5ab455cc4151c46/mpi_op/c862a2f7631dbde9f577f53f99fbf327"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(a15e408bf4116e02f5ab455cc4151c46)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a15e408bf4116e02f5ab455cc4151c46 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op a15e408bf4116e02f5ab455cc4151c46
wait

