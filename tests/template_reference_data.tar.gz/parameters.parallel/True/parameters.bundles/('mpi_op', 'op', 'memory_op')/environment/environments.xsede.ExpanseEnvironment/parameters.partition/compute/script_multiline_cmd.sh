#!/bin/bash
#SBATCH --job-name="TestProject/a15e408bf4116e02f5ab455cc4151c46/multiline_cm/bec778c18da791df0b44512e7c9954a9"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(a15e408bf4116e02f5ab455cc4151c46)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j a15e408bf4116e02f5ab455cc4151c46 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

