#!/bin/bash
#SBATCH --job-name="TestProject/a15e408bf4116e02f5ab455cc4151c46/omp_op/00dc8df9cfa29dac396b13d401881532"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(a15e408bf4116e02f5ab455cc4151c46)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a15e408bf4116e02f5ab455cc4151c46 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op a15e408bf4116e02f5ab455cc4151c46
wait

