#!/bin/bash
#SBATCH --job-name="TestProject/a15e408bf4116e02f5ab455cc4151c46/serial_op/d3037e41b9825a231a00eb88d2e96365"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(a15e408bf4116e02f5ab455cc4151c46)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j a15e408bf4116e02f5ab455cc4151c46 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op a15e408bf4116e02f5ab455cc4151c46
wait

