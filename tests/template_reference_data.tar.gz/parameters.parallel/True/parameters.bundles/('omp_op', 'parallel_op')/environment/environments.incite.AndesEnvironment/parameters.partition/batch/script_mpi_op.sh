#!/bin/bash
#SBATCH --job-name="TestProject/0190ccaf360b384acbf055688eb176f0/mpi_op/c1dae02e3bb1a3ee437f70ac167f94f5"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(0190ccaf360b384acbf055688eb176f0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0190ccaf360b384acbf055688eb176f0 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 0190ccaf360b384acbf055688eb176f0
wait

