#!/bin/bash
#SBATCH --job-name="TestProject/0190ccaf360b384acbf055688eb176f0/multiline_cm/12c88ce85eddabe75181b878ff528f0b"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(0190ccaf360b384acbf055688eb176f0)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 0190ccaf360b384acbf055688eb176f0 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

