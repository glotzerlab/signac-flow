#!/bin/bash
#SBATCH --job-name="TestProject/0190ccaf360b384acbf055688eb176f0/omp_op/3ff6b8a9403008f96b8c58e0f0db2268"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(0190ccaf360b384acbf055688eb176f0)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0190ccaf360b384acbf055688eb176f0 &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 0190ccaf360b384acbf055688eb176f0
wait

