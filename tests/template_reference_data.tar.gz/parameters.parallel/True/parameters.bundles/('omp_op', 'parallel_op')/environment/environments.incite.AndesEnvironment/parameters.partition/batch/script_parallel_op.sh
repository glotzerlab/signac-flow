#!/bin/bash
#SBATCH --job-name="TestProject/0190ccaf360b384acbf055688eb176f0/parallel_op/8e4a3303841d131a80f9186fa002b84b"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(0190ccaf360b384acbf055688eb176f0)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 0190ccaf360b384acbf055688eb176f0 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 0190ccaf360b384acbf055688eb176f0
wait

