#!/bin/bash
#SBATCH --job-name="TestProject/0190ccaf360b384acbf055688eb176f0/serial_op/c32656736a33b757a3926963ce544fa4"
#SBATCH --partition=batch
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(0190ccaf360b384acbf055688eb176f0)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 0190ccaf360b384acbf055688eb176f0 &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op 0190ccaf360b384acbf055688eb176f0
wait

