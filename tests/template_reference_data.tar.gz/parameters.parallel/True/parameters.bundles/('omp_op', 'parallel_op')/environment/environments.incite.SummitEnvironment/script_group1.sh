'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/memory_oppar/fd00189b033bdadff25fcd29539a2309
#BSUB -M 512MB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
# 
# 
# 
wait

