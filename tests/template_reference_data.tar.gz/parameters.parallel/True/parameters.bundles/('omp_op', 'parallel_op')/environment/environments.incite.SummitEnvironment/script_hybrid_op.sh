'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/hybrid_op/338a21de8a288402795bf08c71064b10
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
wait

