'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/memory_op/c62d0e88dba4b13f44fdce67015028f8
#BSUB -M 512MB
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
wait

