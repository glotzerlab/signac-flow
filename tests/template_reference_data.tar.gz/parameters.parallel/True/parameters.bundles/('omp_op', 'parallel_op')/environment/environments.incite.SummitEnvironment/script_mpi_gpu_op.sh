'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/mpi_gpu_op/56be111f5a8942e4fc69a78ae8c4b013
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_gpu_op(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
wait

