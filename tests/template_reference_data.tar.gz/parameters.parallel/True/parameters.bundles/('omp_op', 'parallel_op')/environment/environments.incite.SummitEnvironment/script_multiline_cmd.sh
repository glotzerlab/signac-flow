#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/multiline_cm/148a150d62bc10effc99bba8aacd55d4
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

