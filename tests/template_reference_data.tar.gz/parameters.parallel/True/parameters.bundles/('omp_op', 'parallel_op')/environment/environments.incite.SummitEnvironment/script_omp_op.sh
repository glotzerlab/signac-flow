'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/omp_op/f668d34fee271e1c7e83e5521c11f097
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
wait

