'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/parallel_op/bdc81bd0af10d75d00b2e40d1de72f94
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
wait

