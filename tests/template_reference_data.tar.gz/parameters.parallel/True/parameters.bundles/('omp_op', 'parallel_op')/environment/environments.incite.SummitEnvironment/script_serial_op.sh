'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/serial_op/b6a78b4cff51a8b6e3820ffd796b842b
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# serial_op(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
wait

