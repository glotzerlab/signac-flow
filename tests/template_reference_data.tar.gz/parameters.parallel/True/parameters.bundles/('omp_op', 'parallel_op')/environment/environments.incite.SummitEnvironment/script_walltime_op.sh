'dict' object has no attribute 'directives'
#!/bin/bash
#BSUB -J TestProject/a86543ac187fda26d47ad9a190c58fc6/walltime_op/cd4f2f6fc0b0f354502462967c664313
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(a86543ac187fda26d47ad9a190c58fc6)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j a86543ac187fda26d47ad9a190c58fc6 &
# Eligible to run:
# 
wait

