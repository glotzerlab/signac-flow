#!/bin/bash
#SBATCH --job-name="TestProject/f0df7dcb12ba5429473daa29de840047/hybrid_op/add0149f48699c5785be53afe83afaa2"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(f0df7dcb12ba5429473daa29de840047)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j f0df7dcb12ba5429473daa29de840047 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op f0df7dcb12ba5429473daa29de840047
wait

