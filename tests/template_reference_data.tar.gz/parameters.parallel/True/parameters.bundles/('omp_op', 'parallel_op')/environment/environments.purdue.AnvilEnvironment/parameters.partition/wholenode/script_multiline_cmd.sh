#!/bin/bash
#SBATCH --job-name="TestProject/f0df7dcb12ba5429473daa29de840047/multiline_cm/6d26e3adaacd044ef245c4a7348c188c"
#SBATCH --partition=wholenode
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
# As of 2023-10-30, Anvil incorrectly binds ranks to cores with `mpirun -n`.
# Disable core binding to work around this issue.
export OMPI_MCA_hwloc_base_binding_policy=""

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(f0df7dcb12ba5429473daa29de840047)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j f0df7dcb12ba5429473daa29de840047 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

