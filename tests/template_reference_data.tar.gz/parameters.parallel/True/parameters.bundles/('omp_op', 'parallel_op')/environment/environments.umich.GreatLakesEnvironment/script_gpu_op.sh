#!/bin/bash
#SBATCH --job-name="TestProject/3ed34f2ba8f3f85680f88f50d01ee87b/gpu_op/c6b9887088389e78ea4eded2e2a7fdc8"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --gpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# gpu_op(3ed34f2ba8f3f85680f88f50d01ee87b)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 3ed34f2ba8f3f85680f88f50d01ee87b &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=1/usr/local/bin/python generate_template_reference_data.py exec gpu_op 3ed34f2ba8f3f85680f88f50d01ee87b
wait

