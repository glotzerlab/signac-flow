#!/bin/bash
#SBATCH --job-name="TestProject/3ed34f2ba8f3f85680f88f50d01ee87b/hybrid_op/8ed5830c676fcad277773e45569977dc"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(3ed34f2ba8f3f85680f88f50d01ee87b)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 3ed34f2ba8f3f85680f88f50d01ee87b &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun -u --export=ALL --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 3ed34f2ba8f3f85680f88f50d01ee87b
wait

