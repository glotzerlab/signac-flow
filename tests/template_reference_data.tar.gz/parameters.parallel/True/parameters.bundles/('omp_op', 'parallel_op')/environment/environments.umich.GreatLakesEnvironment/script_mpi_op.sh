#!/bin/bash
#SBATCH --job-name="TestProject/3ed34f2ba8f3f85680f88f50d01ee87b/mpi_op/562238b11ffd4c46f2c93d7f06270ac9"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(3ed34f2ba8f3f85680f88f50d01ee87b)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 3ed34f2ba8f3f85680f88f50d01ee87b &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 3ed34f2ba8f3f85680f88f50d01ee87b
wait

