#!/bin/bash
#SBATCH --job-name="TestProject/3ed34f2ba8f3f85680f88f50d01ee87b/multiline_cm/7b5b6a6afb85b76b6896687a26907efc"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(3ed34f2ba8f3f85680f88f50d01ee87b)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 3ed34f2ba8f3f85680f88f50d01ee87b &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

