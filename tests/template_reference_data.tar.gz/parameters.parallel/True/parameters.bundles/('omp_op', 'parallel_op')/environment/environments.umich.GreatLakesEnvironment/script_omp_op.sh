#!/bin/bash
#SBATCH --job-name="TestProject/3ed34f2ba8f3f85680f88f50d01ee87b/omp_op/9d0432e3c8b9473e23bbf80109a28b23"
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(3ed34f2ba8f3f85680f88f50d01ee87b)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 3ed34f2ba8f3f85680f88f50d01ee87b &
# Eligible to run:
# export OMP_NUM_THREADS=4; srun -u --export=ALL --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 3ed34f2ba8f3f85680f88f50d01ee87b
wait

