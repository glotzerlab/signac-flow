#!/bin/bash
#SBATCH --job-name="TestProject/3ed34f2ba8f3f85680f88f50d01ee87b/walltime_op/9a2ea8083ed4a2392a69a4cde5a31a6d"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(3ed34f2ba8f3f85680f88f50d01ee87b)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 3ed34f2ba8f3f85680f88f50d01ee87b &
# Eligible to run:
# export OMP_NUM_THREADS=1; srun -u --export=ALL --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 3ed34f2ba8f3f85680f88f50d01ee87b
wait

