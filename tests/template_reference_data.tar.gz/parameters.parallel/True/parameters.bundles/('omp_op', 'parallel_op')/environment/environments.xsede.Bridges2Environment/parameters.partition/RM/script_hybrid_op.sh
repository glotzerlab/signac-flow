#!/bin/bash
#SBATCH --job-name="TestProject/7b07398ef5f4825b0465b3003ad88710/hybrid_op/6d0bdf52ad1ea3fd7d5a060a874e7575"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(7b07398ef5f4825b0465b3003ad88710)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 7b07398ef5f4825b0465b3003ad88710 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 7b07398ef5f4825b0465b3003ad88710
wait

