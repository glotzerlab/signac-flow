#!/bin/bash
#SBATCH --job-name="TestProject/7b07398ef5f4825b0465b3003ad88710/multiline_cm/683e90e2123e1f8f15552b0f2b9798ef"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(7b07398ef5f4825b0465b3003ad88710)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 7b07398ef5f4825b0465b3003ad88710 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

