#!/bin/bash
#SBATCH --job-name="TestProject/7b07398ef5f4825b0465b3003ad88710/omp_op/bb954b2aa1ccc20840ca5dcd72cd91bc"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# omp_op(7b07398ef5f4825b0465b3003ad88710)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 7b07398ef5f4825b0465b3003ad88710 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun --ntasks=1 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec omp_op 7b07398ef5f4825b0465b3003ad88710
wait

