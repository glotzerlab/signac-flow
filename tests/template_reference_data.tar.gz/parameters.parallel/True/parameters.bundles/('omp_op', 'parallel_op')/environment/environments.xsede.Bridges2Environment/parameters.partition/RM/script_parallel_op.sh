#!/bin/bash
#SBATCH --job-name="TestProject/7b07398ef5f4825b0465b3003ad88710/parallel_op/33e02deef45ba89c4174439934a32aa5"
#SBATCH --partition=RM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(7b07398ef5f4825b0465b3003ad88710)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 7b07398ef5f4825b0465b3003ad88710 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op 7b07398ef5f4825b0465b3003ad88710
wait

