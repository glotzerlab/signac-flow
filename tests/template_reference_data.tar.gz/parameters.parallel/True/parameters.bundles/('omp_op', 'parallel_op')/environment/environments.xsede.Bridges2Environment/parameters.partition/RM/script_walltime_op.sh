#!/bin/bash
#SBATCH --job-name="TestProject/7b07398ef5f4825b0465b3003ad88710/walltime_op/ccde3cf4a347fa1b9873dd9fa8cb3a4e"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(7b07398ef5f4825b0465b3003ad88710)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 7b07398ef5f4825b0465b3003ad88710 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpirun --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 7b07398ef5f4825b0465b3003ad88710
wait

