#!/bin/bash
#SBATCH --job-name="TestProject/f79b7a688a24b27b21647ca4a048e30d/memory_oppar/0b0a292086f88a048fa6474c7c130579"
#SBATCH --partition=cpu
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3
#SBATCH --mem-per-task=171M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# group1(f79b7a688a24b27b21647ca4a048e30d)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j f79b7a688a24b27b21647ca4a048e30d &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec serial_op f79b7a688a24b27b21647ca4a048e30d
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op f79b7a688a24b27b21647ca4a048e30d
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op f79b7a688a24b27b21647ca4a048e30d
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op f79b7a688a24b27b21647ca4a048e30d
wait

