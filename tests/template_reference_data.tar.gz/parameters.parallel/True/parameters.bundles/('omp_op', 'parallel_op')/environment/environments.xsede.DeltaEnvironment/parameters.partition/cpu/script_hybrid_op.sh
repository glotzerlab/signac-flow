#!/bin/bash
#SBATCH --job-name="TestProject/f79b7a688a24b27b21647ca4a048e30d/hybrid_op/ede0fac8601c0f5bdbd00f63a4fd318e"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(f79b7a688a24b27b21647ca4a048e30d)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j f79b7a688a24b27b21647ca4a048e30d &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op f79b7a688a24b27b21647ca4a048e30d
wait

