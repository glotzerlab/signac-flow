#!/bin/bash
#SBATCH --job-name="TestProject/f79b7a688a24b27b21647ca4a048e30d/mpi_op/fe32f5ee30aa93bd79f3347884330964"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(f79b7a688a24b27b21647ca4a048e30d)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j f79b7a688a24b27b21647ca4a048e30d &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op f79b7a688a24b27b21647ca4a048e30d
wait

