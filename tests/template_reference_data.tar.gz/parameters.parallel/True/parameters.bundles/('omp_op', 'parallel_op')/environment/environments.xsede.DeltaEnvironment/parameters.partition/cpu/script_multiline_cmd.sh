#!/bin/bash
#SBATCH --job-name="TestProject/f79b7a688a24b27b21647ca4a048e30d/multiline_cm/065683c63f3d2bcc5a1830f57dd5c56a"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(f79b7a688a24b27b21647ca4a048e30d)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j f79b7a688a24b27b21647ca4a048e30d &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

