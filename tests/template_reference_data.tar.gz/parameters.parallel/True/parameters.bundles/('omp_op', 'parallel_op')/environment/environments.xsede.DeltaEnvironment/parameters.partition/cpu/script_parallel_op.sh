#!/bin/bash
#SBATCH --job-name="TestProject/f79b7a688a24b27b21647ca4a048e30d/parallel_op/11d206bd73e4a0955331825c97425cc4"
#SBATCH --partition=cpu
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# parallel_op(f79b7a688a24b27b21647ca4a048e30d)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j f79b7a688a24b27b21647ca4a048e30d &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec parallel_op f79b7a688a24b27b21647ca4a048e30d
wait

