#!/bin/bash
#SBATCH --job-name="TestProject/0608fa20a4e32efb89f11b877363eec5/hybrid_op/379e83168158750e6844e4041d64747c"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# hybrid_op(0608fa20a4e32efb89f11b877363eec5)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 0608fa20a4e32efb89f11b877363eec5 &
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec --ntasks=3 --cpus-per-task=4 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec hybrid_op 0608fa20a4e32efb89f11b877363eec5
wait

