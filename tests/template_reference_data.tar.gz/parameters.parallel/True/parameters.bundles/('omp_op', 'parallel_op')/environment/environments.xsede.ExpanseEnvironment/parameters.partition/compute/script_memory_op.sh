#!/bin/bash
#SBATCH --job-name="TestProject/0608fa20a4e32efb89f11b877363eec5/memory_op/4e13ba38d5b1280bfdd2765d205544f8"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-task=512M

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# memory_op(0608fa20a4e32efb89f11b877363eec5)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 0608fa20a4e32efb89f11b877363eec5 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec memory_op 0608fa20a4e32efb89f11b877363eec5
wait

