#!/bin/bash
#SBATCH --job-name="TestProject/0608fa20a4e32efb89f11b877363eec5/mpi_op/e1257f547aa4de2ad4a08f357308ff7f"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=3

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# mpi_op(0608fa20a4e32efb89f11b877363eec5)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0608fa20a4e32efb89f11b877363eec5 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=3 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec mpi_op 0608fa20a4e32efb89f11b877363eec5
wait

