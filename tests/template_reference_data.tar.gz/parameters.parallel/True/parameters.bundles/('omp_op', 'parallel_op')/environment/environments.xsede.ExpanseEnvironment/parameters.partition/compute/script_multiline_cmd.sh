#!/bin/bash
#SBATCH --job-name="TestProject/0608fa20a4e32efb89f11b877363eec5/multiline_cm/7aa5f47df1b4e203951c06267e483e64"
#SBATCH --partition=compute
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# multiline_cmd(0608fa20a4e32efb89f11b877363eec5)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 0608fa20a4e32efb89f11b877363eec5 &
# Eligible to run:
# echo "First line"
# echo "Second line"
wait

