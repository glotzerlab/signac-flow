#!/bin/bash
#SBATCH --job-name="TestProject/0608fa20a4e32efb89f11b877363eec5/walltime_op/3e052842f4b5a5e2b0afc859edbc4da5"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1

set -e
set -u

cd '/home/user/path with spaces and "quotes" and \backslashes/'


# walltime_op(0608fa20a4e32efb89f11b877363eec5)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 0608fa20a4e32efb89f11b877363eec5 &
# Eligible to run:
# export OMP_NUM_THREADS=1; mpiexec --ntasks=1 --cpus-per-task=1 --gpus-per-task=0/usr/local/bin/python generate_template_reference_data.py exec walltime_op 0608fa20a4e32efb89f11b877363eec5
wait

