#!/bin/bash
#BSUB -J SubmissionTe/65a5d534/mpi_gpu_op/0000/3a5c34e66b40adc0af5546fb28d71b77
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(65a5d534933e1876ba27a30ffdf04a55)
jsrun -n 1 -a 5 -c 5 -g 2 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 65a5d534933e1876ba27a30ffdf04a55

