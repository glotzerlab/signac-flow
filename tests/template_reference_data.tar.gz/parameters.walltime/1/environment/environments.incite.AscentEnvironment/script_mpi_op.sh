#!/bin/bash
#BSUB -J SubmissionTe/65a5d534/mpi_op/0000/5c2d3e26150b0a87ed8278502842bc06
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(65a5d534933e1876ba27a30ffdf04a55)
jsrun -n 5 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_op 65a5d534933e1876ba27a30ffdf04a55

