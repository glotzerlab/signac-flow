#!/bin/bash
#BSUB -J SubmissionTe/65a5d534/omp_op/0000/c5d865a7e544e27665efb5e90eb5b8c0
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# omp_op(65a5d534933e1876ba27a30ffdf04a55)
export OMP_NUM_THREADS=4
jsrun -n 1 -a 1 -c 4 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec omp_op 65a5d534933e1876ba27a30ffdf04a55

