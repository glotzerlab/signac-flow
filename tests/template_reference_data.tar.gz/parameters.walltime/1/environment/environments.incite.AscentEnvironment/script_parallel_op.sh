#!/bin/bash
#BSUB -J SubmissionTe/65a5d534/parallel_op/0000/e1f6faf52bb0751ed1dbd0d5e925c684
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# parallel_op(65a5d534933e1876ba27a30ffdf04a55)
jsrun -n 3 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec parallel_op 65a5d534933e1876ba27a30ffdf04a55

