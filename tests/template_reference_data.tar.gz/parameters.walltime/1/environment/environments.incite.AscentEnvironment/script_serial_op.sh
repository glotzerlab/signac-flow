#!/bin/bash
#BSUB -J SubmissionTe/65a5d534/serial_op/0000/90f88cb50b271ec4ba2b0314fc6c911f
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# serial_op(65a5d534933e1876ba27a30ffdf04a55)
jsrun -n 1 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec serial_op 65a5d534933e1876ba27a30ffdf04a55

