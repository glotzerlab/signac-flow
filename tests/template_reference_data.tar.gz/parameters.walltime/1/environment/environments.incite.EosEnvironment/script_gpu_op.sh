#PBS -N SubmissionTe/40c5efdd/gpu_op/0000/57c2dcbc3fb56c9c7f61e1a2a30d94b8
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1
#PBS -A MAT110

set -e
set -u

cd /home/user/project/

# gpu_op(40c5efdd19a4c2f25070b7b9336d7249)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 40c5efdd19a4c2f25070b7b9336d7249

