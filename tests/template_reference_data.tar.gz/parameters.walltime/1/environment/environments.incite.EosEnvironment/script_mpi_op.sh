#PBS -N SubmissionTe/40c5efdd/mpi_op/0000/5ab246fcdab993036c6dc2dc59b0767c
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(40c5efdd19a4c2f25070b7b9336d7249)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 40c5efdd19a4c2f25070b7b9336d7249

