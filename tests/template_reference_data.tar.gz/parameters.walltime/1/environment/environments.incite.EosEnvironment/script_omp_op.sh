#PBS -N SubmissionTe/40c5efdd/omp_op/0000/bc7148190c9629af6d376baab0597bbd
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(40c5efdd19a4c2f25070b7b9336d7249)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 40c5efdd19a4c2f25070b7b9336d7249

