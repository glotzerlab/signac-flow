#PBS -N SubmissionTe/40c5efdd/parallel_op/0000/e81fac928609a954097f82d28f8daab5
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1
#PBS -A MAT110

set -e
set -u

cd /home/user/project/

# parallel_op(40c5efdd19a4c2f25070b7b9336d7249)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 40c5efdd19a4c2f25070b7b9336d7249

