DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb2fc131daf5747c8adc0da35e/gpu_op/2a11b5b409ec1b09a6124b7349273fa8
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# gpu_op(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# jsrun -n 2 -a 1 -c 1 -g 1 --smpiargs='-gpu' -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 2e49a8cb2fc131daf5747c8adc0da35e

