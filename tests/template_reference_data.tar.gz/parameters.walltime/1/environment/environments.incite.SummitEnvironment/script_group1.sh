#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb2fc131daf5747c8adc0da35e/memory_oppar/e9368cae184c03ecf6da738088f734b1
#BSUB -M 0.5GB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# group1(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec serial_op 2e49a8cb2fc131daf5747c8adc0da35e
# jsrun -n 1 -a 1 -c 3 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec parallel_op 2e49a8cb2fc131daf5747c8adc0da35e
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec memory_op 2e49a8cb2fc131daf5747c8adc0da35e

