#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb/parallel_ops/0000/a624c82e5c2430860eee2f3080496dba
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# group1(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec parallel_op 2e49a8cb2fc131daf5747c8adc0da35e
# /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec serial_op 2e49a8cb2fc131daf5747c8adc0da35e

