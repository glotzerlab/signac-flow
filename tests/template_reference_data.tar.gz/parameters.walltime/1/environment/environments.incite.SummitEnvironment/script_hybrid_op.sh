#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb/hybrid_op/0000/f019ce4495fe39f00e345767bb637e82
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# hybrid_op(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# export OMP_NUM_THREADS=4 mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 2e49a8cb2fc131daf5747c8adc0da35e

