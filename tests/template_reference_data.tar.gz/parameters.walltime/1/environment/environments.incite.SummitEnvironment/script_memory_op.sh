#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb2fc131daf5747c8adc0da35e/memory_op/019ffb8ebe3dbb3190f299acaf4bb249
#BSUB -M 8.0GB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# memory_op(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec memory_op 2e49a8cb2fc131daf5747c8adc0da35e

