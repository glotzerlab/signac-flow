#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb/mpi_gpu_op/0000/cd3d104f50a33e846a84d829790d6488
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op[#1](2e4)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 2e49a8cb2fc131daf5747c8adc0da35e

