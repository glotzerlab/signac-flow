#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb/mpi_gpu_op/0000/cd3d104f50a33e846a84d829790d6488
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(2e49a8cb2fc131daf5747c8adc0da35e)
jsrun -n 1 -a 5 -c 5 -g 2 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 2e49a8cb2fc131daf5747c8adc0da35e

