#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb2fc131daf5747c8adc0da35e/mpi_gpu_op/0000/51383e8c33e70eafb23bfbd4cb713446
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op[#1](2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 2e49a8cb2fc131daf5747c8adc0da35e

