#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb/mpi_op/0000/9d326be63ffbf614b842a10c59d1e1fc
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 2e49a8cb2fc131daf5747c8adc0da35e

