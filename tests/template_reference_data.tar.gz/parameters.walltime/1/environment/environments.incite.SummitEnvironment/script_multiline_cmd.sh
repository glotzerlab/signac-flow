DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb2fc131daf5747c8adc0da35e/multiline_cm/6c9a90f9d092989f12a36a9846c30e08
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# multiline_cmd(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  echo "First line"
# echo "Second line"

