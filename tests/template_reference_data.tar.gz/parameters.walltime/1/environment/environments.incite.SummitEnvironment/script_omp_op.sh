#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb2fc131daf5747c8adc0da35e/omp_op/0000/bc208a4ed7f2c8b8a933404e2b796954
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# omp_op[#1](2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 2e49a8cb2fc131daf5747c8adc0da35e

