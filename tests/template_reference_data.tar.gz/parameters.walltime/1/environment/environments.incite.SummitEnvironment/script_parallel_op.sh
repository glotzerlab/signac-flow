#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb/parallel_op/0000/9838006ebdd8aa9f9068f506795c4c12
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# parallel_op(2e49a8cb2fc131daf5747c8adc0da35e)
jsrun -n 3 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec parallel_op 2e49a8cb2fc131daf5747c8adc0da35e

