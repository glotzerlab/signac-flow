#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb/serial_op/0000/1283a05807e119a841806371dc817ad7
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# serial_op(2e49a8cb2fc131daf5747c8adc0da35e)
jsrun -n 1 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec serial_op 2e49a8cb2fc131daf5747c8adc0da35e

