#!/bin/bash
#BSUB -J SubmissionTe/2e49a8cb2fc131daf5747c8adc0da35e/serial_op/38d194a1281c0c04a7696e900ffa47c2
#BSUB -M 4.0G
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# serial_op(2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec serial_op 2e49a8cb2fc131daf5747c8adc0da35e

