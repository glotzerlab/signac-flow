#PBS -N SubmissionTe/64760707/gpu_op/0000/9adaaa3911e8d514a09350d29e5425bd
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/user/project/

# gpu_op(64760707a0aedec77b482309893f1543)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 64760707a0aedec77b482309893f1543

