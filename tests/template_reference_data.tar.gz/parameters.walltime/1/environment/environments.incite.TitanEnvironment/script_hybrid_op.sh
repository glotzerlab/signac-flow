#PBS -N SubmissionTe/64760707/hybrid_op/0000/c548505cc138975980fa6d8d4f4482dc
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/user/project/

# hybrid_op(64760707a0aedec77b482309893f1543)
export OMP_NUM_THREADS=4
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 64760707a0aedec77b482309893f1543

