#PBS -N SubmissionTe/64760707/mpi_gpu_op/0000/74f77d6ce6a4f6ca20b278965d883648
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(64760707a0aedec77b482309893f1543)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 64760707a0aedec77b482309893f1543

