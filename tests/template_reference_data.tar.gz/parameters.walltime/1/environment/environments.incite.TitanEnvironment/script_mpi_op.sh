#PBS -N SubmissionTe/64760707/mpi_op/0000/6c4cc9dc3d92a75f6dbfb5a213c48a41
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(64760707a0aedec77b482309893f1543)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 64760707a0aedec77b482309893f1543

