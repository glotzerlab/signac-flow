#PBS -N SubmissionTe/64760707/mpi_op/0000/cc93829ad5f49e632bf10d5aeac9fc91
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# mpi_op(64760707a0aedec77b482309893f1543)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 64760707a0aedec77b482309893f1543

