#PBS -N SubmissionTe/64760707/omp_op/0000/935b27ff71e972b4812c82ed938fb3ab
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# omp_op(64760707a0aedec77b482309893f1543)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 64760707a0aedec77b482309893f1543

