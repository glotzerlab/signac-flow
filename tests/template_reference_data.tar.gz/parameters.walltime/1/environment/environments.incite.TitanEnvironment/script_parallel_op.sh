#PBS -N SubmissionTe/64760707/parallel_op/0000/fc84bd3cae94457a248398910b58f98e
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# parallel_op(64760707a0aedec77b482309893f1543)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 64760707a0aedec77b482309893f1543

