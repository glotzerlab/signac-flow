#PBS -N SubmissionTe/64760707/serial_op/0000/f930b5a75afc655fbfd22ab7864eb7f4
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# serial_op(64760707a0aedec77b482309893f1543)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 64760707a0aedec77b482309893f1543

