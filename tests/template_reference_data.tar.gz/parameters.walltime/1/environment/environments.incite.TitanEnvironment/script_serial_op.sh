#PBS -N SubmissionTe/64760707/serial_op/0000/247657329188ca00fd2e6730837d6db1
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(64760707a0aedec77b482309893f1543)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 64760707a0aedec77b482309893f1543

