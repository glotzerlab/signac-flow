#PBS -N SubmissionTe/52fdf0d6/gpu_op/0000/c89e585aea80058b6fe4d37806be53b8
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=2:gpus=1
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/user/project/

# gpu_op(52fdf0d6321aa97d51c44889afb5756e)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 52fdf0d6321aa97d51c44889afb5756e

