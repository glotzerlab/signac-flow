#PBS -N SubmissionTe/52fdf0d6/hybrid_op/0000/956fdffb0cc6319a29fd0d295dac57c9
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=4
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(52fdf0d6321aa97d51c44889afb5756e)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 52fdf0d6321aa97d51c44889afb5756e

