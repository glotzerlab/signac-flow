#PBS -N SubmissionTe/52fdf0d6/mpi_gpu_op/0000/df76b322f2f209c3610279abb31d03dd
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(52fdf0d6321aa97d51c44889afb5756e)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 52fdf0d6321aa97d51c44889afb5756e

