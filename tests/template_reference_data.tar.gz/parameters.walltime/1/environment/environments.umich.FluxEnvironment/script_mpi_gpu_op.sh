#PBS -N SubmissionTe/52fdf0d6/mpi_gpu_op/0000/79fddee41f445b0a348e9cd37b35c76c
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=5:gpus=1
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(52fdf0d6321aa97d51c44889afb5756e)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 52fdf0d6321aa97d51c44889afb5756e

