#PBS -N SubmissionTe/52fdf0d6/omp_op/0000/7e4893bc6aa9b330299b2e0fafa531bb
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=1:ppn=4
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# omp_op(52fdf0d6321aa97d51c44889afb5756e)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 52fdf0d6321aa97d51c44889afb5756e

