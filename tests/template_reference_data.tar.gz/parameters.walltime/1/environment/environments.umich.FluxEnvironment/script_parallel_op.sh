#PBS -N SubmissionTe/52fdf0d6/parallel_op/0000/fa435d752bf4010964960658a75fafc9
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l procs=3
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# parallel_op(52fdf0d6321aa97d51c44889afb5756e)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 52fdf0d6321aa97d51c44889afb5756e

