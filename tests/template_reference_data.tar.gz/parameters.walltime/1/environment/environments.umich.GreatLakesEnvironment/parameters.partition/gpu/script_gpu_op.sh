DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/dcb62d7ddf30d4049e6087275b07c271/gpu_op/52d8f49638bfdc0b03f6e37d812b939f"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(dcb62d7ddf30d4049e6087275b07c271)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j dcb62d7ddf30d4049e6087275b07c271
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op dcb62d7ddf30d4049e6087275b07c271

