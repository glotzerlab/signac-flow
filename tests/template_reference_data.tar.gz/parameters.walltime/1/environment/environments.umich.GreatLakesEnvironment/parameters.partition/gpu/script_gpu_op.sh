#!/bin/bash
#SBATCH --job-name="SubmissionTe/dcb62d7d/gpu_op/0000/874ae30c09e2f7fa2c45b556a8a54cf6"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2
#SBATCH --account=rlarson1

set -e
set -u

cd /home/user/project/

# gpu_op(dcb62d7ddf30d4049e6087275b07c271)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j dcb62d7ddf30d4049e6087275b07c271
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec gpu_op dcb62d7ddf30d4049e6087275b07c271

