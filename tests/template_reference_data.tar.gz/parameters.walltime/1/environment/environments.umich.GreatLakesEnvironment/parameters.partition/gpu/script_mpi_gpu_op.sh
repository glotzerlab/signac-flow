#!/bin/bash
#SBATCH --job-name="SubmissionTe/dcb62d7d/mpi_gpu_op/0000/7cb5d5c0c85d5bc88d3413eb24545029"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(dcb62d7ddf30d4049e6087275b07c271)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j dcb62d7ddf30d4049e6087275b07c271
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op dcb62d7ddf30d4049e6087275b07c271

