#!/bin/bash
#SBATCH --job-name="SubmissionTe/dcb62d7ddf30d4049e6087275b07c271/mpi_gpu_op/0000/4364656b4642e8e6225f64c5b16b7a74"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op[#1](dcb62d7ddf30d4049e6087275b07c271)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j dcb62d7ddf30d4049e6087275b07c271
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op dcb62d7ddf30d4049e6087275b07c271

