#!/bin/bash
#SBATCH --job-name="SubmissionTe/dcb62d7ddf30d4049e6087275b07c271/mpi_gpu_op/b5b7f2e6ae23820523a56d009c428700"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(dcb62d7ddf30d4049e6087275b07c271)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j dcb62d7ddf30d4049e6087275b07c271
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op dcb62d7ddf30d4049e6087275b07c271

