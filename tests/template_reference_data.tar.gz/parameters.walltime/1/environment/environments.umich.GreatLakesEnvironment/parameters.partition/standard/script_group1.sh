#!/bin/bash
#SBATCH --job-name="SubmissionTe/633b8323/parallel_ops/0000/bc80e29eec5c815d21e434d742172421"
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(633b8323a34e88b5bef5b59ab5ae6f3f)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec serial_op 633b8323a34e88b5bef5b59ab5ae6f3f
# /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec parallel_op 633b8323a34e88b5bef5b59ab5ae6f3f

