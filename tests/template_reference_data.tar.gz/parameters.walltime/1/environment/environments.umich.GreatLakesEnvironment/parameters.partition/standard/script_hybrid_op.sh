#!/bin/bash
#SBATCH --job-name="SubmissionTe/633b8323a34e88b5bef5b59ab5ae6f3f/hybrid_op/0000/a24fe8005a08ec3cd5ae2b5ea1982d2a"
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](633b8323a34e88b5bef5b59ab5ae6f3f)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 633b8323a34e88b5bef5b59ab5ae6f3f

