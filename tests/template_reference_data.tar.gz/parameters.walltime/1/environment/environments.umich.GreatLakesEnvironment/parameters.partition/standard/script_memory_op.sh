DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
#!/bin/bash
#SBATCH --job-name="SubmissionTe/633b8323a34e88b5bef5b59ab5ae6f3f/memory_op/94909aef6339714ae75add9220790281"
#SBATCH --mem=0.5G
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(633b8323a34e88b5bef5b59ab5ae6f3f)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 633b8323a34e88b5bef5b59ab5ae6f3f

