#!/bin/bash
#SBATCH --job-name="SubmissionTe/633b8323/mpi_op/0000/8785e1a2ac5a88e9312d52bdd8db746b"
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(633b8323a34e88b5bef5b59ab5ae6f3f)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec mpi_op 633b8323a34e88b5bef5b59ab5ae6f3f

