#!/bin/bash
#SBATCH --job-name="SubmissionTe/633b8323a34e88b5bef5b59ab5ae6f3f/omp_op/3ff48682f0074dfc665b2c70b4fcd756"
#SBATCH --mem=4.0G
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(633b8323a34e88b5bef5b59ab5ae6f3f)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 633b8323a34e88b5bef5b59ab5ae6f3f

