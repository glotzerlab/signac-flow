#!/bin/bash
#SBATCH --job-name="SubmissionTe/633b8323/omp_op/0000/825c17c629b6f38b063ef2078d6c2013"
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(633b8323a34e88b5bef5b59ab5ae6f3f)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# export OMP_NUM_THREADS=4
 /usr/local/bin/python generate_template_reference_data.py exec omp_op 633b8323a34e88b5bef5b59ab5ae6f3f

