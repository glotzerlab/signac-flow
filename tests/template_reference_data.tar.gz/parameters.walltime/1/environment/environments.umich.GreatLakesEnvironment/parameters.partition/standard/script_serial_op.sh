#!/bin/bash
#SBATCH --job-name="SubmissionTe/633b8323/serial_op/0000/57ce8d05085790ddfd5e41d4fbaa34ae"
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(633b8323a34e88b5bef5b59ab5ae6f3f)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec serial_op 633b8323a34e88b5bef5b59ab5ae6f3f

