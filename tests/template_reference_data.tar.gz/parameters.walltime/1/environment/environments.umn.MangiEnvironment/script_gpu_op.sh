#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c56/gpu_op/0000/672e2001c4c8cdcd142c1ef74b0beab0"
#SBATCH -t 01:00:00
#SBATCH --ntasks=2

set -e
set -u

cd /home/user/project/

# gpu_op[#1](8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 8d2f0c562b02dafd769b04cc5449fa37

