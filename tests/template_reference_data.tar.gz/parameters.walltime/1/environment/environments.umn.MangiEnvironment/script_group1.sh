DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c562b02dafd769b04cc5449fa37/memory_oppar/71c001eb99950777f087492a8cffeb07"
#SBATCH --mem=0.5G
#SBATCH -t 01:00:00
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# group1(8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8d2f0c562b02dafd769b04cc5449fa37
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8d2f0c562b02dafd769b04cc5449fa37
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 8d2f0c562b02dafd769b04cc5449fa37
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 8d2f0c562b02dafd769b04cc5449fa37

