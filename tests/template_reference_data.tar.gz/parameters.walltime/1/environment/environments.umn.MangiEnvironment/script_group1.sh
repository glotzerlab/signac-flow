#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c562b02dafd769b04cc5449fa37/parallel_ops/60892d2fdbe65ed4539a1474c3e76e25"
#SBATCH --mem=4.0G
#SBATCH -t 01:00:00
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# group1(8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8d2f0c562b02dafd769b04cc5449fa37
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8d2f0c562b02dafd769b04cc5449fa37

