#PBS -N SubmissionTe/8d2f0c56/hybrid_op/0000/854337297b0aac2f16ebc479ee6cf286
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l nodes=5:ppn=4

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 8d2f0c562b02dafd769b04cc5449fa37

