#PBS -N SubmissionTe/8d2f0c56/mpi_gpu_op/0000/6455aa79f2a558ae23dc542080ab451e
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l procs=5:gpus=1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op[#1](8d2)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 8d2f0c562b02dafd769b04cc5449fa37

