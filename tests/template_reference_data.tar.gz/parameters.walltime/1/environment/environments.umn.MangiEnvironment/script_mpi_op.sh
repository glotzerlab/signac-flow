#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c562b02dafd769b04cc5449fa37/mpi_op/42a1633a64e99b903e6d52b8e724346b"
#SBATCH -t 01:00:00
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 8d2f0c562b02dafd769b04cc5449fa37

