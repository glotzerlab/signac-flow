DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c562b02dafd769b04cc5449fa37/multiline_cm/2c6bdcf325877ce0bd59482f0f10d27e"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# echo "First line"
# echo "Second line"

