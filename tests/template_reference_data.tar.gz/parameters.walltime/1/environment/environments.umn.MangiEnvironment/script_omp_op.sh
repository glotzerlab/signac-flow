#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c562b02dafd769b04cc5449fa37/omp_op/d6faf85cb34254daf1e77dedfce2cbfa"
#SBATCH -t 01:00:00
#SBATCH --ntasks=4

set -e
set -u

cd /home/user/project/

# omp_op(8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 8d2f0c562b02dafd769b04cc5449fa37

