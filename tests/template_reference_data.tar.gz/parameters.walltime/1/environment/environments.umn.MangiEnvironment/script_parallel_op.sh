#PBS -N SubmissionTe/8d2f0c56/parallel_op/0000/4b35b004b22a94ed7e319a98e8792c54
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l procs=3

set -e
set -u

cd /home/user/project/

# parallel_op[#1](8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8d2f0c562b02dafd769b04cc5449fa37

