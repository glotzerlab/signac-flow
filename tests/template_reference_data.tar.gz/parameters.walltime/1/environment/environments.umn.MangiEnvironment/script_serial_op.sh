#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c562b02dafd769b04cc5449fa37/serial_op/0000/4012e021294d070243216f2199813341"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# serial_op[#1](8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8d2f0c562b02dafd769b04cc5449fa37

