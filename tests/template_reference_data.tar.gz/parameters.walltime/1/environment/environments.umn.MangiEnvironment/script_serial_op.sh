#PBS -N SubmissionTe/8d2f0c56/serial_op/0000/e06a0747038000eb392bcdc9407e9c03
#PBS -l walltime=01:00:00
#PBS -V
#PBS -l procs=1

set -e
set -u

cd /home/user/project/

# serial_op[#1](8d2)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8d2f0c562b02dafd769b04cc5449fa37

