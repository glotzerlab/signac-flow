DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/8d2f0c562b02dafd769b04cc5449fa37/walltime_op/8caa5b9429b254bac2b49783dfca3e78"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# walltime_op(8d2f0c562b02dafd769b04cc5449fa37)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 8d2f0c562b02dafd769b04cc5449fa37
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 8d2f0c562b02dafd769b04cc5449fa37

