DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
#!/bin/bash
#SBATCH --job-name="SubmissionTe/ac09f7a375d6e3b8243250cc7c4dd89d/gpu_op/ce7f3ee14de90786ef014927cfe5a53f"
#SBATCH --partition=GPU-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(ac09f7a375d6e3b8243250cc7c4dd89d)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j ac09f7a375d6e3b8243250cc7c4dd89d
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op ac09f7a375d6e3b8243250cc7c4dd89d

