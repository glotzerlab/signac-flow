DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/f561f1a461e2b2fa3a66a4c40c5d4fd7/gpu_op/daa135f87343e6922f7a72db0cc0002c"
#SBATCH --partition=GPU
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(f561f1a461e2b2fa3a66a4c40c5d4fd7)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j f561f1a461e2b2fa3a66a4c40c5d4fd7
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op f561f1a461e2b2fa3a66a4c40c5d4fd7

