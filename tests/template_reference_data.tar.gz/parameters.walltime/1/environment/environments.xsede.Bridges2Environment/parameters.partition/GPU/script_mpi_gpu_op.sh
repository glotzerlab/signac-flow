DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/f561f1a461e2b2fa3a66a4c40c5d4fd7/mpi_gpu_op/e86059d92632561c8c6a1c5ecca4957e"
#SBATCH --partition=GPU
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(f561f1a461e2b2fa3a66a4c40c5d4fd7)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j f561f1a461e2b2fa3a66a4c40c5d4fd7
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op f561f1a461e2b2fa3a66a4c40c5d4fd7

