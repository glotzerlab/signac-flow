DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
#!/bin/bash
#SBATCH --job-name="SubmissionTe/b692b9592921310bb2d12429c84fdd8c/hybrid_op/ed102bddb7d619fa3f4812c5e8d01d2c"
#SBATCH --partition=RM-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=20

set -e
set -u

cd /home/user/project/

# hybrid_op(b692b9592921310bb2d12429c84fdd8c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j b692b9592921310bb2d12429c84fdd8c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op b692b9592921310bb2d12429c84fdd8c

