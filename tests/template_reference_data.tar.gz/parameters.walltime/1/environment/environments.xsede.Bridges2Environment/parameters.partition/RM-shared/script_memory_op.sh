DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
#!/bin/bash
#SBATCH --job-name="SubmissionTe/b692b9592921310bb2d12429c84fdd8c/memory_op/bd74f8679d42192fdcc7ca3cf033a94f"
#SBATCH --mem=0.5G
#SBATCH --partition=RM-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# memory_op(b692b9592921310bb2d12429c84fdd8c)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j b692b9592921310bb2d12429c84fdd8c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op b692b9592921310bb2d12429c84fdd8c

