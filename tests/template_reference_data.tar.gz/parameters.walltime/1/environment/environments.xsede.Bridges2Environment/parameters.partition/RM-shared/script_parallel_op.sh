DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
#!/bin/bash
#SBATCH --job-name="SubmissionTe/b692b9592921310bb2d12429c84fdd8c/parallel_op/e3451f8467d63f0d3e73e7c3e84861b8"
#SBATCH --partition=RM-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# parallel_op(b692b9592921310bb2d12429c84fdd8c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j b692b9592921310bb2d12429c84fdd8c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op b692b9592921310bb2d12429c84fdd8c

