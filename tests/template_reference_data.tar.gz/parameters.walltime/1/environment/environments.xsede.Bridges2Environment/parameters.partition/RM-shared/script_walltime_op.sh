DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
#!/bin/bash
#SBATCH --job-name="SubmissionTe/b692b9592921310bb2d12429c84fdd8c/walltime_op/b3f659ecee078db530bd170c305f8996"
#SBATCH --partition=RM-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# walltime_op(b692b9592921310bb2d12429c84fdd8c)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j b692b9592921310bb2d12429c84fdd8c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op b692b9592921310bb2d12429c84fdd8c

