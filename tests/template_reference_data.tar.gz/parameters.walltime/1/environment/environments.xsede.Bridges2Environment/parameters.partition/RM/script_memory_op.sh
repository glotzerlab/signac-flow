#!/bin/bash
#SBATCH --job-name="SubmissionTe/1aaca04d87232c2455ee1088b96d72e8/memory_op/75af32639ec7b5d1edaec67c420453c5"
#SBATCH --mem=8.0G
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(1aaca04d87232c2455ee1088b96d72e8)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 1aaca04d87232c2455ee1088b96d72e8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1aaca04d87232c2455ee1088b96d72e8

