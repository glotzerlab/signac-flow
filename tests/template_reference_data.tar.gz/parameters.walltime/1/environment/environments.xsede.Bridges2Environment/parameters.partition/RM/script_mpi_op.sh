#!/bin/bash
#SBATCH --job-name="SubmissionTe/1aaca04d87232c2455ee1088b96d72e8/mpi_op/22e573cea91e1b0677ed38380a5129cd"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(1aaca04d87232c2455ee1088b96d72e8)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 1aaca04d87232c2455ee1088b96d72e8
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 1aaca04d87232c2455ee1088b96d72e8

