#!/bin/bash
#SBATCH --job-name="SubmissionTe/1aaca04d87232c2455ee1088b96d72e8/multiline_cm/bee6f503ecfcf4338bf91e81221c887b"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(1aaca04d87232c2455ee1088b96d72e8)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 1aaca04d87232c2455ee1088b96d72e8
# Eligible to run:
# echo "First line"
# echo "Second line"

