DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/1aaca04d87232c2455ee1088b96d72e8/omp_op/b6b7619b64fa778c5e36095f46990c9a"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(1aaca04d87232c2455ee1088b96d72e8)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 1aaca04d87232c2455ee1088b96d72e8
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 1aaca04d87232c2455ee1088b96d72e8

