DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/1aaca04d87232c2455ee1088b96d72e8/walltime_op/dacc92eb9df02ce5e3c1467f7fb940c4"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# walltime_op(1aaca04d87232c2455ee1088b96d72e8)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 1aaca04d87232c2455ee1088b96d72e8
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 1aaca04d87232c2455ee1088b96d72e8

