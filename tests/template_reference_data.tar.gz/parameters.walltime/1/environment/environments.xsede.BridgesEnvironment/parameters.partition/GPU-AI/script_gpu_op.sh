#!/bin/bash
#SBATCH --job-name="SubmissionTe/f6a3dd3e60596db6674caf5f4fb5d5cc/gpu_op/0000/b4593befc8675c797ff92ef83bddfb40"
#SBATCH --partition=GPU-AI
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gres=gpu:volta16:2

set -e
set -u

cd /home/user/project/

# gpu_op[#1](f6a3dd3e60596db6674caf5f4fb5d5cc)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j f6a3dd3e60596db6674caf5f4fb5d5cc
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op f6a3dd3e60596db6674caf5f4fb5d5cc

