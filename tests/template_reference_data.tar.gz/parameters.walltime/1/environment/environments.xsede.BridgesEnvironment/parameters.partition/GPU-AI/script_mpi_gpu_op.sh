#!/bin/bash
#SBATCH --job-name="SubmissionTe/mpi_gpu_op/1/f6a3dd3e/0000/f7a49746a0e15ad9401d28489051f6ec"
#SBATCH --partition=GPU-AI
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gres=gpu:volta16:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op[#1](f6a)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j f6a3dd3e60596db6674caf5f4fb5d5cc
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op f6a3dd3e60596db6674caf5f4fb5d5cc

