#!/bin/bash
#SBATCH --job-name="SubmissionTe/d52fc627/gpu_op/0000/9c39197da4fdb56c1c1267e93ab20d05"
#SBATCH --partition=GPU
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/johndoe/project/

# gpu_op(d52fc62789278c7532552747230bca38)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op d52fc62789278c7532552747230bca38

