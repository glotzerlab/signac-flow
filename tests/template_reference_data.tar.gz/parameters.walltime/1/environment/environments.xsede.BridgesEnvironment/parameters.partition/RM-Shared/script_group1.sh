#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d23507f3907b4cbded78a54f68/parallel_ops/8437204e960da6c2d632fadb14fbc279"
#SBATCH --mem=4.0G
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 66c927d23507f3907b4cbded78a54f68
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 66c927d23507f3907b4cbded78a54f68
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 66c927d23507f3907b4cbded78a54f68

