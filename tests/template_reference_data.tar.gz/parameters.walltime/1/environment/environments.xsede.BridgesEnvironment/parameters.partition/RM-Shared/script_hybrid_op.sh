#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d2/hybrid_op/0000/8af6ea26e5079356ed75512722361727"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(66c927d23507f3907b4cbded78a54f68)
export OMP_NUM_THREADS=4
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 66c927d23507f3907b4cbded78a54f68

