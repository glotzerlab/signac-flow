#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d2/mpi_op/0000/ce0ae7e108924e52fc12c4c815bf1a7e"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 66c927d23507f3907b4cbded78a54f68
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 66c927d23507f3907b4cbded78a54f68

