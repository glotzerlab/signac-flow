#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d23507f3907b4cbded78a54f68/multiline_cm/cec21ab48200cab60c3a76030091bc4b"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 66c927d23507f3907b4cbded78a54f68
# Eligible to run:
# echo "First line"
# echo "Second line"

