#SBATCH --job-name="SubmissionTe/66c927d2/parallel_op/0000/"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 2