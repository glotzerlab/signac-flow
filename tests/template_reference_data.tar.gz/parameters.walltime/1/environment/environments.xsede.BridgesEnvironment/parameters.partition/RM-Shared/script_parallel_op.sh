#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d2/parallel_op/0000/b953354468313d18e60dd2e4fec9ee64"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op(66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 66c927d23507f3907b4cbded78a54f68
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec parallel_op 66c927d23507f3907b4cbded78a54f68

