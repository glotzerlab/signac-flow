#!/bin/bash
#SBATCH --job-name="SubmissionTe/66c927d23507f3907b4cbded78a54f68/parallel_op/0000/a8cf3dd9d6895c08d29f38a50187cb8a"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op[#1](66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 66c927d23507f3907b4cbded78a54f68
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 66c927d23507f3907b4cbded78a54f68

