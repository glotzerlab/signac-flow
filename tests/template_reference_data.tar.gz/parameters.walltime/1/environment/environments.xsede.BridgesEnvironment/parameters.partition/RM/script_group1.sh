#!/bin/bash
#SBATCH --job-name="SubmissionTe/group1/1/a8393870/0000/606da3f46cd254adfeda2529111aa7b9"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1[#1](a83)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op a83938708abee3a3abb1c040a684e8b1
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op a83938708abee3a3abb1c040a684e8b1

