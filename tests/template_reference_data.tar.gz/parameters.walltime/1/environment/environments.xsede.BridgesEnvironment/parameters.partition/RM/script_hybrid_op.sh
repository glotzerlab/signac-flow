#!/bin/bash
#SBATCH --job-name="SubmissionTe/a8393870/hybrid_op/0000/62acb7b020ee75ca381c7aab0cc4ca7a"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(a83938708abee3a3abb1c040a684e8b1)
export OMP_NUM_THREADS=4
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op a83938708abee3a3abb1c040a684e8b1

