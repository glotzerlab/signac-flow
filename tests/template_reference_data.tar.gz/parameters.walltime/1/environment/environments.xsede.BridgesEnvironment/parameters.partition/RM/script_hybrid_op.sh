#!/bin/bash
#SBATCH --job-name="SubmissionTe/a8393870/hybrid_op/0000/20ae7ab293f5378d437af28961fa1f61"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec hybrid_op a83938708abee3a3abb1c040a684e8b1

