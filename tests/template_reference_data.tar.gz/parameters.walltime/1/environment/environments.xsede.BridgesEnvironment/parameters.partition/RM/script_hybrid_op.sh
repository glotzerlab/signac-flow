#!/bin/bash
#SBATCH --job-name="SubmissionTe/a83938708abee3a3abb1c040a684e8b1/hybrid_op/117e0937a0137a5ea0d6c7054f17636a"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op a83938708abee3a3abb1c040a684e8b1

