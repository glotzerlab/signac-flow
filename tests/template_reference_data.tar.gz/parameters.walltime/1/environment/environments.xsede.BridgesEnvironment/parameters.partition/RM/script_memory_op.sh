#!/bin/bash
#SBATCH --job-name="SubmissionTe/a83938708abee3a3abb1c040a684e8b1/memory_op/da784a503c196b21e50593bbf14b6b52"
#SBATCH --mem=8.0G
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op a83938708abee3a3abb1c040a684e8b1

