#!/bin/bash
#SBATCH --job-name="SubmissionTe/a83938708abee3a3abb1c040a684e8b1/mpi_op/788727a1555c46ba6300eada32f47160"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op a83938708abee3a3abb1c040a684e8b1

