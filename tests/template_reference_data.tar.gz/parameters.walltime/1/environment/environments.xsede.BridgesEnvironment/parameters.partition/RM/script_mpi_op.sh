#!/bin/bash
#SBATCH --job-name="SubmissionTe/a8393870/mpi_op/0000/5b242a93bf9d435e570cfe5ee93712c0"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(a83938708abee3a3abb1c040a684e8b1)
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op a83938708abee3a3abb1c040a684e8b1

