#!/bin/bash
#SBATCH --job-name="SubmissionTe/a83938708abee3a3abb1c040a684e8b1/multiline_cm/8a863b413147a86b63a869ad6eb7a9f2"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# echo "First line"
# echo "Second line"

