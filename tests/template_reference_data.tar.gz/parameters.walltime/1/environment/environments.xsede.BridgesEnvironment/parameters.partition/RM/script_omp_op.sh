#!/bin/bash
#SBATCH --job-name="SubmissionTe/a8393870/omp_op/0000/ebb21b210d8f1ba4f799a152d4e419bd"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# omp_op(a83938708abee3a3abb1c040a684e8b1)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op a83938708abee3a3abb1c040a684e8b1

