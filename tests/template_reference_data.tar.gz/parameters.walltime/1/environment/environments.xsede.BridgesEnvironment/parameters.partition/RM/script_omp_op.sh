#!/bin/bash
#SBATCH --job-name="SubmissionTe/a8393870/omp_op/0000/ee4f03f66884b5702cec6d2b6e122aa7"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# export OMP_NUM_THREADS=4  /usr/local/bin/python generate_template_reference_data.py exec omp_op a83938708abee3a3abb1c040a684e8b1

