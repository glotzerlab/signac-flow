#!/bin/bash
#SBATCH --job-name="SubmissionTe/a8393870/parallel_op/0000/e76e30c7f52a2f2c43ff34ecb3eb9cd3"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/johndoe/project/

# parallel_op(a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op a83938708abee3a3abb1c040a684e8b1

