#!/bin/bash
#SBATCH --job-name="SubmissionTe/a83938708abee3a3abb1c040a684e8b1/serial_op/d1b89966529e4dba425c7ef6f6bd91b3"
#SBATCH --mem=4.0G
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(a83938708abee3a3abb1c040a684e8b1)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j a83938708abee3a3abb1c040a684e8b1
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op a83938708abee3a3abb1c040a684e8b1

