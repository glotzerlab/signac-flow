#!/bin/bash
#SBATCH --job-name="SubmissionTe/hybrid_op/1/0a46314f/0000/324c9c8f3e29d611e2d53ad2d1733a42"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](0a4)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 0a46314f3bb21140debbc8e4af120947

