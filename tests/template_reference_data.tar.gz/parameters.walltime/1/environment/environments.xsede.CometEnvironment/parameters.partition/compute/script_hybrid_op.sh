#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f/hybrid_op/0000/efabfaf08d070a8ed4631481b1856205"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(0a46314f3bb21140debbc8e4af120947)
export OMP_NUM_THREADS=4
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 0a46314f3bb21140debbc8e4af120947

