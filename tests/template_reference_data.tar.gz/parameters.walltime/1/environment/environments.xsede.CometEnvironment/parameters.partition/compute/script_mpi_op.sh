#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f/mpi_op/0000/b8fb30606a26c2aefce028c4a1e81131"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(0a46314f3bb21140debbc8e4af120947)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 0a46314f3bb21140debbc8e4af120947

