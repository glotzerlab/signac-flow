#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f/mpi_op/0000/5c062d6556259c53847010a95090e66e"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(0a46314f3bb21140debbc8e4af120947)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec mpi_op 0a46314f3bb21140debbc8e4af120947

