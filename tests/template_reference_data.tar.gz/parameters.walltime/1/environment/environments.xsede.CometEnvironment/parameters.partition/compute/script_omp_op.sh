DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f3bb21140debbc8e4af120947/omp_op/2a36c8c7ad09d61b83078a55c0c414b1"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(0a46314f3bb21140debbc8e4af120947)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 0a46314f3bb21140debbc8e4af120947

