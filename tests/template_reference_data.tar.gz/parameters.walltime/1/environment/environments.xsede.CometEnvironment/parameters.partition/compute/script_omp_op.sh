#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f/omp_op/0000/11d8de4799b27c6079d34c70a393f9cb"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(0a46314f3bb21140debbc8e4af120947)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# export OMP_NUM_THREADS=4;  /home/bdice/miniconda3/envs/dice/bin/python generate_template_reference_data.py exec omp_op 0a46314f3bb21140debbc8e4af120947

