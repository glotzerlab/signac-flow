#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f3bb21140debbc8e4af120947/parallel_op/0000/bb9209ed1645c4099505fb9c7c82de5e"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op[#1](0a46314f3bb21140debbc8e4af120947)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 0a46314f3bb21140debbc8e4af120947

