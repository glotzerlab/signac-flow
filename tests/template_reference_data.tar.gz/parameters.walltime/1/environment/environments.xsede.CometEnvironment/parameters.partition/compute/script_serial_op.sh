#!/bin/bash
#SBATCH --job-name="SubmissionTe/0a46314f/serial_op/0000/e87b990d5a8c77e3c93b4ee334821bac"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(0a46314f3bb21140debbc8e4af120947)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 0a46314f3bb21140debbc8e4af120947

