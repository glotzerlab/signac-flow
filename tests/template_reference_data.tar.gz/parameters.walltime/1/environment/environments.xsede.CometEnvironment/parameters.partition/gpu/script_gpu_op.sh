#!/bin/bash
#SBATCH --job-name="SubmissionTe/b2c00b6e/gpu_op/0000/037e1a9a41e396f2c8131d86edf272fd"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# gpu_op(b2c00b6e5630ad7c40eb9f7ce4f0576c)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j b2c00b6e5630ad7c40eb9f7ce4f0576c
# Eligible to run:
# mpiexec -n 2  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec gpu_op b2c00b6e5630ad7c40eb9f7ce4f0576c

