DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/b2c00b6e5630ad7c40eb9f7ce4f0576c/gpu_op/74e8ed0d45e4626af6f5197c8c30428e"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# gpu_op(b2c00b6e5630ad7c40eb9f7ce4f0576c)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j b2c00b6e5630ad7c40eb9f7ce4f0576c
# Eligible to run:
# ibrun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op b2c00b6e5630ad7c40eb9f7ce4f0576c

