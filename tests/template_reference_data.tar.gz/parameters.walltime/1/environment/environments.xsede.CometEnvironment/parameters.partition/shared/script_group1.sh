#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81/parallel_ops/0000/b706d9d2cf200e6df7c1b2706d7dc450"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1[#1](f90)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op f90e4a81f388264f4050b3486a84377b
# /usr/local/bin/python generate_template_reference_data.py exec serial_op f90e4a81f388264f4050b3486a84377b

