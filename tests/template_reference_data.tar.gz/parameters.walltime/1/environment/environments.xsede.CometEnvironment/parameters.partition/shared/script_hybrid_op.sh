#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81f388264f4050b3486a84377b/hybrid_op/8f9c92a04bbe5cf4dfbf09e8477924fd"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op f90e4a81f388264f4050b3486a84377b

