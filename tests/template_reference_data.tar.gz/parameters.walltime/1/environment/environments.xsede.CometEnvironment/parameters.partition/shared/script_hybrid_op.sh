#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81/hybrid_op/0000/84b8495dfa1bb66b59d0f6c5f8f9d91f"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(f90e4a81f388264f4050b3486a84377b)
export OMP_NUM_THREADS=2
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op f90e4a81f388264f4050b3486a84377b

