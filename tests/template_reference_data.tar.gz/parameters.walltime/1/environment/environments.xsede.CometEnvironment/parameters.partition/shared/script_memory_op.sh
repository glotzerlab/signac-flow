DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81f388264f4050b3486a84377b/memory_op/90a2bfeb4fe9b1058d6b59fa3866599b"
#SBATCH --mem=0.5G
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op f90e4a81f388264f4050b3486a84377b

