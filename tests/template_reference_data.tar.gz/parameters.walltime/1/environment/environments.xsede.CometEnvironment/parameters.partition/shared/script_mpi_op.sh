#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81/mpi_op/0000/cbdd09a8c7eeb1eb6fd361187d60312b"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# mpiexec -n 5  /home/bdice/miniconda3/envs/dice/bin/python generate_template_reference_data.py exec mpi_op f90e4a81f388264f4050b3486a84377b

