#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81f388264f4050b3486a84377b/mpi_op/0000/e5f44ee3c62b6164b8ddc3b4638cd156"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op f90e4a81f388264f4050b3486a84377b

