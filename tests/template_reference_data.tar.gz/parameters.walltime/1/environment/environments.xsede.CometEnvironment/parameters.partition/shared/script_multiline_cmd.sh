DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81f388264f4050b3486a84377b/multiline_cm/9a0bb732d372cc85ddd365e1541dedde"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# echo "First line"
# echo "Second line"

