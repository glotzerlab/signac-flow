#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81/omp_op/0000/54015f3f2a10c8c4ba524ae5572976b1"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# export OMP_NUM_THREADS=4  /usr/local/bin/python generate_template_reference_data.py exec omp_op f90e4a81f388264f4050b3486a84377b

