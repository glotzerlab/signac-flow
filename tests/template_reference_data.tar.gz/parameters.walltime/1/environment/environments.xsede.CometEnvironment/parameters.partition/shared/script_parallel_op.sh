#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81/parallel_op/0000/8d0fff6ff4b43437947da259a64b36ba"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/johndoe/project/

# parallel_op(f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op f90e4a81f388264f4050b3486a84377b

