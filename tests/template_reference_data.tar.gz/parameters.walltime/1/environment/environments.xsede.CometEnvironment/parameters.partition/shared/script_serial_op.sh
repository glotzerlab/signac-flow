#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81/serial_op/0000/f3091ec4d51734edd3b823614addd833"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op[#1](f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op f90e4a81f388264f4050b3486a84377b

