DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/f90e4a81f388264f4050b3486a84377b/walltime_op/f1cc04276c2be69214662c8bff0ac631"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# walltime_op(f90e4a81f388264f4050b3486a84377b)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j f90e4a81f388264f4050b3486a84377b
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op f90e4a81f388264f4050b3486a84377b

