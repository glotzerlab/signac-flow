#!/bin/bash
#SBATCH --job-name="SubmissionTe/group1/1/bd2a461a/0000/d1ec50d6ec8f6b3dfd7add934fb1bcb9"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# group1[#1](bd2)
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o group1 -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op bd2a461ab99b72a1458a108f8210376c
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op bd2a461ab99b72a1458a108f8210376c


