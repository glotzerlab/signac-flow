#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461ab99b72a1458a108f8210376c/memory_op/7c4e65a413da236635f555d183eff7ff"
#SBATCH --mem=8.0G
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# memory_op(bd2a461ab99b72a1458a108f8210376c)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op bd2a461ab99b72a1458a108f8210376c


