#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461a/mpi_op/0000/c4a9b0d479e813962319b9df13e818a5"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(bd2a461ab99b72a1458a108f8210376c)
ibrun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op bd2a461ab99b72a1458a108f8210376c

