DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461ab99b72a1458a108f8210376c/mpi_op/ed0f81b3882b6d39f5c8d52e20aeface"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op(bd2a461ab99b72a1458a108f8210376c)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# ibrun -n 5 -o 0 task_affinity  /usr/local/bin/python generate_template_reference_data.py exec mpi_op bd2a461ab99b72a1458a108f8210376c


