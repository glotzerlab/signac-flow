DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461ab99b72a1458a108f8210376c/multiline_cm/eb892a4c338c8c585a93c12bbf201bbb"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(bd2a461ab99b72a1458a108f8210376c)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# echo "First line"
# echo "Second line"


