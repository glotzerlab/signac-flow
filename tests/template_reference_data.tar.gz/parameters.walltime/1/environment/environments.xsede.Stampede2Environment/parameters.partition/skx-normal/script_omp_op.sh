#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461a/omp_op/0000/6b41e48531dc6ecc19454f77a06f4a8e"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# omp_op(bd2a461ab99b72a1458a108f8210376c)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op bd2a461ab99b72a1458a108f8210376c

