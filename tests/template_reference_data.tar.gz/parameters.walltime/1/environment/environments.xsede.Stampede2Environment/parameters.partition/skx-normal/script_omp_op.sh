#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461ab99b72a1458a108f8210376c/omp_op/4bf85e23f00357f25d947a6913c62b9e"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# omp_op(bd2a461ab99b72a1458a108f8210376c)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op bd2a461ab99b72a1458a108f8210376c


