#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461a/parallel_op/0000/5d1c33f8dc97e848fa48f8283f372abf"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# parallel_op(bd2a461ab99b72a1458a108f8210376c)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op bd2a461ab99b72a1458a108f8210376c

