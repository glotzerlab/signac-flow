DeprecationWarning: The walltime argument is deprecated as of 0.13 and will be removed in 0.14. Use the walltime directive instead.
1:00:00
#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461ab99b72a1458a108f8210376c/parallel_op/9896b842d6848d34e357cad369f7b934"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# parallel_op(bd2a461ab99b72a1458a108f8210376c)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op bd2a461ab99b72a1458a108f8210376c


