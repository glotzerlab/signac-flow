#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461a/serial_op/0000/151150621accbd6a5171386ff61b1f1d"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# serial_op[#1](bd2)
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o serial_op -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op bd2a461ab99b72a1458a108f8210376c


