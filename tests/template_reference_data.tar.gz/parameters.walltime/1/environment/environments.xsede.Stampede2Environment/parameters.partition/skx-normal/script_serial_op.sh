#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461a/serial_op/0000/6c414d41ffc0fdff2f8e8d7c72c78217"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(bd2a461ab99b72a1458a108f8210376c)
/usr/local/bin/python generate_template_reference_data.py exec serial_op bd2a461ab99b72a1458a108f8210376c

