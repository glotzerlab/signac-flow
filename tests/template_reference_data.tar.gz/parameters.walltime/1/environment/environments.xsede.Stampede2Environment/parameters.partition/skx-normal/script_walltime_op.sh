#!/bin/bash
#SBATCH --job-name="SubmissionTe/bd2a461ab99b72a1458a108f8210376c/walltime_op/28e29906b750c497950401482667c4a3"
#SBATCH --partition=skx-normal
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# walltime_op(bd2a461ab99b72a1458a108f8210376c)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j bd2a461ab99b72a1458a108f8210376c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op bd2a461ab99b72a1458a108f8210376c


