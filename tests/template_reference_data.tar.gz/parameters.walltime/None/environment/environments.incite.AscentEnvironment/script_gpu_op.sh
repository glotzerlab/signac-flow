#!/bin/bash
#BSUB -J SubmissionTe/fb0231a9/gpu_op/0000/3ee9a9cebf9fd7160822b030d9dae0bf
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# gpu_op(fb0231a9524b4e3f39fa0d6a655375d4)
jsrun -n 1 -a 1 -c 1 -g 2 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec gpu_op fb0231a9524b4e3f39fa0d6a655375d4

