#!/bin/bash
#BSUB -J SubmissionTe/fb0231a9/hybrid_op/0000/0d0ef6da00c23ceeddc03e4297a77c2b
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# hybrid_op(fb0231a9524b4e3f39fa0d6a655375d4)
export OMP_NUM_THREADS=4
jsrun -n 20 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec hybrid_op fb0231a9524b4e3f39fa0d6a655375d4

