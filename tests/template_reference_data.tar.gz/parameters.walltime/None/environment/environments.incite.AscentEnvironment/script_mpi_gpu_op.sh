#!/bin/bash
#BSUB -J SubmissionTe/fb0231a9/mpi_gpu_op/0000/65fe9e0d01c90a07f3674e6fe1b46125
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(fb0231a9524b4e3f39fa0d6a655375d4)
jsrun -n 1 -a 5 -c 5 -g 2 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op fb0231a9524b4e3f39fa0d6a655375d4

