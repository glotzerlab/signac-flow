#!/bin/bash
#BSUB -J SubmissionTe/fb0231a9/omp_op/0000/775f0ed2c6cc6aa34fc04a52aa76ac45
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# omp_op(fb0231a9524b4e3f39fa0d6a655375d4)
export OMP_NUM_THREADS=4
jsrun -n 4 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec omp_op fb0231a9524b4e3f39fa0d6a655375d4

