#!/bin/bash
#BSUB -J SubmissionTe/fb0231a9/parallel_op/0000/f7eb30b632b11091417f420bc7da82f0
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# parallel_op(fb0231a9524b4e3f39fa0d6a655375d4)
jsrun -n 1 -a 1 -c 3 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec parallel_op fb0231a9524b4e3f39fa0d6a655375d4

