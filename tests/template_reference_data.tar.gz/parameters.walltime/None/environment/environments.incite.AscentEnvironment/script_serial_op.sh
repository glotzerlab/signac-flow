#!/bin/bash
#BSUB -J SubmissionTe/fb0231a9/serial_op/0000/05f165b213adb57efd67832245b3c70a
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# serial_op(fb0231a9524b4e3f39fa0d6a655375d4)
jsrun -n 1 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec serial_op fb0231a9524b4e3f39fa0d6a655375d4

