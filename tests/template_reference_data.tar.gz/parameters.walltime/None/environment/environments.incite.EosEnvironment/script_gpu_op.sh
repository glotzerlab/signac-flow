#PBS -N SubmissionTe/5c02d3da/gpu_op/0000/3139f648b71848d5e374a54c3e4247b9
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# gpu_op(5c02d3da683f5a590dc86cc4821c07b0)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 5c02d3da683f5a590dc86cc4821c07b0

