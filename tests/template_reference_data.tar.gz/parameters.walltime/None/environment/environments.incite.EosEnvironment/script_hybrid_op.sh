#PBS -N SubmissionTe/5c02d3da/hybrid_op/0000/4826f402f86fdebfd74a0e33017466fd
#PBS -V
#PBS -l nodes=1
#PBS -A MAT110

set -e
set -u

cd /home/user/project/

# hybrid_op(5c02d3da683f5a590dc86cc4821c07b0)
export OMP_NUM_THREADS=4
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 5c02d3da683f5a590dc86cc4821c07b0

