#PBS -N SubmissionTe/5c02d3da/hybrid_op/0000/c5c18fda93c14fcdd33b3e21b9c522fc
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(5c02d3da683f5a590dc86cc4821c07b0)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 5c02d3da683f5a590dc86cc4821c07b0

