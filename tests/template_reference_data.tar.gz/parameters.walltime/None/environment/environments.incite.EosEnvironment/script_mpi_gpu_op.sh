#PBS -N SubmissionTe/5c02d3da/mpi_gpu_op/0000/72c98217ab2513fe9afef9dabbe5ff52
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(5c02d3da683f5a590dc86cc4821c07b0)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 5c02d3da683f5a590dc86cc4821c07b0

