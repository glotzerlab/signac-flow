#PBS -N SubmissionTe/5c02d3da/mpi_op/0000/f9d84449059ea91a9fc041c829c8777b
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_op(5c02d3da683f5a590dc86cc4821c07b0)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 5c02d3da683f5a590dc86cc4821c07b0

