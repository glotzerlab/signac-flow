#PBS -N SubmissionTe/5c02d3da/omp_op/0000/d6dc573e9d70faa9750c22531f57913f
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# omp_op(5c02d3da683f5a590dc86cc4821c07b0)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 5c02d3da683f5a590dc86cc4821c07b0

