#PBS -N SubmissionTe/5c02d3da/omp_op/0000/2367683821cdc711b24f5da74823c503
#PBS -V
#PBS -l nodes=1
#PBS -A MAT110

set -e
set -u

cd /home/user/project/

# omp_op(5c02d3da683f5a590dc86cc4821c07b0)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 5c02d3da683f5a590dc86cc4821c07b0

