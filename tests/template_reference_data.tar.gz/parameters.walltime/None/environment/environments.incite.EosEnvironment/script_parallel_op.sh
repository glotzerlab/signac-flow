#PBS -N SubmissionTe/5c02d3da/parallel_op/0000/7e8809146ac9faea0c9395f20f177f61
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# parallel_op(5c02d3da683f5a590dc86cc4821c07b0)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 5c02d3da683f5a590dc86cc4821c07b0

