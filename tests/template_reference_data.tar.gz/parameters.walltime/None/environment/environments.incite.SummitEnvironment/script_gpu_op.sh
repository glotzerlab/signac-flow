#!/bin/bash
#BSUB -J SubmissionTe/gpu_op/1/e6cbac22/0000/0bcc09345069d1ba78c308cdd509e647
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# gpu_op[#1](e6c)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op e6cbac22c5887a52771be793228ff1a9

