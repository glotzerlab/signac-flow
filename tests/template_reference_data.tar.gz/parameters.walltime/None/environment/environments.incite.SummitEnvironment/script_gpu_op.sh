#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/gpu_op/0000/0bcc09345069d1ba78c308cdd509e647
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# gpu_op(e6cbac22c5887a52771be793228ff1a9)
jsrun -n 1 -a 1 -c 1 -g 2 --smpiargs='-gpu' -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec gpu_op e6cbac22c5887a52771be793228ff1a9

