#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/parallel_ops/e094e64226f42fb587975dea0f589ad3
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# group1(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op e6cbac22c5887a52771be793228ff1a9
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op e6cbac22c5887a52771be793228ff1a9

