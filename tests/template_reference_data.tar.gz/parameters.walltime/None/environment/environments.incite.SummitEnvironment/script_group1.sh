#!/bin/bash
#BSUB -J SubmissionTe/group1/1/e6cbac22/0000/97d0a878b804677655ab6d5470136204
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# group1[#1](e6c)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op e6cbac22c5887a52771be793228ff1a9
# /usr/local/bin/python generate_template_reference_data.py exec serial_op e6cbac22c5887a52771be793228ff1a9

