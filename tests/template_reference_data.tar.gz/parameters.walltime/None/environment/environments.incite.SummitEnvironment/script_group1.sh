#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/memory_oppar/0f385ddadaebf7ed5a1011b778b48705
#BSUB -M 0.5GB
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# group1(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec serial_op e6cbac22c5887a52771be793228ff1a9
# jsrun -n 1 -a 1 -c 3 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec parallel_op e6cbac22c5887a52771be793228ff1a9
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec memory_op e6cbac22c5887a52771be793228ff1a9

