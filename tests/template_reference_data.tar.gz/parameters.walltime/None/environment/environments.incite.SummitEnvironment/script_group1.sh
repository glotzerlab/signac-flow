None
#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/memory_oppar/a8f850b4b1e54a057b9344135f19f3c6
#BSUB -M 0.5GB
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# group1(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec serial_op e6cbac22c5887a52771be793228ff1a9
# jsrun -n 1 -a 1 -c 3 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec parallel_op e6cbac22c5887a52771be793228ff1a9
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec memory_op e6cbac22c5887a52771be793228ff1a9
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec walltime_op e6cbac22c5887a52771be793228ff1a9

