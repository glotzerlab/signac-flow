#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/hybrid_op/0000/731baf42cfa75b9688dcd3daae349f11
#BSUB -nnodes 1
#BSUB -P MAT110

set -e
set -u

cd /home/user/project/

# hybrid_op(e6cbac22c5887a52771be793228ff1a9)
export OMP_NUM_THREADS=4
jsrun -n 20 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec hybrid_op e6cbac22c5887a52771be793228ff1a9

