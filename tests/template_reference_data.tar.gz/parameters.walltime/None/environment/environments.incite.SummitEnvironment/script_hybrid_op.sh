#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/hybrid_op/10b39dbe27f7aa0822bb4414a05eb9d1
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# export OMP_NUM_THREADS=4; jsrun -n 5 -a 1 -c 4 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op e6cbac22c5887a52771be793228ff1a9

