#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/hybrid_op/0000/731baf42cfa75b9688dcd3daae349f11
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](e6c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op e6cbac22c5887a52771be793228ff1a9

