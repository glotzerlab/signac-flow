#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/hybrid_op/0000/731baf42cfa75b9688dcd3daae349f11
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# hybrid_op(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec hybrid_op e6cbac22c5887a52771be793228ff1a9

