None
#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/memory_op/901a5e20dfc29767cdf5f820999fe808
#BSUB -M 0.5GB
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# memory_op(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec memory_op e6cbac22c5887a52771be793228ff1a9

