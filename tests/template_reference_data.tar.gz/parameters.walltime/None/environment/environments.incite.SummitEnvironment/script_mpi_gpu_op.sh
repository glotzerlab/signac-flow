#!/bin/bash
#BSUB -J SubmissionTe/mpi_gpu_op/1/e6cbac22/0000/4e0dccab2cc57044db7b62db0ac85ff3
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op[#1](e6c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op e6cbac22c5887a52771be793228ff1a9

