None
#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/mpi_gpu_op/30fc4d270229d98d39936326435b4505
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# jsrun -n 1 -a 5 -c 5 -g 2 --smpiargs='-gpu' -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op e6cbac22c5887a52771be793228ff1a9

