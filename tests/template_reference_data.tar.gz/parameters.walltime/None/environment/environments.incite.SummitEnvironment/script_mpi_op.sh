None
#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/mpi_op/156030ffce9507d5b81635148c21a880
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# jsrun -n 5 -a 1 -c 1 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec mpi_op e6cbac22c5887a52771be793228ff1a9

