#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/mpi_op/0000/ac68ab652494c7bbab6f6bd7867a50e0
#BSUB -nnodes 1
#BSUB -P MAT110

set -e
set -u

cd /home/user/project/

# mpi_op(e6cbac22c5887a52771be793228ff1a9)
jsrun -n 5 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec mpi_op e6cbac22c5887a52771be793228ff1a9

