#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/mpi_op/0000/ac68ab652494c7bbab6f6bd7867a50e0
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op[#1](e6c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op e6cbac22c5887a52771be793228ff1a9

