#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/mpi_op/0000/16d54067b9f0b59b427675a8c1afb54e
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# mpi_op[#1](e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op e6cbac22c5887a52771be793228ff1a9

