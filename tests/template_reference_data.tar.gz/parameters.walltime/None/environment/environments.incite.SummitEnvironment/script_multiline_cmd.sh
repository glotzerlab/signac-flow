None
#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/multiline_cm/c7d869d94c5b9a652484ebf2cdef7a68
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# multiline_cmd(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# jsrun -n 1 -a 1 -c 1 -g 0  -d packed -b rs  echo "First line"
# echo "Second line"

