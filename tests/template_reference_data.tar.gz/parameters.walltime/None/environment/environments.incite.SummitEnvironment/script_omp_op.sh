#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/omp_op/10cf977ffa06e74111cf4c300dadd9c8
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# omp_op(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# export OMP_NUM_THREADS=4; jsrun -n 1 -a 1 -c 4 -g 0  -d packed -b rs  /usr/local/bin/python generate_template_reference_data.py exec omp_op e6cbac22c5887a52771be793228ff1a9

