#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/parallel_op/0000/724e2da3c8f93235f3c023c95b7854c9
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# parallel_op(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec parallel_op e6cbac22c5887a52771be793228ff1a9

