#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22c5887a52771be793228ff1a9/serial_op/a9ba81d1b7e37554144b673d3bf89973
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# serial_op(e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op e6cbac22c5887a52771be793228ff1a9

