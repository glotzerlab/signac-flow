#!/bin/bash
#BSUB -J SubmissionTe/e6cbac22/serial_op/0000/b95e15230286dd978a47893f9a3279d4
#BSUB -nnodes 1
#BSUB -P MAT110

set -e
set -u

cd /home/user/project/

# serial_op(e6cbac22c5887a52771be793228ff1a9)
jsrun -n 1 -a 1 -c 1 -g 0 -d packed -b rs /usr/local/bin/python generate_template_reference_data.py exec serial_op e6cbac22c5887a52771be793228ff1a9

