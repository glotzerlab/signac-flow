#PBS -N SubmissionTe/50d0bba0/gpu_op/0000/99bdf4356583b4f821c1c3b711cbf969
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/user/project/

# gpu_op(50d0bba019db759bcdbddb9aed4cd204)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 50d0bba019db759bcdbddb9aed4cd204

