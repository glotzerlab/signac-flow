#PBS -N SubmissionTe/50d0bba0/gpu_op/0000/c645cf29d2c57bb2547824763dbad9ee
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/johndoe/project/

# gpu_op(50d0bba019db759bcdbddb9aed4cd204)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op 50d0bba019db759bcdbddb9aed4cd204

