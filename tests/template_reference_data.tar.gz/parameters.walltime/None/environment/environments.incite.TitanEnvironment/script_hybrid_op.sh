#PBS -N SubmissionTe/50d0bba0/hybrid_op/0000/ad3e4e289908cf14eea646f60ed164e9
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(50d0bba019db759bcdbddb9aed4cd204)
export OMP_NUM_THREADS=2
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 50d0bba019db759bcdbddb9aed4cd204

