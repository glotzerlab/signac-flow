#PBS -N SubmissionTe/50d0bba0/mpi_gpu_op/0000/f3809c1ab29c8f535d37475d99ae90e5
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# mpi_gpu_op(50d0bba019db759bcdbddb9aed4cd204)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 50d0bba019db759bcdbddb9aed4cd204

