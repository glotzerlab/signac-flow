#PBS -N SubmissionTe/50d0bba0/mpi_gpu_op/0000/1c9923d8af74fea901f86911f0013b42
#PBS -V
#PBS -l nodes=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(50d0bba019db759bcdbddb9aed4cd204)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 50d0bba019db759bcdbddb9aed4cd204

