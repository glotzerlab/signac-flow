#PBS -N SubmissionTe/50d0bba0/mpi_op/0000/bc08d63d49a797916d76fe2f1ffdb26d
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# mpi_op(50d0bba019db759bcdbddb9aed4cd204)
aprun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 50d0bba019db759bcdbddb9aed4cd204

