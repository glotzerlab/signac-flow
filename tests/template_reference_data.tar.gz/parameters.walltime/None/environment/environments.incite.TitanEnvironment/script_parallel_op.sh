#PBS -N SubmissionTe/50d0bba0/parallel_op/0000/78061a42dc524053a20bd7c123804f93
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# parallel_op(50d0bba019db759bcdbddb9aed4cd204)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 50d0bba019db759bcdbddb9aed4cd204

