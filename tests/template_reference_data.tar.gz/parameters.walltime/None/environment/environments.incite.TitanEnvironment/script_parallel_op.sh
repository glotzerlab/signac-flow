#PBS -N SubmissionTe/50d0bba0/parallel_op/0000/e6c2b1d9397904562dcc139fdcf22f49
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# parallel_op(50d0bba019db759bcdbddb9aed4cd204)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 50d0bba019db759bcdbddb9aed4cd204

