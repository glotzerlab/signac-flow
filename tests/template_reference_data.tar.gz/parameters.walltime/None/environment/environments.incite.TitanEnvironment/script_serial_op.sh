#PBS -N SubmissionTe/50d0bba0/serial_op/0000/2abfdc46cd9a1f93d622e94917ea247d
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/user/project/

# serial_op(50d0bba019db759bcdbddb9aed4cd204)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 50d0bba019db759bcdbddb9aed4cd204

