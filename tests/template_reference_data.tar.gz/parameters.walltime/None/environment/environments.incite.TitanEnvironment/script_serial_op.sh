#PBS -N SubmissionTe/50d0bba0/serial_op/0000/0ded930feaaae032a8f1822b7c8b9892
#PBS -V
#PBS -l nodes=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(50d0bba019db759bcdbddb9aed4cd204)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 50d0bba019db759bcdbddb9aed4cd204

