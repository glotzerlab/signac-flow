#PBS -N SubmissionTe/a43b5a3b/gpu_op/0000/814e710c691994295aeddb99852750cd
#PBS -V
#PBS -l nodes=1
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# gpu_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op a43b5a3b12e3499d4e23ba6f7ad011b1

