#PBS -N SubmissionTe/a43b5a3b/hybrid_op/0000/04858a97b68451549cda6c80e98716be
#PBS -V
#PBS -l nodes=5:ppn=4
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
export OMP_NUM_THREADS=4
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op a43b5a3b12e3499d4e23ba6f7ad011b1

