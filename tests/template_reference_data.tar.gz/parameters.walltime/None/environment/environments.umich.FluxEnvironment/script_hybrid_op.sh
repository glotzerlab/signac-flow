#PBS -N SubmissionTe/a43b5a3b/hybrid_op/0000/
#PBS -V
#PBS -l nodes=4
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux
export OMP_NUM_THREADS=2