#PBS -N SubmissionTe/a43b5a3b/mpi_gpu_op/0000/4a033f17215a35965a82addc60270a35
#PBS -V
#PBS -l nodes=5:gpus=1
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op a43b5a3b12e3499d4e23ba6f7ad011b1

