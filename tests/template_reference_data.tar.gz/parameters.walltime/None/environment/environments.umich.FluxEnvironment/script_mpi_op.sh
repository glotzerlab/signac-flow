#PBS -N SubmissionTe/a43b5a3b/mpi_op/0000/5dcec00ae1dbb4a02072b30ef0d86f87
#PBS -V
#PBS -l nodes=2
#PBS -l pmem=
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# mpi_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
mpiexec -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op a43b5a3b12e3499d4e23ba6f7ad011b1

