#PBS -N SubmissionTe/a43b5a3b/mpi_op/0000/14371628e20d708327d94c631fdf88a5
#PBS -V
#PBS -l procs=5
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/user/project/

# mpi_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op a43b5a3b12e3499d4e23ba6f7ad011b1

