#PBS -N SubmissionTe/a43b5a3b/omp_op/0000/16148e6550ce3d111291a6d88d77bb92
#PBS -V
#PBS -l nodes=1:ppn=4
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# omp_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op a43b5a3b12e3499d4e23ba6f7ad011b1

