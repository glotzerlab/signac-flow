#PBS -N SubmissionTe/a43b5a3b/parallel_op/0000/198446fb5705cc15ec169b357fbacec0
#PBS -V
#PBS -l procs=3
#PBS -l qos=flux
#PBS -q flux

set -e
set -u

cd /home/johndoe/project/

# parallel_op(a43b5a3b12e3499d4e23ba6f7ad011b1)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op a43b5a3b12e3499d4e23ba6f7ad011b1

