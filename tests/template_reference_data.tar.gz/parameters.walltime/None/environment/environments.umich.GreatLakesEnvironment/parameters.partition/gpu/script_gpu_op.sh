#!/bin/bash
#SBATCH --job-name="SubmissionTe/ba4efd73075609ae545a6f2fd53f3cec/gpu_op/f7c1b5d2605c2dcd242ff98be0f810a5"
#SBATCH --partition=gpu
#SBATCH -t 12:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(ba4efd73075609ae545a6f2fd53f3cec)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j ba4efd73075609ae545a6f2fd53f3cec
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op ba4efd73075609ae545a6f2fd53f3cec

