#!/bin/bash
#SBATCH --job-name="SubmissionTe/ba4efd73/mpi_gpu_op/0000/5802a0b777e14ae75817d32d5a30591e"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5
#SBATCH --gres=gpu:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(ba4efd73075609ae545a6f2fd53f3cec)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j ba4efd73075609ae545a6f2fd53f3cec

