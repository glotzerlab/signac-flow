#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b50e641168bf562c189b6fbfb/parallel_ops/0000/a292cf9918656b8ccf7161d7b831694c"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1[#1](26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 26bd5f5b50e641168bf562c189b6fbfb
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 26bd5f5b50e641168bf562c189b6fbfb

