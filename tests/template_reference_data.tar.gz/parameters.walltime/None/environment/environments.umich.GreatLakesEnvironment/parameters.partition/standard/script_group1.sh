#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b/parallel_ops/0000/ca88b5cdbc1f6ae33f1718b0a8f9e026"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1[#1](26b)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 26bd5f5b50e641168bf562c189b6fbfb
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 26bd5f5b50e641168bf562c189b6fbfb

