#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b50e641168bf562c189b6fbfb/memory_oppar/a8e7c7398459a881ecda9f058192dd5c"
#SBATCH --mem=0.5G
#SBATCH --partition=standard
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 26bd5f5b50e641168bf562c189b6fbfb
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 26bd5f5b50e641168bf562c189b6fbfb
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 26bd5f5b50e641168bf562c189b6fbfb
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 26bd5f5b50e641168bf562c189b6fbfb

