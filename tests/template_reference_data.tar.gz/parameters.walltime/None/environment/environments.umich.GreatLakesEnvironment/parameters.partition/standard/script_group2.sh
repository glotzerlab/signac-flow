#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/4a483a99-5bea7f40/0000/9c1c8c3edcfbfe55963b7bb0a102df7b"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](4a4, 5be)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 4a483a992889fc18663a15acdfdcacba 5bea7f4064798af873fad258b21cf034
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 4a483a992889fc18663a15acdfdcacba 5bea7f4064798af873fad258b21cf034
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 4a483a992889fc18663a15acdfdcacba 5bea7f4064798af873fad258b21cf034

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/92c6054c-f10cfc6d/0000/54288ad835cd89ea64c5fab0be938ce6"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](92c, f10)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 92c6054c6acae4abd09b0055afdf157f f10cfc6dd4fd8c29187aa1971ff2fd87
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 92c6054c6acae4abd09b0055afdf157f f10cfc6dd4fd8c29187aa1971ff2fd87
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 92c6054c6acae4abd09b0055afdf157f f10cfc6dd4fd8c29187aa1971ff2fd87

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/d30f0956-633b8323/0000/4263252ef5f0dc783017cdf775688290"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](d30, 633)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j d30f0956499851002e8bd921cefe93e2 633b8323a34e88b5bef5b59ab5ae6f3f
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op d30f0956499851002e8bd921cefe93e2 633b8323a34e88b5bef5b59ab5ae6f3f
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op d30f0956499851002e8bd921cefe93e2 633b8323a34e88b5bef5b59ab5ae6f3f

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/bd2a461a-0a46314f/0000/2b6e93ecdd3207987c1be02c15c8eb67"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](bd2, 0a4)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j bd2a461ab99b72a1458a108f8210376c 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op bd2a461ab99b72a1458a108f8210376c 0a46314f3bb21140debbc8e4af120947
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op bd2a461ab99b72a1458a108f8210376c 0a46314f3bb21140debbc8e4af120947

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/b9400a2f-ba4efd73/0000/09989abaa0a1426e9095f3b3a7f7dd58"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](b94, ba4)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j b9400a2ff992d9bd5ccfd2ced78b21e6 ba4efd73075609ae545a6f2fd53f3cec
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op b9400a2ff992d9bd5ccfd2ced78b21e6 ba4efd73075609ae545a6f2fd53f3cec
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op b9400a2ff992d9bd5ccfd2ced78b21e6 ba4efd73075609ae545a6f2fd53f3cec

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/9e2461fe-de1e35d9/0000/d697898dc91ae24f991f76e50db1b4eb"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](9e2, de1)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 9e2461fecf22da9d3a066c883cd7f10a de1e35d92b83510d959ebfb4683d7cce
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 9e2461fecf22da9d3a066c883cd7f10a de1e35d92b83510d959ebfb4683d7cce
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 9e2461fecf22da9d3a066c883cd7f10a de1e35d92b83510d959ebfb4683d7cce

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/b2c00b6e-216cd586/0000/a80b6c1e0f95949e6ab801e28febc420"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](b2c, 216)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j b2c00b6e5630ad7c40eb9f7ce4f0576c 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op b2c00b6e5630ad7c40eb9f7ce4f0576c 216cd5860da17dc03ca7facd39d25e5c
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op b2c00b6e5630ad7c40eb9f7ce4f0576c 216cd5860da17dc03ca7facd39d25e5c

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/e6cbac22-dcb62d7d/0000/a60d18aab2e59e019a0c2cccacbe7c5d"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](e6c, dcb)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j e6cbac22c5887a52771be793228ff1a9 dcb62d7ddf30d4049e6087275b07c271
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op e6cbac22c5887a52771be793228ff1a9 dcb62d7ddf30d4049e6087275b07c271
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op e6cbac22c5887a52771be793228ff1a9 dcb62d7ddf30d4049e6087275b07c271

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/a8393870-d142d4b4/0000/dcd0709aca314735ac9794d59cce3b25"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](a83, d14)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j a83938708abee3a3abb1c040a684e8b1 d142d4b4f154ac5011dae8b58cd46b9a
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op a83938708abee3a3abb1c040a684e8b1 d142d4b4f154ac5011dae8b58cd46b9a
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op a83938708abee3a3abb1c040a684e8b1 d142d4b4f154ac5011dae8b58cd46b9a

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/26bd5f5b-df25d491/0000/ec1f864b882f60b3e51e8e04b1204838"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](26b, df2)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 26bd5f5b50e641168bf562c189b6fbfb df25d491cfdf1210db245f94e765ec75
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 26bd5f5b50e641168bf562c189b6fbfb df25d491cfdf1210db245f94e765ec75
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 26bd5f5b50e641168bf562c189b6fbfb df25d491cfdf1210db245f94e765ec75

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/8aef86cd-d52fc627/0000/8031011196d9385858b01c32e486371f"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](8ae, d52)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 8aef86cd5a5dbb175d555864a7c91eed d52fc62789278c7532552747230bca38
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 8aef86cd5a5dbb175d555864a7c91eed d52fc62789278c7532552747230bca38
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 8aef86cd5a5dbb175d555864a7c91eed d52fc62789278c7532552747230bca38

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/31398579-92b8611a/0000/a5ec83b4146ee38e13032295b8d20f46"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](313, 92b)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 31398579b017d58a2b3c230f38560496 92b8611a1ed88c5a249e930d7bcae7a0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 31398579b017d58a2b3c230f38560496 92b8611a1ed88c5a249e930d7bcae7a0
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 31398579b017d58a2b3c230f38560496 92b8611a1ed88c5a249e930d7bcae7a0

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/f90e4a81-66c927d2/0000/d8d17f3990492eb8c1268bdb1c095e0c"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](f90, 66c)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j f90e4a81f388264f4050b3486a84377b 66c927d23507f3907b4cbded78a54f68
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op f90e4a81f388264f4050b3486a84377b 66c927d23507f3907b4cbded78a54f68
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op f90e4a81f388264f4050b3486a84377b 66c927d23507f3907b4cbded78a54f68

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/abd47a2f-0b5d7732/0000/78ff72a57490d90e169fbd79d572a69f"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](abd, 0b5)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j abd47a2fb2ca273ba881932a57fdc4d7 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op abd47a2fb2ca273ba881932a57fdc4d7 0b5d77326769c7e5c65bdcf8c303265c
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op abd47a2fb2ca273ba881932a57fdc4d7 0b5d77326769c7e5c65bdcf8c303265c

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/593a9106-a5e3b313/0000/c1adcc2d797cc119b76627a71b66b956"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](593, a5e)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 593a9106d2d57ba02b9ed29df92002e5 a5e3b313aaf6e78c0f4dd8b58e83949e
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 593a9106d2d57ba02b9ed29df92002e5 a5e3b313aaf6e78c0f4dd8b58e83949e
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 593a9106d2d57ba02b9ed29df92002e5 a5e3b313aaf6e78c0f4dd8b58e83949e

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/f6a3dd3e-2e49a8cb/0000/10c941e80f926e0c34df6e67c66d84d7"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](f6a, 2e4)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j f6a3dd3e60596db6674caf5f4fb5d5cc 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op f6a3dd3e60596db6674caf5f4fb5d5cc 2e49a8cb2fc131daf5747c8adc0da35e
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op f6a3dd3e60596db6674caf5f4fb5d5cc 2e49a8cb2fc131daf5747c8adc0da35e

#!/bin/bash
#SBATCH --job-name="SubmissionTe/group2/2/7441eb4c-9eadf93a/0000/3bdd81947c373230937abc964336b5f5"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group2[#2](744, 9ea)
/usr/local/bin/python generate_template_reference_data.py run -o group2 -j 7441eb4c64c1e8ebac38c41ffe945c97 9eadf93ad5371afb3e6e353591ea62d1
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_agg_op 7441eb4c64c1e8ebac38c41ffe945c97 9eadf93ad5371afb3e6e353591ea62d1
# /usr/local/bin/python generate_template_reference_data.py exec serial_agg_op 7441eb4c64c1e8ebac38c41ffe945c97 9eadf93ad5371afb3e6e353591ea62d1

