#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b50e641168bf562c189b6fbfb/hybrid_op/abc126baa5ce79180a73ac9dc1ba2ddf"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 26bd5f5b50e641168bf562c189b6fbfb

