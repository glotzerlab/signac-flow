#!/bin/bash
#SBATCH --job-name="SubmissionTe/hybrid_op/1/26bd5f5b/0000/9fc0e72b02be443eef2d4a22541aa7ec"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](26b)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 26bd5f5b50e641168bf562c189b6fbfb

