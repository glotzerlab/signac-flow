#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b50e641168bf562c189b6fbfb/memory_op/59c35c527ac6d55e3c0c67759579ce88"
#SBATCH --mem=0.5G
#SBATCH --partition=standard
#SBATCH -t 12:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 26bd5f5b50e641168bf562c189b6fbfb

