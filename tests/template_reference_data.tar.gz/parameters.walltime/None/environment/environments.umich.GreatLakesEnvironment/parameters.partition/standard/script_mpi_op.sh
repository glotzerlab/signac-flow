#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b50e641168bf562c189b6fbfb/mpi_op/0000/05ca3f577ce8e338d389a7f148476434"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 26bd5f5b50e641168bf562c189b6fbfb

