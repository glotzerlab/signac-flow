#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b/mpi_op/0000/95a542c4e3761b2b2e5e11e48a8bd381"
#SBATCH --partition=standard
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(26bd5f5b50e641168bf562c189b6fbfb)
mpiexec -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 26bd5f5b50e641168bf562c189b6fbfb

