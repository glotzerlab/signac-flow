#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b50e641168bf562c189b6fbfb/multiline_cm/fc5972d45ec38360b5a04f0b0fe7440a"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# echo "First line"
# echo "Second line"

