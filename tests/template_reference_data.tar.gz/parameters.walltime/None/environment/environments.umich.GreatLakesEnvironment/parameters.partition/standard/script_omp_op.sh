#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b/omp_op/0000/a66fbe0cc22da611022bca9c2a31a4a6"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# export OMP_NUM_THREADS=4  /usr/local/bin/python generate_template_reference_data.py exec omp_op 26bd5f5b50e641168bf562c189b6fbfb

