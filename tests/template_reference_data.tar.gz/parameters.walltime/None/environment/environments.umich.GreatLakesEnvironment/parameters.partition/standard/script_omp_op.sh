#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b50e641168bf562c189b6fbfb/omp_op/1a4684ba6a13591dcaefe85082c5d151"
#SBATCH --mem=4.0G
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 26bd5f5b50e641168bf562c189b6fbfb

