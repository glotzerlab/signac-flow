#!/bin/bash
#SBATCH --job-name="SubmissionTe/26bd5f5b/serial_op/0000/944cddcb1c2a5b0f8a60c454b234f3a2"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --account=rlarson1

set -e
set -u

cd /home/user/project/

# serial_op(26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 26bd5f5b50e641168bf562c189b6fbfb

