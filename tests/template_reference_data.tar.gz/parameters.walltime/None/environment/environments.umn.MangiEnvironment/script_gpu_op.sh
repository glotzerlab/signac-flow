#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/gpu_op/1168ebfe1d4d23047db70bdfd58fb90d"
#SBATCH --ntasks=2

set -e
set -u

cd /home/user/project/

# gpu_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op e9322f6258d5b1ae4aae667d1476f1f0

