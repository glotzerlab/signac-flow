#PBS -N SubmissionTe/e9322f62/gpu_op/0000/ff79cb38f38abbb7ad5e3adb8e8b258d
#PBS -V
#PBS -l procs=2:gpus=1

set -e
set -u

cd /home/user/project/

# gpu_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op e9322f6258d5b1ae4aae667d1476f1f0

