#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/parallel_ops/7493b4be00f555fa518f6b590ffd0f39"
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# group1(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op e9322f6258d5b1ae4aae667d1476f1f0
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op e9322f6258d5b1ae4aae667d1476f1f0

