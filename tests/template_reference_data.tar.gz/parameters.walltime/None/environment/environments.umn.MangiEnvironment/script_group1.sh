#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/memory_oppar/861a72bb8406990855005533f1e39a10"
#SBATCH --mem=0.5G
#SBATCH -t 01:00:00
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# group1(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op e9322f6258d5b1ae4aae667d1476f1f0
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op e9322f6258d5b1ae4aae667d1476f1f0
# /usr/local/bin/python generate_template_reference_data.py exec memory_op e9322f6258d5b1ae4aae667d1476f1f0
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op e9322f6258d5b1ae4aae667d1476f1f0

