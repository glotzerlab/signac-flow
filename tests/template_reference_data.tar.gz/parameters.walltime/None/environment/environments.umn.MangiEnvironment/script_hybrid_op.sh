#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/hybrid_op/d0edf796ab6f6d39585f905db9b61a71"
#SBATCH --ntasks=20

set -e
set -u

cd /home/user/project/

# hybrid_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op e9322f6258d5b1ae4aae667d1476f1f0

