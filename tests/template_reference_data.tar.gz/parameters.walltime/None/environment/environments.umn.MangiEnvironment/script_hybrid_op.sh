#PBS -N SubmissionTe/e9322f62/hybrid_op/0000/26bf91ff0191a64e0ed56ce5064c0b1a
#PBS -V
#PBS -l nodes=5:ppn=4

set -e
set -u

cd /home/user/project/

# hybrid_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op e9322f6258d5b1ae4aae667d1476f1f0

