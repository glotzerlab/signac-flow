#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/memory_op/3bd9c513b756470bced3a051bb37dc64"
#SBATCH --mem=8.0G
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# memory_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op e9322f6258d5b1ae4aae667d1476f1f0

