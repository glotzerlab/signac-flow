#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f62/mpi_gpu_op/0000/29e1200ec3ecebda1387c7906154ffac"
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# mpiexec -n 5  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec mpi_gpu_op e9322f6258d5b1ae4aae667d1476f1f0

