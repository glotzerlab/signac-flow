#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/mpi_gpu_op/2e679b62357e4f2edec97144a60eb726"
#SBATCH --mem=4.0G
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op e9322f6258d5b1ae4aae667d1476f1f0

