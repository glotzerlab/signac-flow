#PBS -N SubmissionTe/e9322f62/mpi_op/0000/794006d40a5130aa594fccedf5d30f59
#PBS -V
#PBS -l procs=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op e9322f6258d5b1ae4aae667d1476f1f0

