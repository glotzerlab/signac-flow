#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/multiline_cm/ed831ac2e6265378b38883d81194923c"
#SBATCH --mem=4.0G
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# echo "First line"
# echo "Second line"

