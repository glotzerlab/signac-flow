None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/omp_op/0ea51884bb0dd0a85f6c3df344466bef"
#SBATCH --ntasks=4

set -e
set -u

cd /home/user/project/

# omp_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op e9322f6258d5b1ae4aae667d1476f1f0

