#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/parallel_op/f60206dfae3e5a27e5c04fcb443e0beb"
#SBATCH --mem=4.0G
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# parallel_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op e9322f6258d5b1ae4aae667d1476f1f0

