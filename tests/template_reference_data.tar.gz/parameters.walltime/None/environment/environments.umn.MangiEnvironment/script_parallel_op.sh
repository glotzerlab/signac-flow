#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f62/parallel_op/0000/7f0d56079017a0f0b3369ead84259f91"
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# parallel_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec parallel_op e9322f6258d5b1ae4aae667d1476f1f0

