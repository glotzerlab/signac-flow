#PBS -N SubmissionTe/e9322f62/serial_op/0000/5daa987591233f9a8f2250c2d523e3dc
#PBS -V
#PBS -l procs=1

set -e
set -u

cd /home/user/project/

# serial_op[#1](e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op e9322f6258d5b1ae4aae667d1476f1f0

