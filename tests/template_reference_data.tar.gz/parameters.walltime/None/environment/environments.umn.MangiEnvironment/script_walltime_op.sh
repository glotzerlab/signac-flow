None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/e9322f6258d5b1ae4aae667d1476f1f0/walltime_op/28ead6725f98ba6b72cf9019cab55ee7"
#SBATCH -t 01:00:00
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# walltime_op(e9322f6258d5b1ae4aae667d1476f1f0)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j e9322f6258d5b1ae4aae667d1476f1f0
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op e9322f6258d5b1ae4aae667d1476f1f0

