None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/d8664283795991ec1571087a8305d540/gpu_op/05d879b75d42fc0a53f31ca85f9235a6"
#SBATCH --partition=GPU-shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(d8664283795991ec1571087a8305d540)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j d8664283795991ec1571087a8305d540
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op d8664283795991ec1571087a8305d540

