#!/bin/bash
#SBATCH --job-name="SubmissionTe/a1ef4682a030b94772446e451f57f2c0/gpu_op/cb0498d91de6d39841c3ce8fa135acc1"
#SBATCH --partition=GPU
#SBATCH -t 12:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# gpu_op(a1ef4682a030b94772446e451f57f2c0)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j a1ef4682a030b94772446e451f57f2c0
# Eligible to run:
# mpirun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op a1ef4682a030b94772446e451f57f2c0

