#!/bin/bash
#SBATCH --job-name="SubmissionTe/a1ef4682a030b94772446e451f57f2c0/mpi_gpu_op/26e777fd10bf31891ca3d519e884e843"
#SBATCH --partition=GPU
#SBATCH -t 12:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gpus=2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(a1ef4682a030b94772446e451f57f2c0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j a1ef4682a030b94772446e451f57f2c0
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op a1ef4682a030b94772446e451f57f2c0

