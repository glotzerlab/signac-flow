#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/parallel_ops/2ba5be2e38c66d101d8b80c5b0125510"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# group1(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op cd825fd7e6cacba31d9b45b80f27a745
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op cd825fd7e6cacba31d9b45b80f27a745

