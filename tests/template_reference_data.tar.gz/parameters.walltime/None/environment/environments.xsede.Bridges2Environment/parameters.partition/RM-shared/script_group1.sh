#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/memory_oppar/344a7861a99e2b637946851b570e4044"
#SBATCH --mem=0.5G
#SBATCH --partition=RM-shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# group1(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op cd825fd7e6cacba31d9b45b80f27a745
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op cd825fd7e6cacba31d9b45b80f27a745
# /usr/local/bin/python generate_template_reference_data.py exec memory_op cd825fd7e6cacba31d9b45b80f27a745
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op cd825fd7e6cacba31d9b45b80f27a745

