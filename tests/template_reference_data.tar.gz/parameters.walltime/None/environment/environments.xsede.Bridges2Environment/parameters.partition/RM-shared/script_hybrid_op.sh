None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/hybrid_op/bef4128819afe987a4c9c0aca2499e5c"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=20

set -e
set -u

cd /home/user/project/

# hybrid_op(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op cd825fd7e6cacba31d9b45b80f27a745

