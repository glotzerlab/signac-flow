None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/mpi_op/a1851c2ce8f665c3c1f4912e54251f44"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# mpi_op(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op cd825fd7e6cacba31d9b45b80f27a745

