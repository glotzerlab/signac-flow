#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/multiline_cm/b6391b054e79e5bfc34dfdaebcde86e6"
#SBATCH --partition=RM-shared
#SBATCH -t 12:00:00
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# echo "First line"
# echo "Second line"

