#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/omp_op/a6333f9facae8229fce6faa78185806b"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=4

set -e
set -u

cd /home/user/project/

# omp_op(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op cd825fd7e6cacba31d9b45b80f27a745

