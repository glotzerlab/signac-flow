None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/parallel_op/245a7065f6e90166169db4aff08210a5"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=3

set -e
set -u

cd /home/user/project/

# parallel_op(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op cd825fd7e6cacba31d9b45b80f27a745

