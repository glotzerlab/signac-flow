#!/bin/bash
#SBATCH --job-name="SubmissionTe/cd825fd7e6cacba31d9b45b80f27a745/serial_op/ebe84fe6c595376590bfddf33e1591da"
#SBATCH --partition=RM-shared
#SBATCH -N 1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# serial_op(cd825fd7e6cacba31d9b45b80f27a745)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j cd825fd7e6cacba31d9b45b80f27a745
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op cd825fd7e6cacba31d9b45b80f27a745

