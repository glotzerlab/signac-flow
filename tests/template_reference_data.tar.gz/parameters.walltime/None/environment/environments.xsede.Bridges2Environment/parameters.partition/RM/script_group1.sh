#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/parallel_ops/7ecb4108c0a2ee964935941ce11c083d"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1db7edfcb0f7262386bbae8873763550
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 1db7edfcb0f7262386bbae8873763550

