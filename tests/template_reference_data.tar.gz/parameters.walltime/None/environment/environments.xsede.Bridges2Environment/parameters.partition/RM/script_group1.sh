#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/memory_oppar/e2d92a662b9b637258eb7c8c18d8f35b"
#SBATCH --mem=0.5G
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1db7edfcb0f7262386bbae8873763550
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 1db7edfcb0f7262386bbae8873763550
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1db7edfcb0f7262386bbae8873763550
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 1db7edfcb0f7262386bbae8873763550

