#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/hybrid_op/63a12cabfe4545d32f8ac2963bf29086"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# export OMP_NUM_THREADS=4; mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 1db7edfcb0f7262386bbae8873763550

