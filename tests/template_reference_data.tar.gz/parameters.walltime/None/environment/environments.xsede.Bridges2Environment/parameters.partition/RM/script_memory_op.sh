#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/memory_op/200a003e93f3eca59285865262ade70d"
#SBATCH --mem=0.5G
#SBATCH --partition=RM
#SBATCH -t 12:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 1db7edfcb0f7262386bbae8873763550

