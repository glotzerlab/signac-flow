None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/mpi_op/29efda39a954d7a72ed28cb00539d958"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 1db7edfcb0f7262386bbae8873763550

