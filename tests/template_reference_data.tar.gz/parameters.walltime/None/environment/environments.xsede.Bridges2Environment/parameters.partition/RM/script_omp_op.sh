None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/omp_op/b9729cd3f6087b037d972cb72ac07007"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 1db7edfcb0f7262386bbae8873763550

