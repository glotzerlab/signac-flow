#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/serial_op/39570307358f42d06eaf54c7dd8cab99"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 1db7edfcb0f7262386bbae8873763550

