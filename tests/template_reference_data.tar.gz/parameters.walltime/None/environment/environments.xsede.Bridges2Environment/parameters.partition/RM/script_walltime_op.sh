None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/1db7edfcb0f7262386bbae8873763550/walltime_op/de8d318cec5cc6a451faa8fe23e6309f"
#SBATCH --partition=RM
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# walltime_op(1db7edfcb0f7262386bbae8873763550)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 1db7edfcb0f7262386bbae8873763550
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 1db7edfcb0f7262386bbae8873763550

