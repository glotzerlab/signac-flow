#!/bin/bash
#SBATCH --job-name="SubmissionTe/92b8611a/gpu_op/0000/e6784d6f56ff4ec8e8914b0b31b107bc"
#SBATCH --partition=GPU-AI
#SBATCH -N 1
#SBATCH --ntasks-per-node=2
#SBATCH --gres=gpu:volta16:2

set -e
set -u

cd /home/user/project/

# gpu_op(92b8611a1ed88c5a249e930d7bcae7a0)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j 92b8611a1ed88c5a249e930d7bcae7a0
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op 92b8611a1ed88c5a249e930d7bcae7a0

