#!/bin/bash
#SBATCH --job-name="SubmissionTe/92b8611a/mpi_gpu_op/0000/366a14f9cf139644ef4c268d88535216"
#SBATCH --partition=GPU-AI
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gres=gpu:volta16:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(92b8611a1ed88c5a249e930d7bcae7a0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 92b8611a1ed88c5a249e930d7bcae7a0
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 92b8611a1ed88c5a249e930d7bcae7a0

