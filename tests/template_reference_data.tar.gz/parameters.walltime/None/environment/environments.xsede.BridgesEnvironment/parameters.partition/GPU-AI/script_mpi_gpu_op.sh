#!/bin/bash
#SBATCH --job-name="SubmissionTe/92b8611a1ed88c5a249e930d7bcae7a0/mpi_gpu_op/1653fa49cd68acd95585f3ede4703faa"
#SBATCH --partition=GPU-AI
#SBATCH -N 1
#SBATCH --ntasks-per-node=5
#SBATCH --gres=gpu:volta16:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(92b8611a1ed88c5a249e930d7bcae7a0)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j 92b8611a1ed88c5a249e930d7bcae7a0
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op 92b8611a1ed88c5a249e930d7bcae7a0

