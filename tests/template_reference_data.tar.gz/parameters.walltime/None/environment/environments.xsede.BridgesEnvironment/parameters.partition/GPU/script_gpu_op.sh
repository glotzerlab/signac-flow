#!/bin/bash
#SBATCH --job-name="SubmissionTe/d30f0956/gpu_op/0000/4575ab3b405ef89eba12be87926f1cdd"
#SBATCH --partition=GPU
#SBATCH -N 1
#SBATCH --ntasks-per-node=32
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/johndoe/project/

# gpu_op(d30f0956499851002e8bd921cefe93e2)
/usr/local/bin/python generate_template_reference_data.py exec gpu_op d30f0956499851002e8bd921cefe93e2

