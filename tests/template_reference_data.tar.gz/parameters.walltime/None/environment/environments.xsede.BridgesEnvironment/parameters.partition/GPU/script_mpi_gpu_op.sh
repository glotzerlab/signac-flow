#!/bin/bash
#SBATCH --job-name="SubmissionTe/d30f0956499851002e8bd921cefe93e2/mpi_gpu_op/b61fe9ad2d507602ed3b9b80f1ee96f8"
#SBATCH --partition=GPU
#SBATCH -N 1
#SBATCH --ntasks-per-node=32
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op(d30f0956499851002e8bd921cefe93e2)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j d30f0956499851002e8bd921cefe93e2
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op d30f0956499851002e8bd921cefe93e2

