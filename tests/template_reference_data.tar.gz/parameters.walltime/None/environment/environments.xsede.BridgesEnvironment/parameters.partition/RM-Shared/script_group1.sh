#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c6acae4abd09b0055afdf157f/parallel_ops/17655f63afb8889d8bb1ca6bdd470dde"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1[#1](92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 92c6054c6acae4abd09b0055afdf157f
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 92c6054c6acae4abd09b0055afdf157f

