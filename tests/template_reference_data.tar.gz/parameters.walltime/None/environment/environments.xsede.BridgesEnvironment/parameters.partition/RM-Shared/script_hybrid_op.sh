#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/hybrid_op/0000/734cffeceb3fb71593b7707d19d08340"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node 4

set -e
set -u

cd /home/johndoe/project/

# hybrid_op(92c6054c6acae4abd09b0055afdf157f)
export OMP_NUM_THREADS=2
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 92c6054c6acae4abd09b0055afdf157f

