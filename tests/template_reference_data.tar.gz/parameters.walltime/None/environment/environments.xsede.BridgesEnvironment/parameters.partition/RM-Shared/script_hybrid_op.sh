#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/hybrid_op/0000/93f9f5473143eaee18f9417f3f78d4c3"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 92c6054c6acae4abd09b0055afdf157f

