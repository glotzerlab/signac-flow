#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c6acae4abd09b0055afdf157f/hybrid_op/1e0561e177df2a49e2a729eda35aee5f"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 92c6054c6acae4abd09b0055afdf157f

