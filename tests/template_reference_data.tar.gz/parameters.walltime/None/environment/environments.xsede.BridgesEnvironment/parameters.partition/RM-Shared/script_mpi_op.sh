#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/mpi_op/0000/c4f1c471b32c06bbfa2baaf0afd63cf4"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 92c6054c6acae4abd09b0055afdf157f

