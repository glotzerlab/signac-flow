#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c6acae4abd09b0055afdf157f/mpi_op/89b734523dc1ce2626106d3a30a69ef5"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 92c6054c6acae4abd09b0055afdf157f

