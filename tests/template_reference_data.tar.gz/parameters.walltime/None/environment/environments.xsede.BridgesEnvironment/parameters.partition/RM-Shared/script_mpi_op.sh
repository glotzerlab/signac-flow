#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/mpi_op/0000/81933e2616617db598868fe4d67c0a67"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(92c6054c6acae4abd09b0055afdf157f)
mpirun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 92c6054c6acae4abd09b0055afdf157f

