#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c6acae4abd09b0055afdf157f/multiline_cm/75952b86b307c33d0a26e2232c320f3d"
#SBATCH --mem=4.0G
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# echo "First line"
# echo "Second line"

