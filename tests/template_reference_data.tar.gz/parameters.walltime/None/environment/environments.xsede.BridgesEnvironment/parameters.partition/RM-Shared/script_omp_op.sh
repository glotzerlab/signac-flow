#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/omp_op/0000/f60fa731dda5b271339c74dd6806f791"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# omp_op(92c6054c6acae4abd09b0055afdf157f)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 92c6054c6acae4abd09b0055afdf157f

