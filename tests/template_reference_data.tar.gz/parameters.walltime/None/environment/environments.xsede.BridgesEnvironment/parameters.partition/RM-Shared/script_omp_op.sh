#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/omp_op/0000/c3993caf5c37ea56114ce23a45deb428"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# export OMP_NUM_THREADS=4
 /usr/local/bin/python generate_template_reference_data.py exec omp_op 92c6054c6acae4abd09b0055afdf157f

