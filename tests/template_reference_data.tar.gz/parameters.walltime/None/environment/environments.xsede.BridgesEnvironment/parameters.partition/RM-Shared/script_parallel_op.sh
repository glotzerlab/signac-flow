#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/parallel_op/0000/7cb1b1527d55248af9fb4111bf1314fb"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 92c6054c6acae4abd09b0055afdf157f

