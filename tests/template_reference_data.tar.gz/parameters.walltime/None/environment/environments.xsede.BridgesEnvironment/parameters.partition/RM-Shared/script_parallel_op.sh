#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/parallel_op/0000/dc23b36d358eaae840e704bc4b8b3902"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op[#1](92c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 92c6054c6acae4abd09b0055afdf157f

