#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c6acae4abd09b0055afdf157f/serial_op/e8ca39da64977ea628fc173f95dc8c8a"
#SBATCH --mem=4.0G
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 92c6054c6acae4abd09b0055afdf157f

