#!/bin/bash
#SBATCH --job-name="SubmissionTe/92c6054c/serial_op/0000/9b45aafd6b48136043e85263b083603d"
#SBATCH --partition=RM-Shared
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(92c6054c6acae4abd09b0055afdf157f)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 92c6054c6acae4abd09b0055afdf157f
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec serial_op 92c6054c6acae4abd09b0055afdf157f

