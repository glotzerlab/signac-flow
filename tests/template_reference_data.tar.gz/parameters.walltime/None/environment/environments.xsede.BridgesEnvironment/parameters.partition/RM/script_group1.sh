#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/parallel_ops/0000/87b3dcf7e81ea16db577e2dff4b8b669"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1[#1](8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8aef86cd5a5dbb175d555864a7c91eed
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8aef86cd5a5dbb175d555864a7c91eed

