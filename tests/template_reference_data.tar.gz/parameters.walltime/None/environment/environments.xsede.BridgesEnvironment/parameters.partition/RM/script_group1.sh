#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd5a5dbb175d555864a7c91eed/parallel_ops/00ed19a6fc3f1bdf71f6daf5c27a72bb"
#SBATCH --mem=4.0G
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 8aef86cd5a5dbb175d555864a7c91eed
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8aef86cd5a5dbb175d555864a7c91eed

