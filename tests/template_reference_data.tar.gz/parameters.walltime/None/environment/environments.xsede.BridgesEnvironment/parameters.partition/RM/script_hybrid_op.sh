#!/bin/bash
#SBATCH --job-name="SubmissionTe/hybrid_op/1/8aef86cd/0000/8dd6f70fcf74768904ceb9cb5eb39b69"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](8ae)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 8aef86cd5a5dbb175d555864a7c91eed

