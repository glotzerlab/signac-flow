#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/mpi_op/0000/eb8fb09d03b155a7afa285244394e748"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/johndoe/project/

# mpi_op(8aef86cd5a5dbb175d555864a7c91eed)
mpirun -n 5 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 8aef86cd5a5dbb175d555864a7c91eed

