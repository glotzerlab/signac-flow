#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd5a5dbb175d555864a7c91eed/mpi_op/d5e9361759784ee2802a1959fcffc7a1"
#SBATCH --mem=4.0G
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# mpirun -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 8aef86cd5a5dbb175d555864a7c91eed

