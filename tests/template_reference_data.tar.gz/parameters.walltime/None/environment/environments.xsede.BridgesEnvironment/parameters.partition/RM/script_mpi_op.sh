#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/mpi_op/0000/0c83bb6da45ed1f00ba0ff1a8b7d7cfe"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# mpiexec -n 5  /home/siepmann/singh891/.conda/envs/test-signac/bin/python generate_template_reference_data.py exec mpi_op 8aef86cd5a5dbb175d555864a7c91eed

