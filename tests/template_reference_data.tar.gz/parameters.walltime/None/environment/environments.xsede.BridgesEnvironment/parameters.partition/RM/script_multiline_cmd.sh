#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd5a5dbb175d555864a7c91eed/multiline_cm/08e386048813959951cd0ad8f040b4ed"
#SBATCH --mem=4.0G
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# echo "First line"
# echo "Second line"

