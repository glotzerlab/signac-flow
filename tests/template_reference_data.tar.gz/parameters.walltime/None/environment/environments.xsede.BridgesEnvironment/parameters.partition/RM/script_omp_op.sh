#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/omp_op/0000/cdde083a6bd2a6674918c48151c4228b"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# export OMP_NUM_THREADS=4;  /home/bdice/miniconda3/envs/dice/bin/python generate_template_reference_data.py exec omp_op 8aef86cd5a5dbb175d555864a7c91eed

