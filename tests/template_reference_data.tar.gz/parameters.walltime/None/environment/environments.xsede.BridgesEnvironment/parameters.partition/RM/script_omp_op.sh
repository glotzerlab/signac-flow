#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/omp_op/0000/a972d9d73a421223ab3f6b994aaf0c79"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/johndoe/project/

# omp_op(8aef86cd5a5dbb175d555864a7c91eed)
export OMP_NUM_THREADS=4
/usr/local/bin/python generate_template_reference_data.py exec omp_op 8aef86cd5a5dbb175d555864a7c91eed

