#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/parallel_op/0000/af0bae04e6eceda35546f69e12a7c9ee"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node 2

set -e
set -u

cd /home/johndoe/project/

# parallel_op(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py exec parallel_op 8aef86cd5a5dbb175d555864a7c91eed

