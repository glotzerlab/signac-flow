#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd5a5dbb175d555864a7c91eed/parallel_op/0000/362cf5090ed4f3d42d8da2401a3c0a47"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op[#1](8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 8aef86cd5a5dbb175d555864a7c91eed

