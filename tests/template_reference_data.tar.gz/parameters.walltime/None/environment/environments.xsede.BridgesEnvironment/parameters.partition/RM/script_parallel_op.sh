#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/parallel_op/0000/68a41c45fae467e2426905fffaeb1b55"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 8aef86cd5a5dbb175d555864a7c91eed
# Eligible to run:
# /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec parallel_op 8aef86cd5a5dbb175d555864a7c91eed

