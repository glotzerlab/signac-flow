#!/bin/bash
#SBATCH --job-name="SubmissionTe/8aef86cd/serial_op/0000/990f21ba2a78baf0a67972bb5f126476"
#SBATCH --partition=RM
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(8aef86cd5a5dbb175d555864a7c91eed)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 8aef86cd5a5dbb175d555864a7c91eed

