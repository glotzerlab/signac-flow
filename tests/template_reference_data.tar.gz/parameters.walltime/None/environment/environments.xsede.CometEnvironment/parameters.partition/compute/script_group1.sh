#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d77326769c7e5c65bdcf8c303265c/memory_oppar/2ae04ae41f5ba13dd027af62162db3d7"
#SBATCH --mem=0.5G
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 0b5d77326769c7e5c65bdcf8c303265c
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 0b5d77326769c7e5c65bdcf8c303265c
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 0b5d77326769c7e5c65bdcf8c303265c

