#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d77326769c7e5c65bdcf8c303265c/parallel_ops/11411dc67c52798396f0cd99f2186e2b"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1[#1](0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 0b5d77326769c7e5c65bdcf8c303265c
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 0b5d77326769c7e5c65bdcf8c303265c

