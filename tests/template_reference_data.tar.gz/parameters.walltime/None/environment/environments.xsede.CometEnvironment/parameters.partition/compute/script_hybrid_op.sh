#!/bin/bash
#SBATCH --job-name="SubmissionTe/hybrid_op/1/0b5d7732/0000/f13dee97d0316b64ed8cc8787c73cfbd"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](0b5)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 0b5d77326769c7e5c65bdcf8c303265c

