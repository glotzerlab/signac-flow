#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d77326769c7e5c65bdcf8c303265c/hybrid_op/2fb47c50e2782dc3c578bc16e4ad04f1"
#SBATCH --partition=compute
#SBATCH -t 12:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# export OMP_NUM_THREADS=4; ibrun -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 0b5d77326769c7e5c65bdcf8c303265c

