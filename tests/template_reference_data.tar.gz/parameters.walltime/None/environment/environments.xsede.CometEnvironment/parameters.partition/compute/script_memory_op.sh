#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d77326769c7e5c65bdcf8c303265c/memory_op/5ac333d5a16ae6b2c04cace9035e2ecf"
#SBATCH --mem=8.0G
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 0b5d77326769c7e5c65bdcf8c303265c

