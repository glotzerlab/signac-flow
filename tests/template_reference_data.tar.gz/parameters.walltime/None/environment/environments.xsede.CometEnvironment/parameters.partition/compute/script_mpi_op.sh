#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d77326769c7e5c65bdcf8c303265c/mpi_op/0000/ed67cee85e356673dbef3f64e69731bc"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op[#1](0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 0b5d77326769c7e5c65bdcf8c303265c

