#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d77326769c7e5c65bdcf8c303265c/multiline_cm/cf9819e31351b09317944d88c426ff27"
#SBATCH --mem=4.0G
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# echo "First line"
# echo "Second line"

