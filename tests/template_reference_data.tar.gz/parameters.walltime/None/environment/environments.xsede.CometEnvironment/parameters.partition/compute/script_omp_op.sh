#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d7732/omp_op/0000/bc665aeffaf362586659cb515b158365"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op[#1](0b5)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op 0b5d77326769c7e5c65bdcf8c303265c

