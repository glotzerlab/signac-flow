#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d7732/parallel_op/0000/ee8786075044db239c02aaee2db1a286"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 0b5d77326769c7e5c65bdcf8c303265c

