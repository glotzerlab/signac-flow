None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d77326769c7e5c65bdcf8c303265c/walltime_op/7e88898b25627637ab18870d88d60910"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# walltime_op(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 0b5d77326769c7e5c65bdcf8c303265c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 0b5d77326769c7e5c65bdcf8c303265c

