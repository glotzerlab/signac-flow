#!/bin/bash
#SBATCH --job-name="SubmissionTe/de1e35d9/gpu_op/0000/3b2e8f7178e09cc8f095486903aad989"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# gpu_op(de1e35d92b83510d959ebfb4683d7cce)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j de1e35d92b83510d959ebfb4683d7cce

