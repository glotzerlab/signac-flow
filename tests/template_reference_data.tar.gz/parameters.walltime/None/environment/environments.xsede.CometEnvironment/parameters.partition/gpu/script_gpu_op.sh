#!/bin/bash
#SBATCH --job-name="SubmissionTe/de1e35d92b83510d959ebfb4683d7cce/gpu_op/65f4352aa77c65aa0796bd5af29ba1dd"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# gpu_op[#1](de1e35d92b83510d959ebfb4683d7cce)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j de1e35d92b83510d959ebfb4683d7cce
# Eligible to run:
# ibrun -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op de1e35d92b83510d959ebfb4683d7cce

