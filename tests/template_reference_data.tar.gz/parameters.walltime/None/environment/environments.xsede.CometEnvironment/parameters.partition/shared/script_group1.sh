#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd586/parallel_ops/0000/ab6cad96e410a9f457d0b67e26f5031f"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /home/bdice/miniconda3/envs/dice/bin/python generate_template_reference_data.py exec parallel_op 216cd5860da17dc03ca7facd39d25e5c
# /home/bdice/miniconda3/envs/dice/bin/python generate_template_reference_data.py exec serial_op 216cd5860da17dc03ca7facd39d25e5c

