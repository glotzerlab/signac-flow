#SBATCH --job-name="SubmissionTe/216cd586/hybrid_op/0000/"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4
export OMP_NUM_THREADS=2