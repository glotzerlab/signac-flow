#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd5860da17dc03ca7facd39d25e5c/memory_op/03cd752d55e6a55bf0ddd0e5b6e34b95"
#SBATCH --mem=8.0G
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# memory_op(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 216cd5860da17dc03ca7facd39d25e5c

