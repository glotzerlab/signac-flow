#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd586/mpi_op/0000/37165f2ac0814e833816b52a1a94da26"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 216cd5860da17dc03ca7facd39d25e5c

