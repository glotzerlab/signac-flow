#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd586/mpi_op/0000/4cb9fb1768b54fd856aa3defe991ec10"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=2

set -e
set -u

cd /home/johndoe/project/

# mpi_op(216cd5860da17dc03ca7facd39d25e5c)
ibrun -n 2 /usr/local/bin/python generate_template_reference_data.py exec mpi_op 216cd5860da17dc03ca7facd39d25e5c

