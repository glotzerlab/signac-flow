#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd5860da17dc03ca7facd39d25e5c/multiline_cm/0dc529e41b16a7f5a10dc7f1fe1b5858"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# multiline_cmd(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o multiline_cmd -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# echo "First line"
# echo "Second line"

