#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd586/omp_op/0000/4aa4df8f98c6be351d9cbd444cea9960"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=4

set -e
set -u

cd /home/user/project/

# omp_op(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# export OMP_NUM_THREADS=4  /usr/local/bin/python generate_template_reference_data.py exec omp_op 216cd5860da17dc03ca7facd39d25e5c

