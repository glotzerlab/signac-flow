#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd5860da17dc03ca7facd39d25e5c/parallel_op/0000/c9b7e17f0e510068b93c9133f28b98db"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op[#1](216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 216cd5860da17dc03ca7facd39d25e5c

