#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd5860da17dc03ca7facd39d25e5c/parallel_op/5a665e71ec2292b2c22cbb36040bbd59"
#SBATCH --partition=shared
#SBATCH -t 12:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 216cd5860da17dc03ca7facd39d25e5c

