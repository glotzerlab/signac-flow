#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd5860da17dc03ca7facd39d25e5c/serial_op/9a1711a9caed0a514d88ea9b29874833"
#SBATCH --mem=4.0G
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 216cd5860da17dc03ca7facd39d25e5c

