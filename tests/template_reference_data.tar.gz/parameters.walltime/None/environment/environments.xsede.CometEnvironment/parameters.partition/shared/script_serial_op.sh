#!/bin/bash
#SBATCH --job-name="SubmissionTe/serial_op/1/216cd586/0000/5808cb5245e4f7522c762fdcd7916709"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op[#1](216)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 216cd5860da17dc03ca7facd39d25e5c

