None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/216cd5860da17dc03ca7facd39d25e5c/walltime_op/59b6e4bf8c5dfe6e437b5a7cf16999ae"
#SBATCH --partition=shared
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# walltime_op(216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o walltime_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec walltime_op 216cd5860da17dc03ca7facd39d25e5c

