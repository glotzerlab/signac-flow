#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a992889fc18663a15acdfdcacba/hybrid_op/51b8f919daaf933cdfe8ab8c8814503a"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# hybrid_op(4a483a992889fc18663a15acdfdcacba)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 4a483a992889fc18663a15acdfdcacba
# Eligible to run:
# export OMP_NUM_THREADS=4; ibrun -n 5 -o 0 task_affinity  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 4a483a992889fc18663a15acdfdcacba


