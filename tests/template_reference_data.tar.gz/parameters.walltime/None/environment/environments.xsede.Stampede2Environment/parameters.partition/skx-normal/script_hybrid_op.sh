#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a99/hybrid_op/0000/cd4c889841600dea3aabf671a1b30c1c"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=5

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](4a483a992889fc18663a15acdfdcacba)
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 4a483a992889fc18663a15acdfdcacba
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 4a483a992889fc18663a15acdfdcacba


