None
#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a992889fc18663a15acdfdcacba/memory_op/896b6ec9357328fb6bb140a3ce60a59f"
#SBATCH --mem=0.5G
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# memory_op(4a483a992889fc18663a15acdfdcacba)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o memory_op -j 4a483a992889fc18663a15acdfdcacba
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec memory_op 4a483a992889fc18663a15acdfdcacba


