#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a99/omp_op/0000/670605860891c0220ccd6e8afb61fbb5"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# omp_op(4a483a992889fc18663a15acdfdcacba)
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o omp_op -j 4a483a992889fc18663a15acdfdcacba
# Eligible to run:
# export OMP_NUM_THREADS=4;  /home/siepmann/singh891/.conda/envs/siganc-test/bin/python generate_template_reference_data.py exec omp_op 4a483a992889fc18663a15acdfdcacba


