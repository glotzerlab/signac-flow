#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a99/omp_op/0000/2cdfa586696d7ebc6037ab2b1fa9b263"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=2
#SBATCH --partition=skx-normal

set -e
set -u

cd /home/johndoe/project/

# omp_op(4a483a992889fc18663a15acdfdcacba)
export OMP_NUM_THREADS=2
/usr/local/bin/python generate_template_reference_data.py exec omp_op 4a483a992889fc18663a15acdfdcacba

