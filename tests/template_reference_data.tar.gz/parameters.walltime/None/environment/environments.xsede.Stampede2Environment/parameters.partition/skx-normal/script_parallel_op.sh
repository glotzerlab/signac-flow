#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a992889fc18663a15acdfdcacba/parallel_op/45def292ce735007784ff46a25e31034"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# parallel_op(4a483a992889fc18663a15acdfdcacba)
export _FLOW_STAMPEDE_OFFSET_=0
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 4a483a992889fc18663a15acdfdcacba
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 4a483a992889fc18663a15acdfdcacba


