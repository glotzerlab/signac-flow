#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a99/parallel_op/0000/7d4ea14c4ccfa1ad8a180ea611b0e755"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/user/project/

# parallel_op(4a483a992889fc18663a15acdfdcacba)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 4a483a992889fc18663a15acdfdcacba
_FLOW_STAMPEDE_OFFSET_=0 /usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 4a483a992889fc18663a15acdfdcacba

