#!/bin/bash
#SBATCH --job-name="SubmissionTe/4a483a99/serial_op/0000/3af6f6d0b5f45ae916c2793b615336b8"
#SBATCH --partition=skx-normal
#SBATCH --nodes=1
#SBATCH --ntasks=1

set -e
set -u

cd /home/johndoe/project/

# serial_op(4a483a992889fc18663a15acdfdcacba)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 4a483a992889fc18663a15acdfdcacba

