#!/bin/bash
#SBATCH --job-name="SubmissionTe/0b5d7732/serial_op/0000/99c0ceae19faa2b56158895bbd2e532c"
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op(0b5d77326769c7e5c65bdcf8c303265c)
/usr/local/bin/python generate_template_reference_data.py exec serial_op 0b5d77326769c7e5c65bdcf8c303265c

