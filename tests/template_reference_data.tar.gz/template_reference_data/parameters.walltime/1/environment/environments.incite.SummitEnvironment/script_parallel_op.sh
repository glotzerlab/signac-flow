#!/bin/bash
#BSUB -J SubmissionTe/parallel_op/1/2e49a8cb/0000/9838006ebdd8aa9f9068f506795c4c12
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# parallel_op-1: (2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 2e49a8cb2fc131daf5747c8adc0da35e

