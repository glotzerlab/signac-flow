#!/bin/bash
#BSUB -J SubmissionTe/serial_op/1/2e49a8cb/0000/1283a05807e119a841806371dc817ad7
#BSUB -W 01:00
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# serial_op-1: (2e49a8cb2fc131daf5747c8adc0da35e)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 2e49a8cb2fc131daf5747c8adc0da35e
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 2e49a8cb2fc131daf5747c8adc0da35e

