#!/bin/bash
#SBATCH --job-name="SubmissionTe/gpu_op/1/d52fc627/0000/61b094a24220bc6288b75147fb7d995d"
#SBATCH --partition=GPU
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=32
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# gpu_op-1: (d52fc62789278c7532552747230bca38)
/usr/local/bin/python generate_template_reference_data.py run -o gpu_op -j d52fc62789278c7532552747230bca38
# Eligible to run:
# mpiexec -n 2  /usr/local/bin/python generate_template_reference_data.py exec gpu_op d52fc62789278c7532552747230bca38

