#!/bin/bash
#SBATCH --job-name="SubmissionTe/serial_op/1/66c927d2/0000/7d8c321f5cfdb0738485a60d2fc48807"
#SBATCH --partition=RM-Shared
#SBATCH -t 01:00:00
#SBATCH -N 1
#SBATCH --ntasks-per-node=1

set -e
set -u

cd /home/user/project/

# serial_op-1: (66c927d23507f3907b4cbded78a54f68)
/usr/local/bin/python generate_template_reference_data.py run -o serial_op -j 66c927d23507f3907b4cbded78a54f68
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 66c927d23507f3907b4cbded78a54f68

