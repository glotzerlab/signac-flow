#!/bin/bash
#SBATCH --job-name="SubmissionTe/group1/1/0a46314f/0000/60068b640c8841b4d8a7e96d2c1839ed"
#SBATCH --partition=compute
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# group1-1: (0a46314f3bb21140debbc8e4af120947)
/usr/local/bin/python generate_template_reference_data.py run -o group1 -j 0a46314f3bb21140debbc8e4af120947
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec serial_op 0a46314f3bb21140debbc8e4af120947
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 0a46314f3bb21140debbc8e4af120947

