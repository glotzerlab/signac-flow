#!/bin/bash
#SBATCH --job-name="SubmissionTe/mpi_gpu_op/1/b2c00b6e/0000/fa9c9a7dc94efbbc65abdfef253956c3"
#SBATCH --partition=gpu
#SBATCH -t 01:00:00
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op-1: (b2c00b6e5630ad7c40eb9f7ce4f0576c)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j b2c00b6e5630ad7c40eb9f7ce4f0576c
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op b2c00b6e5630ad7c40eb9f7ce4f0576c

