#!/bin/bash
#BSUB -J SubmissionTe/omp_op/1/e6cbac22/0000/e44cab9c84b7fd87ae100a2f088d92e1
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# omp_op-1: (e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o omp_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# export OMP_NUM_THREADS=4;  /usr/local/bin/python generate_template_reference_data.py exec omp_op e6cbac22c5887a52771be793228ff1a9

