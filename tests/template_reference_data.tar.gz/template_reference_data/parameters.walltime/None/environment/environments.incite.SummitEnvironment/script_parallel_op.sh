#!/bin/bash
#BSUB -J SubmissionTe/parallel_op/1/e6cbac22/0000/724e2da3c8f93235f3c023c95b7854c9
#BSUB -nnodes 1

set -e
set -u

cd /home/user/project/

# parallel_op-1: (e6cbac22c5887a52771be793228ff1a9)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j e6cbac22c5887a52771be793228ff1a9
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op e6cbac22c5887a52771be793228ff1a9

