#!/bin/bash
#SBATCH --job-name="SubmissionTe/mpi_op/1/26bd5f5b/0000/95a542c4e3761b2b2e5e11e48a8bd381"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=5

set -e
set -u

cd /home/user/project/

# mpi_op-1: (26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_op 26bd5f5b50e641168bf562c189b6fbfb

