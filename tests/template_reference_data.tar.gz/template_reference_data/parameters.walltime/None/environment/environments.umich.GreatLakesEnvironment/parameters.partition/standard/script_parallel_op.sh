#!/bin/bash
#SBATCH --job-name="SubmissionTe/parallel_op/1/26bd5f5b/0000/52522ed013c8950e4809c522f8538467"
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op-1: (26bd5f5b50e641168bf562c189b6fbfb)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 26bd5f5b50e641168bf562c189b6fbfb
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 26bd5f5b50e641168bf562c189b6fbfb

