#!/bin/bash
#SBATCH --job-name="SubmissionTe/mpi_gpu_op/1/d30f0956/0000/4b7c41472d365b7ce8af7a81b618c911"
#SBATCH --partition=GPU
#SBATCH -N 1
#SBATCH --ntasks-per-node=32
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op-1: (d30f0956499851002e8bd921cefe93e2)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j d30f0956499851002e8bd921cefe93e2
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op d30f0956499851002e8bd921cefe93e2

