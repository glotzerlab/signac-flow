#!/bin/bash
#SBATCH --job-name="SubmissionTe/mpi_gpu_op/1/de1e35d9/0000/fc719ad6dd0d388769f634ef0036e1d5"
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --gres=gpu:p100:2

set -e
set -u

cd /home/user/project/

# mpi_gpu_op-1: (de1e35d92b83510d959ebfb4683d7cce)
/usr/local/bin/python generate_template_reference_data.py run -o mpi_gpu_op -j de1e35d92b83510d959ebfb4683d7cce
# Eligible to run:
# mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec mpi_gpu_op de1e35d92b83510d959ebfb4683d7cce

