#!/bin/bash
#SBATCH --job-name="SubmissionTe/hybrid_op/1/216cd586/0000/33edd8bad1341b1165e62a207bf1b3a1"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=20

set -e
set -u

cd /home/user/project/

# hybrid_op[#1](216)
/usr/local/bin/python generate_template_reference_data.py run -o hybrid_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# export OMP_NUM_THREADS=4; mpiexec -n 5  /usr/local/bin/python generate_template_reference_data.py exec hybrid_op 216cd5860da17dc03ca7facd39d25e5c

