#!/bin/bash
#SBATCH --job-name="SubmissionTe/parallel_op/1/216cd586/0000/80514982110b3295e4a84b260976e23f"
#SBATCH --partition=shared
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=3

set -e
set -u

cd /home/user/project/

# parallel_op-1: (216cd5860da17dc03ca7facd39d25e5c)
/usr/local/bin/python generate_template_reference_data.py run -o parallel_op -j 216cd5860da17dc03ca7facd39d25e5c
# Eligible to run:
# /usr/local/bin/python generate_template_reference_data.py exec parallel_op 216cd5860da17dc03ca7facd39d25e5c

